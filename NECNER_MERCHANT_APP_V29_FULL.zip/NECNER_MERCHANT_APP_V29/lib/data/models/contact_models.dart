import 'package:flutter/foundation.dart';

@immutable
class MerchantContact {
  final int id;
  final String name;
  final String phone;
  final String email;
  final String status;
  final String optInStatus;

  const MerchantContact({
    required this.id,
    required this.name,
    required this.phone,
    required this.email,
    required this.status,
    required this.optInStatus,
  });

  factory MerchantContact.fromJson(Map<String, dynamic> json) {
    return MerchantContact(
      id: int.tryParse(json['id']?.toString() ?? '') ?? 0,
      name: (json['name'] ?? '').toString().trim(),
      phone: (json['phone'] ?? '').toString().trim(),
      email: (json['email'] ?? '').toString().trim(),
      status: (json['status'] ?? 'active').toString(),
      optInStatus: (json['opt_in_status'] ?? 'opted_in').toString(),
    );
  }
}
