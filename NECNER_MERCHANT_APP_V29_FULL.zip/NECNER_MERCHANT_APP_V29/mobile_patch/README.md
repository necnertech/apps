# NECNER Merchant App V29 — Backend Additive Patch

This package contains **new files only**. Do not replace existing service PHP files.

Upload these files to the same `public_html` used by the app:

- `workspace-bridge.php` -> `mobile/workspace-bridge.php`
- `chat/start.php` -> `mobile/chat/start.php`

The existing `mobile/.htaccess` does not need a new rewrite rule because both are physical PHP files.

## What this fixes

1. Merchant Workspace Bridge now loads the real `SellerAuth` through the existing mobile-platform bootstrap.
2. The bridge creates the normal `WaSaaS\\Auth` customer web session, including the correct role fields.
3. Relative service routes are resolved server-side from the central service registry, so `exports/admin/...` and `store/admin/...` do not accidentally open `/admin/...`.
4. `iframe=1` is always applied, so existing PHP customer/service pages render without their desktop sidebar/topbar/footer.
5. `chat/start.php` creates/reuses a tenant-scoped mobile chat conversation for a CRM contact, allowing a new chat to be opened even when no previous thread exists.

## Security

The bridge and chat endpoint always authenticate the existing Bearer token and derive tenant/user identity server-side. The Flutter client cannot choose another tenant.
