# NECNER Merchant App V30 — Functional/UI Fix Pack

This package is based on the supplied NECNER Merchant App V29 project. Existing service/business architecture is preserved; the fixes are focused on the problems shown in the supplied screenshots.

## Fixed in this package

- WebView merchant session bridge is used for existing merchant PHP pages.
- Direct service API manifest routes are handled with the mobile Bearer token instead of being opened as an unauthenticated web page.
- E-Commerce/Store legacy API manifest routes are mapped to the real merchant UI pages for Products, Orders, Payments/Settings and Store dashboard.
- Android WebView `<input type="file">` now opens the native file picker, including product/profile image uploads.
- WebView file/content access is enabled for authenticated merchant pages.
- Merchant web workspace sidebar/drawer/overlay is hidden in the mobile workspace so the black desktop sidebar does not appear after save/navigation.
- Common merchant web tools opened from the Flutter app now open inside the authenticated Merchant WebView instead of an unauthenticated external browser.
- Common tools now include Contacts, Groups/Segments, Broadcast, Message Templates, Bulk SMS workspace, Inbox and WhatsApp Numbers.
- Bottom navigation uses the same dark-teal header background with emerald active state.
- New-chat contact picker uses a dark theme and has an explicit close button.
- Contact avatars are displayed when the backend supplies an avatar/profile image URL; initials remain the fallback.
- Chat rows also use the contact avatar when available.
- New-chat flow continues to use the tenant-scoped `/mobile/chat/start.php` endpoint.
- Chat composer uses the chat theme instead of a black/detached input appearance.
- Chat contains service-aware action buttons and a merchant frontend URL action.
- Chat URL card has an Open Merchant Frontend button.
- A test URL message is automatically sent only when a newly opened conversation has no messages; it can also be sent manually from the chat action menu.
- Chat watermark: `NECNER TECHNOLOGY — WhatsApp API Cloud System`.
- Service detail changed from a cramped 3-column icon canvas to a professional full-width page/module list.
- Storefront URL endpoint added so the chat URL can resolve to the authenticated merchant's actual storefront URL when the backend registry provides one.

## Backend patch

Upload the files in `mobile_patch/` to the corresponding `/public_html/mobile/` location on Hostinger:

- `chat/start.php`
- `workspace-bridge.php`
- `storefront-url.php`

These are NEW patch files. Do not replace existing service business files.

## Flutter dependency

Added:

`webview_flutter_android: ^4.10.0`

After extracting the project on the development PC:

```powershell
C:\flutter\bin\flutter.bat pub get
C:\flutter\bin\flutter.bat analyze
C:\flutter\bin\flutter.bat clean
C:\flutter\bin\flutter.bat pub get
C:\flutter\bin\flutter.bat build apk --release
```

Do not upgrade Gradle/AGP/Kotlin just for the existing warning messages unless a real build failure requires it.
