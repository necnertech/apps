# Necner Merchant — Global Tools Implementation

This package extends the existing merchant Flutter app without replacing its dynamic service engine.

## Global tools
- Merchant Tools / More menu
- WhatsApp Business center
- Screenshot-style WhatsApp template builder with live preview
- Contacts: add, search, phone contact sync, CSV import/export, Google Contacts OAuth sync
- Groups / broadcast entry points
- CRM & Deals entry point
- Automation & AI entry points
- Team management
- Payments / transactions / refunds view foundation
- Subscription / usage / message balance view
- Invoice links for order transactions
- Password change
- WhatsApp number status

## Service rule
Every assigned service continues to load its own backend manifest/modules. Common capabilities are available inside the merchant application and may be used in the context of every assigned service. They are not duplicated as separate hard-coded service implementations.

## Backend
The companion `public_html` package adds `/mobile/global.php` and `/mobile/google-contacts.php`. Existing `contacts`, `teams`, `team_members`, `payments`, `subscriptions`, `plans`, `orders`, `whatsapp_numbers`, and `whatsapp_templates` tables are reused. No new SQL migration is required by this package.

## Provider requirements
- Google Contacts sync requires the existing platform Google Client ID/Secret and Google People API Contacts scope to be enabled in the Google Cloud project.
- FCM/APNs still require production provider credentials for true background push delivery.
- WhatsApp template approval remains controlled by Meta; drafts are not represented as approved.
