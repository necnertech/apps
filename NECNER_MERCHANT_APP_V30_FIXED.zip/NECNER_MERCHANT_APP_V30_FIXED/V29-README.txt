NECNER MERCHANT APP V29
========================

BASE
----
This package is based on NECNER merchant app V26 and adds the V27 workspace bridge flow plus the fixes below.

MAIN FIXES
----------
1. Service screen remains assignment-driven.
2. Each assigned service opens a 3-column circle-icon function grid.
3. Clicking a service function opens the EXISTING PHP merchant page in an in-app WebView.
4. The PHP workspace bridge creates the normal merchant web session and applies iframe=1, so desktop sidebar/topbar/footer are not shown.
5. Service relative routes are resolved on the server from the central service registry.
6. Bottom navigation is Chats / Notifications / Services / Settings.
7. Settings contains common merchant functions: Business Profile, Account Settings, Security/Change Password, Team, WhatsApp, Contacts, Templates, Automation, Subscription/Billing and Analytics.
8. Top Chats 3-dot menu includes Profile/Business Logo, Change Password, Common Settings and WhatsApp Business.
9. Business name/logo are read from the authenticated merchant session and can be updated through the existing mobile profile API.
10. New Chat now loads the merchant's REAL CRM contacts from /mobile/whatsapp/contacts.php, showing full name and phone number.
11. Selecting a contact calls the new additive /mobile/chat/start.php endpoint to reuse/create the tenant-scoped mobile conversation, then opens the chat.

BACKEND PATCH
-------------
Upload these NEW files to public_html:

mobile_patch/workspace-bridge.php -> public_html/mobile/workspace-bridge.php
mobile_patch/chat/start.php       -> public_html/mobile/chat/start.php

No rewrite rule is required for these two physical PHP files.

FLUTTER BUILD
-------------
On the Windows Flutter machine:

cd C:\FlutterProjects\necner_merchant_app
C:\flutter\bin\flutter.bat pub get
C:\flutter\bin\flutter.bat analyze
C:\flutter\bin\flutter.bat run

Release APK:
C:\flutter\bin\flutter.bat build apk --release

IMPORTANT
---------
Do not replace the existing production service PHP modules. The mobile app intentionally opens those existing pages instead of rebuilding their business logic in Dart.
