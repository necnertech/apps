# ==============================================================================
# Necner Merchant App — Phase 11 Production ProGuard / R8 Optimization Rules
# Target: Android 14 (API 34) | Min: Android 6.0 (API 23)
# ==============================================================================

# Flutter Engine Keep Rules
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }

# Flutter Secure Storage (Android Keystore Integration)
-keep class com.it_nomads.fluttersecurestorage.** { *; }

# Connectivity Plus & Device Info Plus Plugins
-keep class dev.fluttercommunity.plus.connectivity.** { *; }
-keep class dev.fluttercommunity.plus.device_info.** { *; }
-keep class dev.fluttercommunity.plus.package_info.** { *; }

# Network & HTTP Models (Prevent obfuscating JSON serialization fields)
-keepattributes *Annotation*,EnclosingMethod,InnerClasses,Signature
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# Android Architecture Components
-keep class androidx.lifecycle.DefaultLifecycleObserver
-dontwarn androidx.window.**
-dontwarn okhttp3.**
-dontwarn okio.**

# Preserve Line Numbers for Crash Reporting & Deobfuscation Mapping
-renamesourcefileattribute SourceFile
-keepattributes SourceFile,LineNumberTable

# Google Play Core classes referenced by Flutter deferred-components support
-keep class com.google.android.play.core.** { *; }
-dontwarn com.google.android.play.core.**
