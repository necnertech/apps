import 'package:flutter/foundation.dart';
import '../../core/constants/app_constants.dart';
import '../../data/models/bootstrap_config.dart';

/// Dynamic runtime configuration.
/// Decouples client repositories from fixed production domains.
class AppConfig extends ChangeNotifier {
  String _apiBaseUrl;
  String _bootstrapOrigin;
  String _realtimeBaseUrl;
  String _minimumAppVersion;
  bool _maintenanceMode;
  bool _forceUpdate;
  String _configVersion;
  Map<String, bool> _featureFlags;

  AppConfig({
    String? initialBaseUrl,
  })  : _apiBaseUrl = _normalizeUrl(initialBaseUrl ?? AppConstants.defaultBootstrapOrigin),
        _bootstrapOrigin = _originFromApiBaseUrl(
          initialBaseUrl ?? AppConstants.defaultBootstrapOrigin,
        ),
        _realtimeBaseUrl = '',
        _minimumAppVersion = '1.0.0',
        _maintenanceMode = false,
        _forceUpdate = false,
        _configVersion = '1.0.0',
        _featureFlags = const {
          'chat': true,
          'notifications': true,
          'realtime': true,
        };

  String get apiBaseUrl => _apiBaseUrl;
  String get bootstrapOrigin => _bootstrapOrigin;
  String get realtimeBaseUrl => _realtimeBaseUrl;
  String get minimumAppVersion => _minimumAppVersion;
  bool get maintenanceMode => _maintenanceMode;
  bool get forceUpdate => _forceUpdate;
  String get configVersion => _configVersion;
  Map<String, bool> get featureFlags => _featureFlags;

  bool isFeatureEnabled(String flagName) => _featureFlags[flagName] ?? false;

  /// Updates runtime configuration dynamically from GET /mobile/config/bootstrap response.
  void updateFromBootstrap(BootstrapConfig config) {
    if (config.apiBaseUrl.isNotEmpty) {
      _apiBaseUrl = _normalizeUrl(config.apiBaseUrl);
      _bootstrapOrigin = _originFromApiBaseUrl(_apiBaseUrl);
    }
    _realtimeBaseUrl = config.realtimeBaseUrl;
    _minimumAppVersion = config.minimumAppVersion;
    _maintenanceMode = config.maintenanceMode;
    _forceUpdate = config.forceUpdate;
    _configVersion = config.configVersion;
    _featureFlags = config.featureFlags;

    notifyListeners();
  }

  /// Resolves the stable discovery origin from an API base URL.
  ///
  /// Example: https://example.com/mobile -> https://example.com
  /// This keeps bootstrap discovery separate from the normal /mobile API base.
  static String _originFromApiBaseUrl(String url) {
    final normalized = _normalizeUrl(url);
    try {
      final uri = Uri.parse(normalized);
      final pathSegments = List<String>.from(uri.pathSegments);
      if (pathSegments.isNotEmpty && pathSegments.last == 'mobile') {
        pathSegments.removeLast();
      }
      return uri.replace(pathSegments: pathSegments, query: null, fragment: null).toString().replaceFirst(RegExp(r'/$'), '');
    } catch (_) {
      return _normalizeUrl(AppConstants.defaultBootstrapOrigin);
    }
  }

  /// Normalizes URL by ensuring scheme and removing trailing slashes.
  static String _normalizeUrl(String url) {
    var trimmed = url.trim();
    while (trimmed.endsWith('/')) {
      trimmed = trimmed.substring(0, trimmed.length - 1);
    }
    if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
      trimmed = 'https://$trimmed';
    }
    return trimmed;
  }
}
