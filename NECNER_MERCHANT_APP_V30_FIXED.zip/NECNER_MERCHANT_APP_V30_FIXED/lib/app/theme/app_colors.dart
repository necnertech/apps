import 'package:flutter/material.dart';

/// WhatsApp Business-inspired color palette for the Necner Merchant App.
/// Uses the approved dark teal / emerald visual family without infringing trademarks.
class AppColors {
  const AppColors._();

  // Primary WhatsApp Business Greens & Teals
  static const Color primaryTeal = Color(0xFF075E54); // Deep brand header teal
  static const Color primaryEmerald = Color(0xFF008069); // WhatsApp Business green
  static const Color accentGreen = Color(0xFF25D366); // Vibrant action green
  static const Color secondaryTeal = Color(0xFF128C7E); // Secondary app bar tint

  // Neutral Light Canvas
  static const Color backgroundLight = Color(0xFFF7F8FA);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color borderLight = Color(0xFFE2E8F0);
  static const Color textPrimaryLight = Color(0xFF0F172A);
  static const Color textSecondaryLight = Color(0xFF64748B);

  // Neutral Dark Canvas
  static const Color backgroundDark = Color(0xFF0B141B);
  static const Color surfaceDark = Color(0xFF111B21);
  static const Color borderDark = Color(0xFF202C33);
  static const Color textPrimaryDark = Color(0xFFE9EDEF);
  static const Color textSecondaryDark = Color(0xFF8696A0);

  // Compatibility aliases used by legacy governance screens.
  static const Color primary = primaryEmerald;
  static const Color surface = surfaceLight;
  static const Color border = borderLight;
  static const Color textSecondary = textSecondaryLight;

  // Status & Badges
  static const Color badgeGreen = Color(0xFF25D366);
  static const Color badgeAmber = Color(0xFFF59E0B);
  static const Color badgeRed = Color(0xFFEF4444);
  static const Color badgeBlue = Color(0xFF3B82F6);
}
