import 'package:flutter/foundation.dart';
import '../logging/app_logger.dart';

enum VersionGateState {
  supported,
  recommendedUpdate,
  forceUpdate,
  maintenanceBlocked,
}

/// Enterprise Client-Side Remote Configuration & Governance Consumer
class RemoteConfigService extends ChangeNotifier {
  String _configVersion = 'v1.0.0';
  String _apiBaseUrl = 'https://api.necner.com';
  String _realtimeBaseUrl = 'wss://api.necner.com/realtime';
  String _minimumAppVersion = '1.0.0';
  String _recommendedAppVersion = '1.0.0';
  bool _forceUpdate = false;
  String _updateMessage = 'A new version of Necner Merchant is available.';
  bool _maintenanceMode = false;
  String _maintenanceTitle = 'System Maintenance';
  String _maintenanceMessage = 'We are performing routine upgrades.';

  Map<String, bool> _featureFlags = {
    'chat_enabled': true,
    'realtime_enabled': true,
    'notifications_enabled': true,
    'attachments_enabled': true,
    'customer_app_enabled': true,
    'merchant_app_enabled': true,
    'master_search_enabled': true,
    'global_action_center_enabled': true,
    'payment_features_enabled': true,
  };

  Map<String, Map<String, dynamic>> _serviceGovernance = {
    'doctor': {'active': true, 'merchant_enabled': true, 'customer_enabled': true, 'sort_order': 1},
    'ecommerce': {'active': true, 'merchant_enabled': true, 'customer_enabled': true, 'sort_order': 2},
    'booking': {'active': true, 'merchant_enabled': true, 'customer_enabled': true, 'sort_order': 3},
  };

  RemoteConfigService();

  // Getters
  String get configVersion => _configVersion;
  String get apiBaseUrl => _apiBaseUrl;
  String get realtimeBaseUrl => _realtimeBaseUrl;
  String get minimumAppVersion => _minimumAppVersion;
  String get recommendedAppVersion => _recommendedAppVersion;
  bool get forceUpdate => _forceUpdate;
  String get updateMessage => _updateMessage;
  bool get maintenanceMode => _maintenanceMode;
  String get maintenanceTitle => _maintenanceTitle;
  String get maintenanceMessage => _maintenanceMessage;
  Map<String, bool> get featureFlags => Map.unmodifiable(_featureFlags);
  Map<String, Map<String, dynamic>> get serviceGovernance => Map.unmodifiable(_serviceGovernance);

  /// Evaluates app version against remote policy
  VersionGateState evaluateVersionState(String currentAppVersion) {
    if (_maintenanceMode) {
      return VersionGateState.maintenanceBlocked;
    }

    final isBelowMin = _compareSemver(currentAppVersion, _minimumAppVersion) < 0;
    if (_forceUpdate || isBelowMin) {
      return VersionGateState.forceUpdate;
    }

    final isBelowRecommended = _compareSemver(currentAppVersion, _recommendedAppVersion) < 0;
    if (isBelowRecommended) {
      return VersionGateState.recommendedUpdate;
    }

    return VersionGateState.supported;
  }

  /// Checks if a feature flag is enabled
  bool isFeatureEnabled(String flagName, {bool defaultValue = true}) {
    return _featureFlags[flagName] ?? defaultValue;
  }

  /// Checks if a service is enabled in governance
  bool isServiceActive(String serviceKey, {bool forCustomer = false}) {
    final gov = _serviceGovernance[serviceKey];
    if (gov == null) return false;
    final active = gov['active'] as bool? ?? true;
    if (!active) return false;

    if (forCustomer) {
      return gov['customer_enabled'] as bool? ?? true;
    } else {
      return gov['merchant_enabled'] as bool? ?? true;
    }
  }

  /// Applies configuration dictionary from backend API
  void applyConfig(Map<String, dynamic> config) {
    if (config.containsKey('config_version')) {
      _configVersion = config['config_version'] as String;
    }
    if (config.containsKey('api_base_url')) {
      _apiBaseUrl = config['api_base_url'] as String;
    }
    if (config.containsKey('realtime_base_url')) {
      _realtimeBaseUrl = config['realtime_base_url'] as String;
    }
    if (config.containsKey('minimum_app_version')) {
      _minimumAppVersion = config['minimum_app_version'] as String;
    }
    if (config.containsKey('recommended_app_version')) {
      _recommendedAppVersion = config['recommended_app_version'] as String;
    }
    if (config.containsKey('force_update')) {
      _forceUpdate = config['force_update'] as bool? ?? false;
    }
    if (config.containsKey('update_message')) {
      _updateMessage = config['update_message'] as String? ?? _updateMessage;
    }
    if (config.containsKey('maintenance_mode')) {
      _maintenanceMode = config['maintenance_mode'] as bool? ?? false;
    }
    if (config.containsKey('maintenance_title')) {
      _maintenanceTitle = config['maintenance_title'] as String? ?? _maintenanceTitle;
    }
    if (config.containsKey('maintenance_message')) {
      _maintenanceMessage = config['maintenance_message'] as String? ?? _maintenanceMessage;
    }

    if (config['feature_flags'] is Map) {
      final flags = config['feature_flags'] as Map;
      _featureFlags = flags.map((k, v) => MapEntry(k.toString(), v == true));
    }

    if (config['service_governance'] is Map) {
      final sGov = config['service_governance'] as Map;
      _serviceGovernance = sGov.map((k, v) {
        if (v is Map) {
          return MapEntry(k.toString(), Map<String, dynamic>.from(v));
        }
        return MapEntry(k.toString(), <String, dynamic>{});
      });
    }

    AppLogger.info('RemoteConfigService applied new configuration version: $_configVersion');
    notifyListeners();
  }

  /// Helper to compare two semantic versions: returns -1 if v1 < v2, 0 if v1 == v2, 1 if v1 > v2
  int _compareSemver(String v1, String v2) {
    try {
      final clean1 = v1.split('-').first.replaceAll(RegExp(r'[^0-9\.]'), '');
      final clean2 = v2.split('-').first.replaceAll(RegExp(r'[^0-9\.]'), '');
      final parts1 = clean1.split('.').map((p) => int.tryParse(p) ?? 0).toList();
      final parts2 = clean2.split('.').map((p) => int.tryParse(p) ?? 0).toList();

      while (parts1.length < 3) {
        parts1.add(0);
      }
      while (parts2.length < 3) {
        parts2.add(0);
      }

      for (var i = 0; i < 3; i++) {
        if (parts1[i] < parts2[i]) return -1;
        if (parts1[i] > parts2[i]) return 1;
      }
      return 0;
    } catch (_) {
      return 0;
    }
  }
}
