import 'package:flutter/material.dart';
import '../../data/models/module_schema_models.dart';
import '../permissions/permission_evaluator.dart';

class EntityLink {
  final String label;
  final String entityType;
  final String entityId;
  final String serviceKey;
  final String moduleKey;
  final IconData icon;

  const EntityLink({
    required this.label,
    required this.entityType,
    required this.entityId,
    required this.serviceKey,
    required this.moduleKey,
    required this.icon,
  });
}

class EntityRelationshipResolver {
  /// Extracts contextual related entity links from an entity's data payload
  static List<EntityLink> resolveLinks({
    required String serviceKey,
    required String moduleKey,
    required EntityRecord record,
    required PermissionEvaluator evaluator,
  }) {
    final links = <EntityLink>[];
    final data = record.data;

    // 1. Order relationships (Order -> Customer / Chat, Order -> Invoice)
    if (moduleKey == 'orders' || serviceKey == 'ecommerce') {
      if (data['customer_id'] != null || data['customer_name'] != null) {
        final custName = data['customer_name']?.toString() ?? 'Customer';
        links.add(
          EntityLink(
            label: 'Message $custName',
            entityType: 'chat',
            entityId: data['chat_id']?.toString() ?? '1',
            serviceKey: serviceKey,
            moduleKey: 'chat',
            icon: Icons.chat_bubble_outline,
          ),
        );
      }
      if (data['invoice_id'] != null) {
        links.add(
          EntityLink(
            label: 'Invoice #${data['invoice_id']}',
            entityType: 'payment',
            entityId: data['invoice_id'].toString(),
            serviceKey: serviceKey,
            moduleKey: 'payments',
            icon: Icons.receipt_long,
          ),
        );
      }
    }

    // 2. Appointment relationships (Appointment -> Patient, Appointment -> Doctor)
    if (moduleKey == 'appointments' || serviceKey == 'doctor') {
      if (data['patient_id'] != null || data['patient_name'] != null) {
        final patName = data['patient_name']?.toString() ?? 'Patient';
        links.add(
          EntityLink(
            label: 'Patient: $patName',
            entityType: 'patient',
            entityId: data['patient_id']?.toString() ?? 'pat_1',
            serviceKey: 'doctor',
            moduleKey: 'patients',
            icon: Icons.person_outline,
          ),
        );
        links.add(
          EntityLink(
            label: 'Chat with $patName',
            entityType: 'chat',
            entityId: '1',
            serviceKey: 'doctor',
            moduleKey: 'chat',
            icon: Icons.chat_bubble_outline,
          ),
        );
      }
    }

    // Filter links based on whether user has permission to view that service
    return links.where((link) {
      if (link.entityType == 'chat') return true;
      return evaluator.isServiceAssigned(link.serviceKey);
    }).toList();
  }
}
