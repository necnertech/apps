import 'package:flutter/foundation.dart';

/// Privacy-safe application logger.
/// Invariants:
/// - Strictly disables debug logging in release mode (kReleaseMode).
/// - Scrubs passwords, access tokens, refresh tokens, and Authorization headers.
class AppLogger {
  const AppLogger._();

  static void info(String message, {String tag = 'NecnerApp'}) {
    if (kReleaseMode) return;
    debugPrint('[$tag][INFO] ${_sanitize(message)}');
  }

  static void warning(String message, {String tag = 'NecnerApp'}) {
    if (kReleaseMode) return;
    debugPrint('[$tag][WARN] ${_sanitize(message)}');
  }

  static void error(String message, {dynamic error, StackTrace? stackTrace, String tag = 'NecnerApp'}) {
    if (kReleaseMode) return;
    debugPrint('[$tag][ERROR] ${_sanitize(message)}');
    if (error != null) {
      debugPrint('[$tag][ERROR_DETAIL] ${_sanitize(error.toString())}');
    }
  }

  /// Scrubs sensitive tokens, passwords, and authorization headers from log strings
  static String _sanitize(String input) {
    var output = input;
    // Scrub Bearer tokens
    output = output.replaceAll(RegExp(r'Bearer\s+[A-Za-z0-9\-\._~\+\/]+=*', caseSensitive: false), 'Bearer [REDACTED_TOKEN]');
    // Scrub password parameters
    output = output.replaceAll(RegExp(r'"password"\s*:\s*"[^"]*"', caseSensitive: false), '"password":"[REDACTED_PASSWORD]"');
    // Scrub refresh tokens
    output = output.replaceAll(RegExp(r'"refresh_token"\s*:\s*"[^"]*"', caseSensitive: false), '"refresh_token":"[REDACTED_TOKEN]"');
    // Scrub access tokens
    output = output.replaceAll(RegExp(r'"access_token"\s*:\s*"[^"]*"', caseSensitive: false), '"access_token":"[REDACTED_TOKEN]"');
    return output;
  }
}
