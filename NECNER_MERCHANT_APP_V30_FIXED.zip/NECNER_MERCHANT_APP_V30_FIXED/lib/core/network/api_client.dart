import 'package:flutter/foundation.dart';
import 'package:dio/dio.dart';
import '../../app/config/app_config.dart';
import '../constants/app_constants.dart';
import '../errors/app_exception.dart';
import '../errors/error_codes.dart';
import '../logging/app_logger.dart';
import '../result/result.dart';
import '../secure_storage/secure_storage_service.dart';
import 'auth_interceptor.dart';

/// Single, production-grade reusable API client for the Necner Merchant app.
/// Consumes the Phase 2 backend contracts with dynamic URL binding and safe error mapping.
class ApiClient {
  late final Dio _dio;
  final AppConfig _config;
  final SecureStorageService _storage;
  final VoidCallback _onSessionExpired;

  ApiClient({
    required AppConfig config,
    required SecureStorageService storage,
    required VoidCallback onSessionExpired,
    Dio? customDio,
  })  : _config = config,
        _storage = storage,
        _onSessionExpired = onSessionExpired {
    _dio = customDio ??
        Dio(
          BaseOptions(
            baseUrl: _config.apiBaseUrl,
            connectTimeout: AppConstants.connectTimeout,
            receiveTimeout: AppConstants.receiveTimeout,
            sendTimeout: AppConstants.sendTimeout,
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
              'X-Device-Platform': defaultTargetPlatform == TargetPlatform.iOS ? 'ios' : 'android',
              'X-App-Version': AppConstants.defaultAppVersion,
            },
          ),
        );

    // Attach single-flight mutex refresh interceptor
    _dio.interceptors.add(
      AuthInterceptor(
        storage: _storage,
        onSessionExpired: _onSessionExpired,
      ),
    );

    // Update Dio base URL whenever AppConfig updates from Bootstrap
    _config.addListener(() {
      _dio.options.baseUrl = _config.apiBaseUrl;
      AppLogger.info('ApiClient baseUrl updated dynamically to: ${_config.apiBaseUrl}');
    });
  }

  Dio get dioInstance => _dio;

  /// Fetches bootstrap configuration from the discovery origin, never from
  /// the normal /mobile API base URL. This prevents /mobile/mobile/... URLs
  /// when a cached API base is restored at app startup.
  Future<Result<T>> getBootstrap<T>(
    String path, {
    required T Function(dynamic data) parser,
    CancelToken? cancelToken,
  }) async {
    try {
      final origin = _config.bootstrapOrigin;
      final bootstrapUrl = Uri.parse('$origin$path');
      AppLogger.info('Bootstrap request URL: $bootstrapUrl');
      final res = await _dio.getUri(
        bootstrapUrl,
        options: Options(extra: {'skipAuth': true}),
        cancelToken: cancelToken,
      );
      return _parseResponse<T>(res.data, parser, res.statusCode, requestPath: bootstrapUrl.toString());
    } on DioException catch (e) {
      return Result.failure(_mapDioException(e));
    } catch (_) {
      return Result.failure(
        AppException(
          errorCode: ErrorCodes.internalError,
          message: 'An unexpected error occurred.',
        ),
      );
    }
  }

  /// HTTP GET
  Future<Result<T>> get<T>(
    String path, {
    Map<String, dynamic>? queryParameters,
    bool skipAuth = false,
    required T Function(dynamic data) parser,
    CancelToken? cancelToken,
  }) async {
    try {
      final res = await _dio.get(
        _normalizeApiPath(path),
        queryParameters: queryParameters,
        options: Options(extra: {'skipAuth': skipAuth}),
        cancelToken: cancelToken,
      );
      return _parseResponse<T>(res.data, parser, res.statusCode, requestPath: _normalizeApiPath(path));
    } on DioException catch (e) {
      return Result.failure(_mapDioException(e));
    } catch (e, st) {
      AppLogger.error('Unexpected GET failure for ${_normalizeApiPath(path)}: $e\n$st');
      return Result.failure(
        const AppException(
          errorCode: ErrorCodes.internalError,
          message: 'An unexpected error occurred.',
        ),
      );
    }
  }

  /// HTTP POST
  Future<Result<T>> post<T>(
    String path, {
    dynamic data,
    Map<String, dynamic>? queryParameters,
    bool skipAuth = false,
    required T Function(dynamic data) parser,
    CancelToken? cancelToken,
  }) async {
    try {
      final res = await _dio.post(
        _normalizeApiPath(path),
        data: data,
        queryParameters: queryParameters,
        options: Options(extra: {'skipAuth': skipAuth}),
        cancelToken: cancelToken,
      );
      return _parseResponse<T>(res.data, parser, res.statusCode, requestPath: _normalizeApiPath(path));
    } on DioException catch (e) {
      return Result.failure(_mapDioException(e));
    } catch (e, st) {
      AppLogger.error('Unexpected POST failure for ${_normalizeApiPath(path)}: $e\n$st');
      return Result.failure(
        const AppException(
          errorCode: ErrorCodes.internalError,
          message: 'An unexpected error occurred.',
        ),
      );
    }
  }

  String _normalizeApiPath(String path) {
    final normalizedPath = path.trim();
    final base = Uri.tryParse(_config.apiBaseUrl);
    if (base != null && base.pathSegments.isNotEmpty) {
      final baseSegments = List<String>.from(base.pathSegments);
      if (baseSegments.last == 'mobile' && normalizedPath.startsWith('/mobile/')) {
        return normalizedPath.substring('/mobile'.length);
      }
    }
    return normalizedPath;
  }

  /// Parses the standard Phase 1 / Phase 2 envelope:
  /// { "success": true, "data": ... } or { "success": false, "error_code": ... }
  Result<T> _parseResponse<T>(
    dynamic body,
    T Function(dynamic data) parser,
    int? statusCode, {
    String? requestPath,
  }) {
    try {
      if (body is Map<String, dynamic>) {
        if (body['success'] == true) {
          final data = body.containsKey('data') ? body['data'] : body;
          final parsed = parser(data);
          return Result.success(parsed);
        }
        return Result.failure(AppException.fromJson(body, statusCode: statusCode));
      }

      return Result.failure(
        AppException(
          errorCode: ErrorCodes.invalidRequest,
          message: 'Invalid response format received from server.',
          statusCode: statusCode,
        ),
      );
    } catch (e, st) {
      AppLogger.error(
        'API response parsing failed for ${requestPath ?? 'unknown endpoint'} '
        '(HTTP ${statusCode ?? 'unknown'}): $e\n$st',
      );
      return Result.failure(
        const AppException(
          errorCode: ErrorCodes.invalidRequest,
          message: 'The server returned data the app could not read. Please retry.',
        ),
      );
    }
  }

  /// Maps Dio exceptions to safe AppException representations
  AppException _mapDioException(DioException e) {
    if (e.type == DioExceptionType.connectionTimeout ||
        e.type == DioExceptionType.receiveTimeout ||
        e.type == DioExceptionType.sendTimeout) {
      return AppException.timeout();
    }

    if (e.type == DioExceptionType.connectionError) {
      return AppException.offline();
    }

    final response = e.response;
    AppLogger.error('API request failed: ${e.requestOptions.method} ${e.requestOptions.path} -> ${response?.statusCode ?? 'no-status'}');
    if (response?.data is Map<String, dynamic>) {
      return AppException.fromJson(
        response!.data as Map<String, dynamic>,
        statusCode: response.statusCode,
      );
    }

    return AppException(
      errorCode: ErrorCodes.internalError,
      message: 'Server communication error (${response?.statusCode ?? 'unknown'}).',
      statusCode: response?.statusCode,
    );
  }
}
