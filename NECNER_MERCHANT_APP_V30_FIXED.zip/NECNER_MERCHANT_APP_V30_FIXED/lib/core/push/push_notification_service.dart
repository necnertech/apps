import 'dart:async';
import 'package:flutter/foundation.dart';
import '../../data/models/notification_models.dart';
import '../../data/repositories/notification_repository.dart';
import '../logging/app_logger.dart';
import '../utils/device_service.dart';

/// Native Push Bridge for APNs (iOS) and FCM (Android)
class PushNotificationService extends ChangeNotifier {
  final NotificationRepository _repository;
  final DeviceService _deviceService;

  final StreamController<String> _deepLinkController = StreamController<String>.broadcast();
  final StreamController<PushNotificationItem> _foregroundNotificationController =
      StreamController<PushNotificationItem>.broadcast();

  String? _registeredToken;
  bool _isRegistered = false;

  PushNotificationService({
    required NotificationRepository repository,
    required DeviceService deviceService,
  })  : _repository = repository,
        _deviceService = deviceService;

  bool get isRegistered => _isRegistered;
  String? get registeredToken => _registeredToken;
  Stream<String> get onDeepLink => _deepLinkController.stream;
  Stream<PushNotificationItem> get onForegroundNotification =>
      _foregroundNotificationController.stream;

  /// Initializes native push tokens and registers with the Necner backend gateway
  Future<void> initializeAndRegister() async {
    try {
      final deviceId = await _deviceService.getDeviceId();
      final platform = _deviceService.getPlatformName();
      final provider = platform == 'ios' ? 'apns' : 'fcm';

      // No fake FCM/APNs token is generated. Real background push requires
      // the platform provider credentials/configuration. Fast foreground
      // notification delivery is provided by the authenticated 3-second poll.
      AppLogger.info('Registering device for notification delivery on $platform ($provider)...');

      final result = await _repository.registerDeviceToken(
        deviceId: deviceId,
        platform: platform,
        pushToken: '',
        tokenProvider: provider,
      );

      result.when(
        success: (_) {
          _registeredToken = null;
          _isRegistered = true;
          AppLogger.info('Native push bridge successfully registered with backend gateway.');
          notifyListeners();
        },
        failure: (err) {
          AppLogger.error('Failed to register native push token: ${err.message}');
        },
      );
    } catch (e) {
      AppLogger.error('Error during push initialization: $e');
    }
  }

  /// Handles incoming push notification payload (from foreground or background tap)
  void handleIncomingPayload(Map<String, dynamic> data) {
    AppLogger.info('Incoming Push Payload received: $data');

    final notification = PushNotificationItem.fromJson(data);
    _foregroundNotificationController.add(notification);

    if (notification.deepLink != null && notification.deepLink!.isNotEmpty) {
      _deepLinkController.add(notification.deepLink!);
    }
  }

  /// Parses and navigates a deep link string
  /// Supported schemes:
  /// - necner://chat/{chat_id}
  /// - necner://services/{service_key}
  /// - necner://notifications/{id}
  static String? resolveRouteFromDeepLink(String deepLink) {
    if (!deepLink.startsWith('necner://')) return null;

    final uri = Uri.tryParse(deepLink);
    if (uri == null) return null;

    final path = uri.host + uri.path;

    if (path.startsWith('chat/')) {
      final chatId = path.replaceFirst('chat/', '');
      return '/chats/$chatId';
    } else if (path.startsWith('services/')) {
      final serviceKey = path.replaceFirst('services/', '');
      return '/services/$serviceKey';
    } else if (path.startsWith('notifications/')) {
      return '/notifications';
    }

    return '/chats';
  }

  @override
  void dispose() {
    _deepLinkController.close();
    _foregroundNotificationController.close();
    super.dispose();
  }
}
