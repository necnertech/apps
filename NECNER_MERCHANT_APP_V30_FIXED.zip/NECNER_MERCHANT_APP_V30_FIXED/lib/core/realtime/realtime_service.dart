import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import '../../data/models/chat_models.dart';
import '../logging/app_logger.dart';
import '../network/api_client.dart';

enum RealtimeConnectionState {
  disconnected,
  connecting,
  connected,
  reconnecting,
}

/// Realtime Event Payload
class RealtimeEvent {
  final String eventId;
  final String eventType;
  final Map<String, dynamic> data;
  final DateTime timestamp;
  final String? serviceKey;
  final String? entityType;
  final String? entityId;

  RealtimeEvent({
    String? eventId,
    required this.eventType,
    required this.data,
    DateTime? timestamp,
    this.serviceKey,
    this.entityType,
    this.entityId,
  })  : eventId = eventId ?? 'evt_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(9999)}',
        timestamp = timestamp ?? DateTime.now();

  factory RealtimeEvent.fromJson(Map<String, dynamic> json) {
    return RealtimeEvent(
      eventId: json['event_id']?.toString(),
      eventType: json['event_type']?.toString() ?? 'system.update',
      data: json['data'] is Map ? Map<String, dynamic>.from(json['data'] as Map) : (json['payload'] is Map ? Map<String, dynamic>.from(json['payload'] as Map) : {}),
      timestamp: DateTime.tryParse(json['timestamp']?.toString() ?? json['created_at']?.toString() ?? '') ?? DateTime.now(),
      serviceKey: json['service_key']?.toString(),
      entityType: json['entity_type']?.toString(),
      entityId: json['entity_id']?.toString(),
    );
  }
}

/// Hardened Realtime Service with Checkpoint Recovery, Deduplication & Reconnect Backoff
class RealtimeService extends ChangeNotifier {
  final ApiClient? _apiClient;
  final StreamController<RealtimeEvent> _eventStreamController =
      StreamController<RealtimeEvent>.broadcast();

  RealtimeConnectionState _state = RealtimeConnectionState.disconnected;
  String? _currentUrl;
  String? _lastEventId;
  String? _lastCheckpoint;
  int _reconnectAttempts = 0;
  Timer? _reconnectTimer;

  // Sliding window set for event deduplication
  final Set<String> _processedEventIds = {};
  static const int _maxDeduplicationWindow = 300;

  RealtimeService({ApiClient? apiClient}) : _apiClient = apiClient;

  bool get isConnected => _state == RealtimeConnectionState.connected;
  RealtimeConnectionState get state => _state;
  Stream<RealtimeEvent> get eventStream => _eventStreamController.stream;
  String? get lastEventId => _lastEventId;

  /// Connects to realtime transport (SSE / WebSocket)
  void connect(String realtimeUrl) {
    if (_state == RealtimeConnectionState.connected && _currentUrl == realtimeUrl) return;

    _currentUrl = realtimeUrl;
    _state = RealtimeConnectionState.connecting;
    notifyListeners();

    AppLogger.info('Connecting to Realtime Gateway: $realtimeUrl...');

    // Simulate reliable connection handshake
    _state = RealtimeConnectionState.connected;
    _reconnectAttempts = 0;
    _reconnectTimer?.cancel();
    _lastCheckpoint = DateTime.now().toIso8601String();
    AppLogger.info('Connected to Realtime Gateway. Checkpoint: $_lastCheckpoint');
    notifyListeners();

    // Trigger checkpoint sync if we have a last checkpoint
    _syncMissedEvents();
  }

  /// Disconnects from realtime transport
  void disconnect() {
    _state = RealtimeConnectionState.disconnected;
    _currentUrl = null;
    _reconnectTimer?.cancel();
    AppLogger.info('Disconnected from Realtime Gateway.');
    notifyListeners();
  }

  /// Handles transport drop with exponential backoff & jitter
  void handleTransportDrop() {
    if (_state == RealtimeConnectionState.disconnected) return;

    _state = RealtimeConnectionState.reconnecting;
    notifyListeners();

    _reconnectAttempts++;
    final backoffSeconds = min(30, pow(2, min(_reconnectAttempts, 5)).toInt());
    final jitterMs = Random().nextInt(1000);
    final delay = Duration(seconds: backoffSeconds, milliseconds: jitterMs);

    AppLogger.warning('Realtime disconnected. Reconnecting in ${backoffSeconds}s (attempt #$_reconnectAttempts)...');

    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(delay, () {
      if (_currentUrl != null) {
        connect(_currentUrl!);
      }
    });
  }

  /// Broadcasts an event locally with automatic deduplication
  void dispatchEvent(
    String eventType,
    Map<String, dynamic> data, {
    String? eventId,
    String? serviceKey,
    String? entityType,
    String? entityId,
  }) {
    final resolvedEventId = eventId ?? 'evt_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(9999)}';

    // Event deduplication check
    if (_processedEventIds.contains(resolvedEventId)) {
      AppLogger.info('Deduplicating already processed event: $resolvedEventId ($eventType)');
      return;
    }

    _recordProcessedEventId(resolvedEventId);
    _lastEventId = resolvedEventId;
    _lastCheckpoint = DateTime.now().toIso8601String();

    AppLogger.info('Realtime Event Received: $eventType [$resolvedEventId]');

    _eventStreamController.add(
      RealtimeEvent(
        eventId: resolvedEventId,
        eventType: eventType,
        data: data,
        serviceKey: serviceKey,
        entityType: entityType,
        entityId: entityId,
      ),
    );
  }

  /// Simulates an incoming customer message in real-time
  void simulateIncomingMessage({
    required String chatId,
    required String customerName,
    required String content,
    String type = 'text',
    Map<String, dynamic>? metadata,
    String? eventId,
  }) {
    final msg = ChatMessageItem(
      id: 'msg_rt_${DateTime.now().millisecondsSinceEpoch}',
      chatId: chatId,
      senderType: 'customer',
      senderId: 'cust_incoming',
      senderName: customerName,
      type: type,
      content: content,
      metadata: metadata ?? {},
      deliveryStatus: MessageDeliveryStatus.delivered,
      createdAt: DateTime.now().toIso8601String().substring(0, 19).replaceAll('T', ' '),
    );

    dispatchEvent(
      'chat.message_received',
      {
        'chat_id': chatId,
        'message': msg.toJson(),
      },
      eventId: eventId,
      serviceKey: 'chat',
      entityType: 'chat',
      entityId: chatId,
    );
  }

  /// Fetches missed events from the server during offline/disconnect gap
  Future<void> _syncMissedEvents() async {
    if (_apiClient == null) return;

    try {
      final queryParams = <String, dynamic>{};
      if (_lastEventId != null && _lastEventId!.isNotEmpty) {
        queryParams['last_event_id'] = _lastEventId;
      } else if (_lastCheckpoint != null) {
        queryParams['since_checkpoint'] = _lastCheckpoint;
      }

      final result = await _apiClient.get<Map<String, dynamic>>(
        '/mobile/events/sync.php',
        queryParameters: queryParams,
        parser: (data) => data is Map<String, dynamic> ? data : {},
      );

      result.when(
        success: (res) {
          final missed = res['events'] as List<dynamic>? ?? [];
          if (missed.isNotEmpty) {
            AppLogger.info('Reconciled ${missed.length} missed events since checkpoint.');
            for (final raw in missed) {
              if (raw is Map<String, dynamic>) {
                final evt = RealtimeEvent.fromJson(raw);
                dispatchEvent(
                  evt.eventType,
                  evt.data,
                  eventId: evt.eventId,
                  serviceKey: evt.serviceKey,
                  entityType: evt.entityType,
                  entityId: evt.entityId,
                );
              }
            }
          }
          if (res['latest_event_id'] != null) {
            _lastEventId = res['latest_event_id'].toString();
          }
        },
        failure: (err) {
          AppLogger.error('Failed to sync missed events: ${err.message}');
        },
      );
    } catch (e) {
      AppLogger.error('Error syncing events: $e');
    }
  }

  void _recordProcessedEventId(String id) {
    _processedEventIds.add(id);
    if (_processedEventIds.length > _maxDeduplicationWindow) {
      _processedEventIds.remove(_processedEventIds.first);
    }
  }

  @override
  void dispose() {
    _reconnectTimer?.cancel();
    _eventStreamController.close();
    super.dispose();
  }
}
