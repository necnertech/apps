/// Merchant Activity Feed Models
class MerchantActivityItem {
  final String id;
  final String title;
  final String description;
  final String serviceKey;
  final String actorName;
  final String timestamp;
  final String entityType;
  final String entityId;
  final String? reference;

  const MerchantActivityItem({
    required this.id,
    required this.title,
    required this.description,
    required this.serviceKey,
    required this.actorName,
    required this.timestamp,
    required this.entityType,
    required this.entityId,
    this.reference,
  });

  factory MerchantActivityItem.fromJson(Map<String, dynamic> json) {
    return MerchantActivityItem(
      id: json['id']?.toString() ?? '',
      title: json['title']?.toString() ?? 'Activity',
      description: json['description']?.toString() ?? '',
      serviceKey: json['service_key']?.toString() ?? 'general',
      actorName: json['actor_name']?.toString() ?? 'System',
      timestamp: json['timestamp']?.toString() ?? '',
      entityType: json['entity_type']?.toString() ?? 'record',
      entityId: json['entity_id']?.toString() ?? '',
      reference: json['reference']?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'service_key': serviceKey,
    'actor_name': actorName,
    'timestamp': timestamp,
    'entity_type': entityType,
    'entity_id': entityId,
    'reference': reference,
  };
}
