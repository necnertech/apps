/// Models for WhatsApp Business-Inspired Messaging in Necner Merchant App
/// Complies with Phase 1 freeze and Phase 2 backend contracts.
library;

class ConversationSummary {
  final String id;
  final String conversationKey;
  final String customerName;
  final String customerPhone;
  final String serviceKey;
  final String serviceLabel;
  final String lastMessage;
  final String lastMessageTime;
  final int unreadCount;
  final String? customerAvatarUrl;

  const ConversationSummary({
    required this.id,
    required this.conversationKey,
    required this.customerName,
    required this.customerPhone,
    required this.serviceKey,
    required this.serviceLabel,
    required this.lastMessage,
    required this.lastMessageTime,
    required this.unreadCount,
    this.customerAvatarUrl,
  });

  factory ConversationSummary.fromJson(Map<String, dynamic> json) {
    return ConversationSummary(
      id: json['id']?.toString() ?? '',
      conversationKey: json['conversation_key']?.toString() ?? '',
      customerName: json['customer_name']?.toString() ?? 'Customer',
      customerPhone: json['customer_phone']?.toString() ?? '',
      serviceKey: json['service_key']?.toString() ?? 'general',
      serviceLabel: json['service_label']?.toString() ?? 'Service',
      lastMessage: json['last_message']?.toString() ?? '',
      lastMessageTime: json['last_message_time']?.toString() ?? '',
      unreadCount: (json['unread_count'] as num?)?.toInt() ?? 0,
      customerAvatarUrl: (json['customer_avatar_url'] ?? json['avatar_url'] ?? json['profile_image_url'])?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'conversation_key': conversationKey,
    'customer_name': customerName,
    'customer_phone': customerPhone,
    'service_key': serviceKey,
    'service_label': serviceLabel,
    'last_message': lastMessage,
    'last_message_time': lastMessageTime,
    'unread_count': unreadCount,
    'customer_avatar_url': customerAvatarUrl,
  };

  ConversationSummary copyWith({
    String? id,
    String? conversationKey,
    String? customerName,
    String? customerPhone,
    String? serviceKey,
    String? serviceLabel,
    String? lastMessage,
    String? lastMessageTime,
    int? unreadCount,
    String? customerAvatarUrl,
  }) {
    return ConversationSummary(
      id: id ?? this.id,
      conversationKey: conversationKey ?? this.conversationKey,
      customerName: customerName ?? this.customerName,
      customerPhone: customerPhone ?? this.customerPhone,
      serviceKey: serviceKey ?? this.serviceKey,
      serviceLabel: serviceLabel ?? this.serviceLabel,
      lastMessage: lastMessage ?? this.lastMessage,
      lastMessageTime: lastMessageTime ?? this.lastMessageTime,
      unreadCount: unreadCount ?? this.unreadCount,
      customerAvatarUrl: customerAvatarUrl ?? this.customerAvatarUrl,
    );
  }
}

enum MessageDeliveryStatus {
  sending,
  sent,
  delivered,
  read,
}

class ChatMessageItem {
  final String id;
  final String chatId;
  final String senderType; // 'merchant' | 'customer' | 'system'
  final String senderId;
  final String senderName;
  final String type; // 'text' | 'voice' | 'order' | 'appointment' | 'payment' | 'image'
  final String content;
  final Map<String, dynamic> metadata;
  final MessageDeliveryStatus deliveryStatus;
  final String createdAt;

  const ChatMessageItem({
    required this.id,
    required this.chatId,
    required this.senderType,
    required this.senderId,
    required this.senderName,
    required this.type,
    required this.content,
    required this.metadata,
    required this.deliveryStatus,
    required this.createdAt,
  });

  bool get isMerchant => senderType == 'merchant';
  bool get isSystem => senderType == 'system';
  bool get isCustomer => senderType == 'customer';

  factory ChatMessageItem.fromJson(Map<String, dynamic> json) {
    MessageDeliveryStatus status = MessageDeliveryStatus.sent;
    final statusStr = json['delivery_status']?.toString().toLowerCase();
    if (statusStr == 'sending') {
      status = MessageDeliveryStatus.sending;
    } else if (statusStr == 'delivered') {
      status = MessageDeliveryStatus.delivered;
    } else if (statusStr == 'read') {
      status = MessageDeliveryStatus.read;
    }

    Map<String, dynamic> meta = {};
    if (json['metadata'] is Map) {
      meta = Map<String, dynamic>.from(json['metadata'] as Map);
    }

    return ChatMessageItem(
      id: json['id']?.toString() ?? '',
      chatId: json['chat_id']?.toString() ?? '',
      senderType: json['sender_type']?.toString() ?? 'customer',
      senderId: json['sender_id']?.toString() ?? '',
      senderName: json['sender_name']?.toString() ?? 'Unknown',
      type: json['type']?.toString() ?? 'text',
      content: json['content']?.toString() ?? '',
      metadata: meta,
      deliveryStatus: status,
      createdAt: json['created_at']?.toString() ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'chat_id': chatId,
    'sender_type': senderType,
    'sender_id': senderId,
    'sender_name': senderName,
    'type': type,
    'content': content,
    'metadata': metadata,
    'delivery_status': deliveryStatus.name,
    'created_at': createdAt,
  };

  ChatMessageItem copyWith({
    String? id,
    String? chatId,
    String? senderType,
    String? senderId,
    String? senderName,
    String? type,
    String? content,
    Map<String, dynamic>? metadata,
    MessageDeliveryStatus? deliveryStatus,
    String? createdAt,
  }) {
    return ChatMessageItem(
      id: id ?? this.id,
      chatId: chatId ?? this.chatId,
      senderType: senderType ?? this.senderType,
      senderId: senderId ?? this.senderId,
      senderName: senderName ?? this.senderName,
      type: type ?? this.type,
      content: content ?? this.content,
      metadata: metadata ?? this.metadata,
      deliveryStatus: deliveryStatus ?? this.deliveryStatus,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

/// Metadata model for Order Cards inside chat
class OrderCardData {
  final String orderId;
  final String orderNumber;
  final String customerName;
  final String itemsSummary;
  final double totalAmount;
  final String currency;
  final String status;

  const OrderCardData({
    required this.orderId,
    required this.orderNumber,
    required this.customerName,
    required this.itemsSummary,
    required this.totalAmount,
    this.currency = 'USD',
    required this.status,
  });

  factory OrderCardData.fromMap(Map<String, dynamic> map) {
    return OrderCardData(
      orderId: map['order_id']?.toString() ?? map['orderId']?.toString() ?? '10045',
      orderNumber: map['order_number']?.toString() ?? map['orderNumber']?.toString() ?? '#10045',
      customerName: map['customer_name']?.toString() ?? map['customerName']?.toString() ?? 'Customer',
      itemsSummary: map['items_summary']?.toString() ?? map['items']?.toString() ?? '3 items (Medications)',
      totalAmount: (map['total_amount'] as num?)?.toDouble() ?? (map['total'] as num?)?.toDouble() ?? 45.50,
      currency: map['currency']?.toString() ?? 'USD',
      status: map['status']?.toString() ?? 'ready_for_pickup',
    );
  }
}

/// Metadata model for Appointment Cards inside chat
class AppointmentCardData {
  final String appointmentId;
  final String serviceName;
  final String doctorName;
  final String dateTimeString;
  final String status;

  const AppointmentCardData({
    required this.appointmentId,
    required this.serviceName,
    required this.doctorName,
    required this.dateTimeString,
    required this.status,
  });

  factory AppointmentCardData.fromMap(Map<String, dynamic> map) {
    return AppointmentCardData(
      appointmentId: map['appointment_id']?.toString() ?? map['id']?.toString() ?? '8042',
      serviceName: map['service_name']?.toString() ?? map['service']?.toString() ?? 'Follow-up Consultation',
      doctorName: map['doctor_name']?.toString() ?? map['doctor']?.toString() ?? 'Dr. Alena Vance',
      dateTimeString: map['date']?.toString() ?? map['dateTime']?.toString() ?? 'Tomorrow 10:30 AM',
      status: map['status']?.toString() ?? 'confirmed',
    );
  }
}

/// Metadata model for Payment Cards inside chat
class PaymentCardData {
  final String invoiceNumber;
  final double amount;
  final String currency;
  final String status;
  final String dueDate;

  const PaymentCardData({
    required this.invoiceNumber,
    required this.amount,
    this.currency = 'USD',
    required this.status,
    required this.dueDate,
  });

  factory PaymentCardData.fromMap(Map<String, dynamic> map) {
    return PaymentCardData(
      invoiceNumber: map['invoice_number']?.toString() ?? map['invoice']?.toString() ?? 'INV-2026-092',
      amount: (map['amount'] as num?)?.toDouble() ?? 120.00,
      currency: map['currency']?.toString() ?? 'USD',
      status: map['status']?.toString() ?? 'pending',
      dueDate: map['due_date']?.toString() ?? map['due']?.toString() ?? 'Today',
    );
  }
}
