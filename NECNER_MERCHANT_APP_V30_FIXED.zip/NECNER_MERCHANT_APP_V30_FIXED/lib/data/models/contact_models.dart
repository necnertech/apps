import 'package:flutter/foundation.dart';

@immutable
class MerchantContact {
  final int id;
  final String name;
  final String phone;
  final String email;
  final String status;
  final String optInStatus;
  final String? avatarUrl;

  const MerchantContact({
    required this.id,
    required this.name,
    required this.phone,
    required this.email,
    required this.status,
    required this.optInStatus,
    this.avatarUrl,
  });

  factory MerchantContact.fromJson(Map<String, dynamic> json) {
    final avatar = (json['avatar_url'] ??
            json['profile_image_url'] ??
            json['image_url'] ??
            json['photo_url'])
        ?.toString()
        .trim();
    return MerchantContact(
      id: int.tryParse(json['id']?.toString() ?? '') ?? 0,
      name: (json['name'] ?? '').toString().trim(),
      phone: (json['phone'] ?? '').toString().trim(),
      email: (json['email'] ?? '').toString().trim(),
      status: (json['status'] ?? 'active').toString(),
      optInStatus: (json['opt_in_status'] ?? 'opted_in').toString(),
      avatarUrl: avatar == null || avatar.isEmpty ? null : avatar,
    );
  }
}
