import 'package:flutter/foundation.dart';

enum FieldType {
  text,
  multiline,
  number,
  currency,
  date,
  time,
  boolean,
  select,
  fileAttachment,
}

@immutable
class FieldDefinition {
  final String key;
  final String label;
  final FieldType type;
  final bool required;
  final String? placeholder;
  final String? defaultValue;
  final List<String>? options; // For select / dropdown
  final num? min;
  final num? max;

  const FieldDefinition({
    required this.key,
    required this.label,
    required this.type,
    this.required = false,
    this.placeholder,
    this.defaultValue,
    this.options,
    this.min,
    this.max,
  });

  factory FieldDefinition.fromJson(Map<String, dynamic> json) {
    FieldType type;
    switch ((json['type'] as String? ?? 'text').toLowerCase()) {
      case 'multiline':
        type = FieldType.multiline;
        break;
      case 'number':
        type = FieldType.number;
        break;
      case 'currency':
        type = FieldType.currency;
        break;
      case 'date':
        type = FieldType.date;
        break;
      case 'time':
        type = FieldType.time;
        break;
      case 'boolean':
        type = FieldType.boolean;
        break;
      case 'select':
        type = FieldType.select;
        break;
      case 'file':
        type = FieldType.fileAttachment;
        break;
      case 'text':
      default:
        type = FieldType.text;
    }

    final opts = (json['options'] as List<dynamic>?)?.map((e) => e.toString()).toList();

    return FieldDefinition(
      key: json['key'] as String,
      label: json['label'] as String? ?? json['key'] as String,
      type: type,
      required: json['required'] as bool? ?? false,
      placeholder: json['placeholder'] as String?,
      defaultValue: json['default_value']?.toString(),
      options: opts,
      min: json['min'] as num?,
      max: json['max'] as num?,
    );
  }
}

@immutable
class ActionDefinition {
  final String actionKey;
  final String title;
  final String description;
  final List<FieldDefinition> fields;
  final String? requiredPermission;

  const ActionDefinition({
    required this.actionKey,
    required this.title,
    required this.description,
    this.fields = const [],
    this.requiredPermission,
  });

  factory ActionDefinition.fromJson(Map<String, dynamic> json) {
    final fieldsRaw = json['fields'] as List<dynamic>? ?? [];
    return ActionDefinition(
      actionKey: json['action_key'] as String,
      title: json['title'] as String,
      description: json['description'] as String? ?? '',
      fields: fieldsRaw.map((f) => FieldDefinition.fromJson(f as Map<String, dynamic>)).toList(),
      requiredPermission: json['required_permission'] as String?,
    );
  }
}

@immutable
class EntityRecord {
  final String id;
  final String title;
  final String status;
  final Map<String, dynamic> data;
  final DateTime createdAt;

  const EntityRecord({
    required this.id,
    required this.title,
    required this.status,
    required this.data,
    required this.createdAt,
  });

  factory EntityRecord.fromJson(Map<String, dynamic> json) {
    return EntityRecord(
      id: json['id'].toString(),
      title: json['title'] as String? ?? 'Untitled',
      status: json['status'] as String? ?? 'active',
      data: (json['data'] as Map<String, dynamic>?) ?? {},
      createdAt: DateTime.tryParse(json['created_at']?.toString() ?? '') ?? DateTime.now(),
    );
  }
}
