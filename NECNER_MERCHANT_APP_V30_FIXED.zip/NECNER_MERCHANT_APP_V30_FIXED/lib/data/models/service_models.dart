import 'package:flutter/foundation.dart';

enum CapabilityState {
  available,
  readOnly,
  notImplemented,
  disabled;

  static CapabilityState fromString(String val) {
    switch (val.toUpperCase().replaceAll('-', '_').replaceAll(' ', '_')) {
      case 'AVAILABLE':
      case 'ACTIVE':
      case 'ENABLED':
        return CapabilityState.available;
      case 'READ_ONLY':
      case 'READONLY':
        return CapabilityState.readOnly;
      case 'NOT_IMPLEMENTED':
      case 'IN_PROGRESS':
        return CapabilityState.notImplemented;
      case 'DISABLED':
      default:
        return CapabilityState.disabled;
    }
  }

  String get label {
    switch (this) {
      case CapabilityState.available:
        return 'Available';
      case CapabilityState.readOnly:
        return 'Read Only';
      case CapabilityState.notImplemented:
        return 'In Progress';
      case CapabilityState.disabled:
        return 'Disabled';
    }
  }
}

@immutable
class ServiceDiscoveryItem {
  final String serviceKey;
  final String serviceName;
  final String category;
  final bool active;
  final bool assigned;
  final int sortOrder;
  final List<String> permissions;
  final String manifestReference;
  final String urlPrefix;
  final String panelKey;
  final String panelEntryFile;

  const ServiceDiscoveryItem({
    required this.serviceKey,
    required this.serviceName,
    this.category = 'General',
    required this.active,
    required this.assigned,
    this.sortOrder = 10,
    this.permissions = const [],
    required this.manifestReference,
    this.urlPrefix = '',
    this.panelKey = '',
    this.panelEntryFile = 'admin/index.php',
  });

  factory ServiceDiscoveryItem.fromJson(Map<String, dynamic> json) {
    return ServiceDiscoveryItem(
      serviceKey: (json['service_key'] ?? json['key'] ?? '').toString(),
      serviceName: (json['service_name'] ?? json['name'] ?? json['title'] ?? '').toString(),
      category: (json['category'] ?? json['category_name'] ?? 'General').toString(),
      active: _asBool(json['active'], defaultValue: true),
      assigned: _asBool(json['assigned'], defaultValue: true),
      sortOrder: _asInt(json['sort_order'], defaultValue: 10),
      permissions: _asStringList(json['permissions']),
      manifestReference: (json['manifest_reference'] ?? json['manifest_url'] ?? '').toString(),
      urlPrefix: (json['url_prefix'] ?? json['service_url_prefix'] ?? '').toString(),
      panelKey: (json['panel_key'] ?? '').toString(),
      panelEntryFile: (json['panel_entry_file'] ?? 'admin/index.php').toString(),
    );
  }
}

@immutable
class ServiceAction {
  final String actionKey;
  final String title;
  final bool requiresConfirmation;
  final bool requiresIdempotency;
  final String entityType;
  final String permissionRequired;

  const ServiceAction({
    required this.actionKey,
    required this.title,
    this.requiresConfirmation = true,
    this.requiresIdempotency = true,
    this.entityType = '',
    this.permissionRequired = '',
  });

  factory ServiceAction.fromJson(dynamic raw) {
    if (raw is String) {
      return ServiceAction(actionKey: raw, title: _pretty(raw));
    }
    if (raw is! Map) {
      return const ServiceAction(actionKey: '', title: 'Action');
    }
    final j = Map<String, dynamic>.from(raw);
    final key = (j['action_key'] ?? j['key'] ?? j['id'] ?? '').toString();
    return ServiceAction(
      actionKey: key,
      title: (j['title'] ?? j['label'] ?? j['name'] ?? (key.isNotEmpty ? _pretty(key) : 'Action')).toString(),
      requiresConfirmation: j['requires_confirmation'] != false,
      requiresIdempotency: j['idempotency_required'] != false,
      entityType: (j['entity_type'] ?? '').toString(),
      permissionRequired: (j['permission_required'] ?? j['permission'] ?? '').toString(),
    );
  }
}

@immutable
class ServiceModule {
  final String id;
  final String title;
  final String route;
  final String icon;
  final CapabilityState capability;
  final List<String> permissionsRequired;
  final List<ServiceAction> actions;
  final int sortOrder;
  final String group;
  final bool common;

  String get moduleKey => id;

  const ServiceModule({
    required this.id,
    required this.title,
    required this.route,
    required this.icon,
    required this.capability,
    this.permissionsRequired = const [],
    this.actions = const [],
    this.sortOrder = 10,
    this.group = 'Service',
    this.common = false,
  });

  factory ServiceModule.fromJson(Map<String, dynamic> json) {
    final rawId = (json['id'] ?? json['key'] ?? json['module_key'] ?? '').toString();
    final title = (json['title'] ?? json['label'] ?? json['name'] ?? (rawId.isNotEmpty ? _pretty(rawId) : 'Module')).toString();
    final actionsRaw = _asList(json['actions']);

    return ServiceModule(
      id: rawId.isNotEmpty ? rawId : _slug(title),
      title: title,
      route: (json['route'] ?? json['url'] ?? '').toString(),
      icon: (json['icon'] ?? 'grid').toString(),
      capability: CapabilityState.fromString((json['capability'] ?? json['status'] ?? 'AVAILABLE').toString()),
      permissionsRequired: _asStringList(json['permissions_required'] ?? json['permissions']),
      actions: actionsRaw.map(ServiceAction.fromJson).where((a) => a.actionKey.isNotEmpty).toList(growable: false),
      sortOrder: _asInt(json['sort_order'], defaultValue: 10),
      group: (json['group'] ?? 'Service').toString(),
      common: json['common'] == true || json['common']?.toString().toLowerCase() == 'true',
    );
  }
}

@immutable
class ServiceManifest {
  final String serviceKey;
  final String serviceName;
  final String manifestVersion;
  final String adapterVersion;
  final List<String> permissions;
  final Map<String, CapabilityState> capabilities;
  final List<ServiceModule> modules;
  final List<ServiceModule> commonModules;

  const ServiceManifest({
    required this.serviceKey,
    required this.serviceName,
    required this.manifestVersion,
    required this.adapterVersion,
    required this.permissions,
    required this.capabilities,
    required this.modules,
    this.commonModules = const [],
  });

  factory ServiceManifest.fromJson(Map<String, dynamic> json) {
    final modulesRaw = _asList(json['modules']);
    final modules = <ServiceModule>[];

    for (final raw in modulesRaw) {
      if (raw is Map) {
        modules.add(ServiceModule.fromJson(Map<String, dynamic>.from(raw)));
      } else if (raw is String) {
        modules.add(ServiceModule(
          id: _slug(raw),
          title: _pretty(raw),
          route: '',
          icon: 'grid',
          capability: CapabilityState.available,
        ));
      }
    }

    final commonRaw = _asList(json['common_modules'] ?? json['common_functions']);
    final commonModules = <ServiceModule>[];
    for (final raw in commonRaw) {
      if (raw is Map) {
        final map = Map<String, dynamic>.from(raw);
        map['common'] = true;
        map['group'] = map['group'] ?? 'Common';
        commonModules.add(ServiceModule.fromJson(map));
      } else if (raw is String) {
        commonModules.add(ServiceModule(
          id: _slug(raw), title: _pretty(raw), route: '', icon: 'grid',
          capability: CapabilityState.available, common: true, group: 'Common',
        ));
      }
    }
    modules.sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    commonModules.sort((a, b) => a.sortOrder.compareTo(b.sortOrder));

    return ServiceManifest(
      serviceKey: (json['service_key'] ?? json['key'] ?? '').toString(),
      serviceName: (json['service_name'] ?? json['name'] ?? json['display_name'] ?? 'Service').toString(),
      manifestVersion: (json['manifest_version'] ?? json['version'] ?? '1.0.0').toString(),
      adapterVersion: (json['adapter_version'] ?? '1.0.0').toString(),
      permissions: _asStringList(json['permissions']),
      capabilities: _asCapabilities(json['capabilities']),
      modules: modules,
      commonModules: commonModules,
    );
  }
}

List<dynamic> _asList(dynamic value) {
  if (value is List) return value;
  // Some older PHP manifests use an associative object keyed by module name.
  if (value is Map) {
    return value.entries.map((entry) {
      final v = entry.value;
      if (v is Map) {
        final map = Map<String, dynamic>.from(v);
        map.putIfAbsent('id', () => entry.key.toString());
        return map;
      }
      return {'id': entry.key.toString(), 'title': entry.key.toString(), 'value': v};
    }).toList();
  }
  return const [];
}

List<String> _asStringList(dynamic value) {
  if (value is List) {
    return value.map((e) => e.toString()).where((e) => e.isNotEmpty).toList(growable: false);
  }
  if (value is Map) {
    return value.keys.map((e) => e.toString()).where((e) => e.isNotEmpty).toList(growable: false);
  }
  if (value is String && value.trim().isNotEmpty) return [value.trim()];
  return const [];
}

Map<String, CapabilityState> _asCapabilities(dynamic value) {
  final out = <String, CapabilityState>{};
  if (value is Map) {
    value.forEach((key, raw) {
      if (raw is Map) {
        final state = raw['state'] ?? raw['status'] ?? raw['capability'] ?? 'AVAILABLE';
        out[key.toString()] = CapabilityState.fromString(state.toString());
      } else {
        out[key.toString()] = CapabilityState.fromString(raw.toString());
      }
    });
  } else if (value is List) {
    for (final item in value) {
      if (item is Map) {
        final key = (item['key'] ?? item['id'] ?? item['name'] ?? '').toString();
        if (key.isEmpty) continue;
        final state = (item['state'] ?? item['status'] ?? item['capability'] ?? 'AVAILABLE').toString();
        out[key] = CapabilityState.fromString(state);
      } else if (item is String && item.isNotEmpty) {
        out[item] = CapabilityState.available;
      }
    }
  }
  return out;
}

bool _asBool(dynamic value, {required bool defaultValue}) {
  if (value is bool) return value;
  if (value is num) return value != 0;
  if (value is String) {
    final v = value.toLowerCase().trim();
    if (['true', '1', 'yes', 'active', 'enabled'].contains(v)) return true;
    if (['false', '0', 'no', 'inactive', 'disabled'].contains(v)) return false;
  }
  return defaultValue;
}

int _asInt(dynamic value, {required int defaultValue}) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse(value?.toString() ?? '') ?? defaultValue;
}

String _slug(String value) => value
    .toLowerCase()
    .trim()
    .replaceAll(RegExp(r'[^a-z0-9]+'), '-')
    .replaceAll(RegExp(r'^-+|-+$'), '');

String _pretty(String value) {
  final s = value.replaceAll(RegExp(r'[_-]+'), ' ').trim();
  if (s.isEmpty) return 'Module';
  return s.split(' ').map((w) => w.isEmpty ? w : '${w[0].toUpperCase()}${w.substring(1)}').join(' ');
}
