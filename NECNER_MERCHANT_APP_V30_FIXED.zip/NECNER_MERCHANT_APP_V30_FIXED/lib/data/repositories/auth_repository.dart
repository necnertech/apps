import '../../core/constants/api_endpoints.dart';
import '../../core/network/api_client.dart';
import '../../core/result/result.dart';
import '../../core/secure_storage/secure_storage_service.dart';
import '../models/auth_models.dart';

class AuthRepository {
  final ApiClient _apiClient;
  final SecureStorageService _storage;

  AuthRepository({
    required ApiClient apiClient,
    required SecureStorageService storage,
  })  : _apiClient = apiClient,
        _storage = storage;

  /// Merchant Single Login (Username/Email + Password)
  Future<Result<AuthSession>> login(LoginRequest request) async {
    final result = await _apiClient.post<Map<String, dynamic>>(
      ApiEndpoints.login,
      data: request.toJson(),
      skipAuth: true,
      parser: (data) => data as Map<String, dynamic>,
    );

    return result.when(
      success: (data) async {
        // Parse and persist tokens
        final tokens = AuthTokens.fromJson(data);
        await _storage.saveTokens(
          accessToken: tokens.accessToken,
          refreshToken: tokens.refreshToken,
          expiresAt: tokens.expiresAt,
        );

        // Validate the freshly issued bearer token against the server before
        // marking the local session as authenticated. This prevents a
        // successful login response from being followed by a misleading
        // "session expired" state caused by the first authenticated call.
        final meResult = await getMe();
        return meResult.when(
          success: (serverSession) => Result.success(serverSession),
          failure: (err) async {
            await _storage.clearSession();
            return Result.failure(err);
          },
        );
      },
      failure: (err) => Result.failure(err),
    );
  }

  /// Fetches authenticated merchant profile and server-derived tenant
  Future<Result<AuthSession>> getMe() async {
    return _apiClient.get<AuthSession>(
      ApiEndpoints.me,
      parser: (data) => AuthSession.fromJson(data as Map<String, dynamic>),
    );
  }

  /// Revokes session on server and wipes local secure credentials
  Future<Result<bool>> logout() async {
    final refreshToken = await _storage.getRefreshToken();
    try {
      await _apiClient.post<bool>(
        ApiEndpoints.logout,
        data: {'refresh_token': refreshToken ?? ''},
        parser: (_) => true,
      );
    } catch (_) {
      // Even if network fails, proceed with local purge
    } finally {
      await _storage.clearSession();
    }
    return Result.success(true);
  }
}
