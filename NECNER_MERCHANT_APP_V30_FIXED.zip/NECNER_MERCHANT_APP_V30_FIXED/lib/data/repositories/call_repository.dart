import 'package:url_launcher/url_launcher.dart';
import '../../core/constants/api_endpoints.dart';
import '../../core/network/api_client.dart';
import '../../core/result/result.dart';
class CallRepository{final ApiClient _api;CallRepository(this._api);Future<Result<String>> createVideoRoom(String chatId)=>_api.post<String>(ApiEndpoints.videoCall,data:{'chat_id':chatId},parser:(d)=>(d as Map)['room_url']?.toString()??'');Future<bool> startPhoneCall(String phone)async{final p=phone.replaceAll(RegExp(r'[^0-9+]'),'');if(p.isEmpty)return false;return launchUrl(Uri(scheme:'tel',path:p),mode:LaunchMode.externalApplication);}Future<bool> openVideoRoom(String url)=>launchUrl(Uri.parse(url),mode:LaunchMode.externalApplication);}
