import '../../core/logging/app_logger.dart';
import '../../core/network/api_client.dart';
import '../../core/result/result.dart';
import '../models/chat_models.dart';
import '../models/contact_models.dart';

class ChatRepository {
  final ApiClient _apiClient;

  ChatRepository(this._apiClient);

  /// Fetches merchant conversation threads
  Future<Result<List<ConversationSummary>>> getConversations() async {
    return _apiClient.get<List<ConversationSummary>>(
      '/mobile/chat/index.php',
      parser: (data) {
        if (data is Map<String, dynamic> && data['items'] is List) {
          final list = data['items'] as List;
          return list
              .map((item) => ConversationSummary.fromJson(item as Map<String, dynamic>))
              .toList();
        }
        return [];
      },
    );
  }

  /// Fetches message thread for a conversation
  Future<Result<List<ChatMessageItem>>> getMessages(String chatId) async {
    return _apiClient.get<List<ChatMessageItem>>(
      '/mobile/chat/messages.php',
      queryParameters: {'chat_id': chatId},
      parser: (data) {
        if (data is Map<String, dynamic> && data['items'] is List) {
          final list = data['items'] as List;
          return list
              .map((item) => ChatMessageItem.fromJson(item as Map<String, dynamic>))
              .toList();
        }
        return [];
      },
    );
  }

  /// Dispatches an interactive message (text, voice, order, appointment, payment)
  Future<Result<ChatMessageItem>> sendMessage({
    required String chatId,
    required String type,
    required String content,
    Map<String, dynamic>? metadata,
  }) async {
    AppLogger.info('Sending interactive $type message to chat #$chatId');
    return _apiClient.post<ChatMessageItem>(
      '/mobile/chat/messages.php',
      data: {
        'chat_id': chatId,
        'type': type,
        'content': content,
        'metadata': metadata ?? {},
      },
      parser: (data) => ChatMessageItem.fromJson(data as Map<String, dynamic>),
    );
  }


  /// Loads the merchant's real CRM contacts from the existing contacts table.
  Future<Result<List<MerchantContact>>> getContacts({String query = ''}) async {
    return _apiClient.get<List<MerchantContact>>(
      '/mobile/whatsapp/contacts.php',
      queryParameters: query.trim().isEmpty ? null : {'q': query.trim()},
      parser: (data) {
        if (data is Map<String, dynamic> && data['items'] is List) {
          return (data['items'] as List)
              .whereType<Map>()
              .map((item) => MerchantContact.fromJson(Map<String, dynamic>.from(item)))
              .where((item) => item.id > 0 && item.status.toLowerCase() != 'archived')
              .toList(growable: false);
        }
        return const [];
      },
    );
  }

  /// Creates/reuses the tenant-scoped mobile conversation for a CRM contact.
  Future<Result<ConversationSummary>> startConversation({required int contactId}) async {
    return _apiClient.post<ConversationSummary>(
      '/mobile/chat/start.php',
      data: {'contact_id': contactId},
      parser: (data) => ConversationSummary.fromJson(Map<String, dynamic>.from(data as Map)),
    );
  }


  Future<Result<String>> getStorefrontUrl() async {
    return _apiClient.get<String>(
      '/mobile/storefront-url.php',
      parser: (data) {
        if (data is Map<String, dynamic>) return data['url']?.toString() ?? '';
        return '';
      },
    );
  }

  /// Marks a conversation as read
  Future<Result<bool>> markAsRead(String chatId) async {
    return _apiClient.post<bool>(
      '/mobile/chat/read.php',
      data: {'chat_id': chatId},
      parser: (data) => true,
    );
  }

  /// Emits typing indicator to recipient
  Future<Result<bool>> sendTyping(String chatId, bool isTyping) async {
    return _apiClient.post<bool>(
      '/mobile/chat/typing.php',
      data: {'chat_id': chatId, 'is_typing': isTyping},
      parser: (data) => true,
    );
  }
}
