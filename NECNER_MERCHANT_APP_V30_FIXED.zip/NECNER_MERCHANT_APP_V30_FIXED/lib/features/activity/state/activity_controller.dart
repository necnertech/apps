import 'dart:async';
import 'package:flutter/foundation.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/logging/app_logger.dart';
import '../../../core/realtime/realtime_service.dart';
import '../../../data/models/activity_models.dart';
import '../../../data/repositories/activity_repository.dart';

class ActivityController extends ChangeNotifier {
  final ActivityRepository _repository;
  final RealtimeService _realtimeService;

  List<MerchantActivityItem> _activities = [];
  bool _isLoading = false;
  AppException? _error;
  String? _filterServiceKey;

  StreamSubscription<RealtimeEvent>? _realtimeSubscription;

  ActivityController({
    required ActivityRepository repository,
    required RealtimeService realtimeService,
  })  : _repository = repository,
        _realtimeService = realtimeService {
    _listenToRealtimeEvents();
  }

  bool get isLoading => _isLoading;
  List<MerchantActivityItem> get activities => _activities;
  AppException? get error => _error;

  void setServiceFilter(String? serviceKey) {
    _filterServiceKey = serviceKey;
    loadActivities();
  }

  Future<void> loadActivities() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    final result = await _repository.getActivities(serviceKey: _filterServiceKey);

    result.when(
      success: (items) {
        _activities = items;
        _isLoading = false;
        notifyListeners();
      },
      failure: (err) {
        _error = err;
        _isLoading = false;
        notifyListeners();
      },
    );
  }

  void _listenToRealtimeEvents() {
    _realtimeSubscription = _realtimeService.eventStream.listen((event) {
      if (event.eventType == 'activity.created') {
        final data = event.data;
        final newActivity = MerchantActivityItem(
          id: 'act_${DateTime.now().millisecondsSinceEpoch}',
          title: data['title']?.toString() ?? 'Action Completed',
          description: 'Executed action "${data['action_key']}"',
          serviceKey: data['service_key']?.toString() ?? 'general',
          actorName: 'Dr. Alena Vance',
          timestamp: 'Just now',
          entityType: 'action',
          entityId: data['entity_id']?.toString() ?? '',
        );

        _activities.insert(0, newActivity);
        AppLogger.info('Activity stream updated with: ${newActivity.title}');
        notifyListeners();
      }
    });
  }

  @override
  void dispose() {
    _realtimeSubscription?.cancel();
    super.dispose();
  }
}
