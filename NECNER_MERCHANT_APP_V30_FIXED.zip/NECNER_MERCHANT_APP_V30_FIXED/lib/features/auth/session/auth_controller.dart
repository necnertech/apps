import 'package:flutter/foundation.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/logging/app_logger.dart';
import '../../../core/secure_storage/secure_storage_service.dart';
import '../../../core/utils/device_service.dart';
import '../../../data/models/auth_models.dart';
import '../../../data/repositories/auth_repository.dart';
import '../../../data/repositories/profile_repository.dart';

enum AuthStatus {
  uninitialized,
  authenticating,
  authenticated,
  unauthenticated,
  sessionExpired,
}

class AuthController extends ChangeNotifier {
  final AuthRepository _repository;
  final SecureStorageService _storage;
  final DeviceService _deviceService;

  AuthStatus _status = AuthStatus.uninitialized;
  AuthSession? _currentSession;
  AppException? _lastError;

  AuthController({
    required AuthRepository repository,
    required SecureStorageService storage,
    required DeviceService deviceService,
  })  : _repository = repository,
        _storage = storage,
        _deviceService = deviceService;

  AuthStatus get status => _status;
  bool get isAuthenticated => _status == AuthStatus.authenticated;
  AuthSession? get currentSession => _currentSession;
  AppException? get lastError => _lastError;

  /// Restores session on app startup if a valid token exists
  Future<void> checkExistingSession() async {
    final hasToken = await _storage.hasValidToken();
    if (!hasToken) {
      _status = AuthStatus.unauthenticated;
      notifyListeners();
      return;
    }

    AppLogger.info('Valid access token discovered in secure storage. Validating with server...');

    // Fetch server-authoritative tenant and user profile
    final result = await _repository.getMe();

    result.when(
      success: (session) {
        _currentSession = session;
        _status = AuthStatus.authenticated;
        AppLogger.info('Session restored successfully for Tenant #${session.tenant.id}.');
        notifyListeners();
      },
      failure: (err) async {
        AppLogger.warning('Stored session failed validation: ${err.message}. Clearing credentials.');
        await _storage.clearSession();
        _status = AuthStatus.unauthenticated;
        notifyListeners();
      },
    );
  }

  /// Authenticates with Username or Email + Password
  Future<bool> login(String identifier, String password) async {
    _status = AuthStatus.authenticating;
    _lastError = null;
    notifyListeners();

    final deviceId = await _deviceService.getDeviceId();
    final platform = _deviceService.getPlatformName();

    final request = LoginRequest(
      identifier: identifier.trim(),
      password: password,
      deviceId: deviceId,
      platform: platform,
      appVersion: AppConstants.defaultAppVersion,
    );

    final result = await _repository.login(request);

    return result.when(
      success: (session) {
        _currentSession = session;
        _status = AuthStatus.authenticated;
        _lastError = null;
        AppLogger.info('Merchant successfully authenticated for Tenant #${session.tenant.id}.');
        notifyListeners();
        return true;
      },
      failure: (err) {
        _lastError = err;
        _status = AuthStatus.unauthenticated;
        AppLogger.error('Merchant login failed: ${err.message}');
        notifyListeners();
        return false;
      },
    );
  }

  void applyProfileUpdate(MerchantProfileUpdate update) {
    final current=_currentSession; if(current==null)return;
    _currentSession=AuthSession(user:current.user.copyWith(avatarUrl:update.avatarUrl??current.user.avatarUrl),tenant:current.tenant.copyWith(name:update.businessName),effectivePermissions:current.effectivePermissions,assignedServices:current.assignedServices);
    notifyListeners();
  }

  /// Secure logout: notifies backend and wipes local hardware keystore
  Future<void> logout() async {
    AppLogger.info('Merchant logout initiated.');
    await _repository.logout();
    _currentSession = null;
    _status = AuthStatus.unauthenticated;
    _lastError = null;
    notifyListeners();
  }

  /// Called by AuthInterceptor when token refresh fails
  void handleSessionExpired() {
    AppLogger.warning('Session expired signal received from API client interceptor.');
    _currentSession = null;
    _status = AuthStatus.sessionExpired;
    notifyListeners();
  }
}
