import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../../app/theme/app_colors.dart';
import '../state/bootstrap_controller.dart';
import '../../auth/session/auth_controller.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startStartupSequence();
    });
  }

  Future<void> _startStartupSequence() async {
    final bootstrapCtrl = context.read<BootstrapController>();
    final authCtrl = context.read<AuthController>();

    // 1. Execute Server Bootstrap Handshake
    await bootstrapCtrl.executeBootstrap();

    if (!mounted) return;

    if (bootstrapCtrl.status == BootstrapStatus.maintenance) {
      context.go('/maintenance');
      return;
    }

    if (bootstrapCtrl.status == BootstrapStatus.forceUpdate) {
      context.go('/force-update');
      return;
    }

    if (bootstrapCtrl.status == BootstrapStatus.error) {
      context.go('/config-error');
      return;
    }

    // 2. Validate & Restore Secure Auth Session
    await authCtrl.checkExistingSession();

    if (!mounted) return;

    if (authCtrl.isAuthenticated) {
      context.go('/chats');
    } else {
      context.go('/login');
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: AppColors.primaryTeal,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // App Emblem
            CircleAvatar(
              radius: 36,
              backgroundColor: Colors.white,
              child: Text(
                'N',
                style: TextStyle(
                  fontSize: 38,
                  fontWeight: FontWeight.w800,
                  color: AppColors.primaryTeal,
                ),
              ),
            ),
            SizedBox(height: 24),
            Text(
              'Necner Merchant',
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
                letterSpacing: -0.5,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'WhatsApp Business-Inspired Mobile Hub',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 12,
              ),
            ),
            SizedBox(height: 48),
            SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                strokeWidth: 2.5,
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white70),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
