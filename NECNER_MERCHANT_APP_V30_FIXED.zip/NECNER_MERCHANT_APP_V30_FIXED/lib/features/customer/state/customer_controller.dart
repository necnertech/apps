import 'dart:async';
import 'package:flutter/foundation.dart';
import '../../../core/logging/app_logger.dart';
import '../../../core/network/api_client.dart';
import '../../../core/realtime/realtime_service.dart';
import '../models/customer_models.dart';

class CustomerController extends ChangeNotifier {
  final ApiClient _apiClient;
  final RealtimeService _realtimeService;

  CustomerProfile? _currentCustomer;
  List<CustomerServiceOffering> _services = [];
  List<CustomerServiceRequest> _requests = [];
  List<Map<String, dynamic>> _notifications = [];
  bool _isLoading = false;
  String? _errorMessage;
  StreamSubscription<RealtimeEvent>? _realtimeSubscription;

  CustomerController({
    required ApiClient apiClient,
    required RealtimeService realtimeService,
  })  : _apiClient = apiClient,
        _realtimeService = realtimeService {
    // Default seed customer session for Sarah Jenkins
    _currentCustomer = const CustomerProfile(
      id: 1,
      uuid: 'cust_sarah_jenkins_001',
      name: 'Sarah Jenkins',
      email: 'sarah.jenkins@example.com',
      phone: '+1-555-0199',
    );
    _listenToRealtimeEvents();
  }

  bool get isAuthenticated => _currentCustomer != null;
  CustomerProfile? get currentCustomer => _currentCustomer;
  List<CustomerServiceOffering> get services => _services;
  List<CustomerServiceRequest> get requests => _requests;
  List<Map<String, dynamic>> get notifications => _notifications;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  void setCustomer(CustomerProfile? profile) {
    _currentCustomer = profile;
    notifyListeners();
  }

  /// Discovers public/customer services
  Future<void> loadServices() async {
    _isLoading = true;
    notifyListeners();

    final res = await _apiClient.get<List<CustomerServiceOffering>>(
      '/mobile/customer/services/index.php',
      parser: (data) {
        if (data is Map<String, dynamic> && data['items'] is List) {
          final list = data['items'] as List;
          return list.map((i) => CustomerServiceOffering.fromJson(i as Map<String, dynamic>)).toList();
        }
        return [];
      },
    );

    res.when(
      success: (items) {
        _services = items;
        _isLoading = false;
        notifyListeners();
      },
      failure: (err) {
        _errorMessage = err.message;
        _isLoading = false;
        notifyListeners();
      },
    );
  }

  /// Loads customer's own service requests (Orders, Appointments, Bookings)
  Future<void> loadRequests() async {
    final res = await _apiClient.get<List<CustomerServiceRequest>>(
      '/mobile/customer/services/data.php',
      parser: (data) {
        if (data is Map<String, dynamic> && data['items'] is List) {
          final list = data['items'] as List;
          return list.map((i) => CustomerServiceRequest.fromJson(i as Map<String, dynamic>)).toList();
        }
        return [];
      },
    );

    res.when(
      success: (items) {
        _requests = items;
        notifyListeners();
      },
      failure: (err) {
        AppLogger.error('Failed to load customer requests: ${err.message}');
      },
    );
  }

  /// Submits an appointment, order, or booking request
  Future<bool> submitRequest({
    required String serviceKey,
    required String actionKey,
    required Map<String, dynamic> data,
  }) async {
    _isLoading = true;
    notifyListeners();

    final res = await _apiClient.post<Map<String, dynamic>>(
      '/mobile/customer/services/action.php',
      data: {
        'service_key': serviceKey,
        'action_key': actionKey,
        'data': data,
      },
      parser: (d) => d as Map<String, dynamic>,
    );

    bool success = false;
    res.when(
      success: (d) {
        success = true;
        _isLoading = false;
        loadRequests();
      },
      failure: (err) {
        _errorMessage = err.message;
        _isLoading = false;
        notifyListeners();
      },
    );

    return success;
  }

  /// Loads customer notifications
  Future<void> loadNotifications() async {
    final res = await _apiClient.get<List<Map<String, dynamic>>>(
      '/mobile/customer/notifications/index.php',
      parser: (data) {
        if (data is Map<String, dynamic> && data['items'] is List) {
          final list = data['items'] as List;
          return list.map((i) => Map<String, dynamic>.from(i as Map)).toList();
        }
        return [];
      },
    );

    res.when(
      success: (items) {
        _notifications = items;
        notifyListeners();
      },
      failure: (err) {},
    );
  }

  void _listenToRealtimeEvents() {
    _realtimeSubscription = _realtimeService.eventStream.listen((event) {
      final evtType = event.eventType;
      if (evtType == 'order.updated' ||
          evtType == 'order.confirmed' ||
          evtType == 'appointment.confirmed' ||
          evtType == 'payment.captured') {
        AppLogger.info('Customer state invalidated by realtime event: $evtType');
        loadRequests();
        loadNotifications();
      }
    });
  }

  @override
  void dispose() {
    _realtimeSubscription?.cancel();
    super.dispose();
  }
}
