import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../../app/theme/app_colors.dart';
import '../../../core/push/push_notification_service.dart';
import '../../../data/models/notification_models.dart';
import '../state/notifications_controller.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<NotificationsController>().loadNotifications();
    });
  }

  @override
  Widget build(BuildContext context) {
    final notifCtrl = context.watch<NotificationsController>();
    final unreadCount = notifCtrl.unreadCount;

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: const Color(0xFF075E54),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Alerts & Push Inbox',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
            ),
            Text(
              unreadCount > 0 ? '$unreadCount unread notifications' : 'All caught up',
              style: TextStyle(color: Colors.white.withValues(alpha: 0.8), fontSize: 12),
            ),
          ],
        ),
        actions: [
          if (unreadCount > 0)
            TextButton(
              onPressed: () => notifCtrl.markAllAsRead(),
              child: const Text(
                'Mark All Read',
                style: TextStyle(color: Color(0xFF25D366), fontWeight: FontWeight.bold),
              ),
            ),
          IconButton(
            icon: const Icon(Icons.more_vert_rounded, color: Colors.white),
            tooltip: 'Merchant Tools',
            onPressed: () => context.push('/tools'),
          ),
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: () => notifCtrl.loadNotifications(),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Container(
            color: const Color(0xFF054D44),
            height: 48,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                _buildFilterChip('all', 'All', notifCtrl),
                const SizedBox(width: 8),
                _buildFilterChip('order', 'Orders', notifCtrl),
                const SizedBox(width: 8),
                _buildFilterChip('appointment', 'Appointments', notifCtrl),
                const SizedBox(width: 8),
                _buildFilterChip('system', 'System', notifCtrl),
              ],
            ),
          ),
        ),
      ),
      body: RefreshIndicator(
        color: const Color(0xFF075E54),
        onRefresh: () => notifCtrl.loadNotifications(),
        child: _buildBody(notifCtrl),
      ),
    );
  }

  Widget _buildFilterChip(String key, String label, NotificationsController ctrl) {
    final isSelected = ctrl.activeFilter == key;
    return GestureDetector(
      onTap: () => ctrl.setFilter(key),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF25D366) : Colors.white.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: isSelected ? Colors.white : Colors.white.withValues(alpha: 0.9),
              fontSize: 12.5,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBody(NotificationsController notifCtrl) {
    if (notifCtrl.isLoading && notifCtrl.filteredNotifications.isEmpty) {
      return const Center(child: CircularProgressIndicator(color: Color(0xFF075E54)));
    }

    final list = notifCtrl.filteredNotifications;

    if (list.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.notifications_none, size: 64, color: Colors.grey.shade400),
              const SizedBox(height: 16),
              const Text(
                'No notifications to display',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF374151)),
              ),
              const SizedBox(height: 8),
              Text(
                'Native APNs and FCM push alerts will appear here.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: Colors.grey.shade500),
              ),
            ],
          ),
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: list.length,
      separatorBuilder: (_, __) => const Divider(height: 1, indent: 72, color: Color(0xFFE5E7EB)),
      itemBuilder: (context, index) {
        final item = list[index];
        return _buildNotificationCard(item, notifCtrl);
      },
    );
  }

  Widget _buildNotificationCard(PushNotificationItem item, NotificationsController notifCtrl) {
    return Container(
      color: item.isRead ? Colors.transparent : const Color(0xFFF0FDF4), // soft green tint for unread
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        onTap: () {
          notifCtrl.markAsRead(item.id);
          if (item.deepLink != null) {
            final route = PushNotificationService.resolveRouteFromDeepLink(item.deepLink!);
            if (route != null) {
              context.push(route);
            }
          }
        },
        leading: CircleAvatar(
          radius: 22,
          backgroundColor: _getTypeColor(item.type).withValues(alpha: 0.12),
          child: Icon(_getTypeIcon(item.type), color: _getTypeColor(item.type), size: 22),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text(
                item.title,
                style: TextStyle(
                  fontWeight: item.isRead ? FontWeight.w600 : FontWeight.bold,
                  fontSize: 15,
                  color: const Color(0xFF111827),
                ),
              ),
            ),
            if (!item.isRead)
              Container(
                width: 8,
                height: 8,
                margin: const EdgeInsets.only(left: 6),
                decoration: const BoxDecoration(
                  color: Color(0xFF25D366),
                  shape: BoxShape.circle,
                ),
              ),
          ],
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.body,
                style: const TextStyle(fontSize: 13.5, color: Color(0xFF4B5563), height: 1.3),
              ),
              const SizedBox(height: 4),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    item.serviceKey.toUpperCase(),
                    style: TextStyle(
                      fontSize: 10.5,
                      fontWeight: FontWeight.bold,
                      color: _getTypeColor(item.type),
                    ),
                  ),
                  Text(
                    item.createdAt,
                    style: const TextStyle(fontSize: 11, color: Color(0xFF9CA3AF)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getTypeColor(String type) {
    switch (type) {
      case 'order':
        return const Color(0xFF059669);
      case 'appointment':
        return const Color(0xFF0284C7);
      case 'chat':
        return const Color(0xFF075E54);
      case 'payment':
        return const Color(0xFF7C3AED);
      default:
        return const Color(0xFF6B7280);
    }
  }

  IconData _getTypeIcon(String type) {
    switch (type) {
      case 'order':
        return Icons.shopping_bag;
      case 'appointment':
        return Icons.calendar_today;
      case 'chat':
        return Icons.chat;
      case 'payment':
        return Icons.payment;
      default:
        return Icons.notifications;
    }
  }
}
