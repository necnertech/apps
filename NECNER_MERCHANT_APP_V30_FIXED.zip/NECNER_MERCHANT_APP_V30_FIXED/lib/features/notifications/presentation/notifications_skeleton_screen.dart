import 'package:flutter/material.dart';
import '../../../app/theme/app_colors.dart';

class NotificationsSkeletonScreen extends StatelessWidget {
  const NotificationsSkeletonScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Notification Item 1
        _buildNotificationCard(
          title: 'New Pharmacy Order #10045',
          body: 'Marcus Vance ordered 2 items (\$120.00). Ready for fulfillment.',
          service: 'Pharmacy Store',
          time: '15m ago',
          isUnread: true,
          icon: Icons.shopping_bag_outlined,
          iconColor: AppColors.badgeBlue,
        ),
        const SizedBox(height: 12),

        // Notification Item 2
        _buildNotificationCard(
          title: 'Appointment Confirmed',
          body: 'Elena Rostova confirmed Consultation for Oct 02 at 02:00 PM.',
          service: 'Doctor & Clinic',
          time: '45m ago',
          isUnread: true,
          icon: Icons.calendar_today_outlined,
          iconColor: AppColors.primaryEmerald,
        ),
        const SizedBox(height: 12),

        // Notification Item 3
        _buildNotificationCard(
          title: 'Payment Received: \$45.00',
          body: 'Settled via NecnerPay for Consultation #8041.',
          service: 'Doctor & Clinic',
          time: '2h ago',
          isUnread: false,
          icon: Icons.payments_outlined,
          iconColor: AppColors.accentGreen,
        ),

        const SizedBox(height: 36),
        Center(
          child: Text(
            'Push notification channels (FCM / APNS) connect in Phase 4.',
            style: TextStyle(fontSize: 11, color: AppColors.textSecondaryLight.withValues(alpha: 0.8)),
          ),
        ),
      ],
    );
  }

  Widget _buildNotificationCard({
    required String title,
    required String body,
    required String service,
    required String time,
    required bool isUnread,
    required IconData icon,
    required Color iconColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isUnread ? AppColors.primaryEmerald.withValues(alpha: 0.4) : AppColors.borderLight,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, size: 20, color: iconColor),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: isUnread ? FontWeight.bold : FontWeight.w600,
                        color: AppColors.textPrimaryLight,
                      ),
                    ),
                    Text(time, style: const TextStyle(fontSize: 10, color: AppColors.textSecondaryLight)),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  body,
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight, height: 1.3),
                ),
                const SizedBox(height: 6),
                Text(
                  service,
                  style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: iconColor),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
