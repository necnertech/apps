import '../../../core/result/result.dart';
import '../../../data/models/module_schema_models.dart';
import '../../../data/models/service_models.dart';

/// Reusable Service Adapter Interface.
/// Provides a consistent contract for all dynamic service modules (Healthcare, Retail, Salon, etc.)
/// without hardcoding service-specific business logic into Flutter widgets.
abstract class MerchantServiceAdapter {
  String get serviceKey;
  String get serviceName;

  /// Loads service manifest defining modules and explicit capabilities
  Future<Result<ServiceManifest>> loadManifest();

  /// Retrieves paginated records for a supported module
  Future<Result<List<EntityRecord>>> listRecords(String moduleKey);

  /// Retrieves single record details
  Future<Result<EntityRecord>> getRecordDetail(String moduleKey, String recordId);

  /// Submits an action form payload to the authorized backend endpoint
  Future<Result<Map<String, dynamic>>> executeAction(String actionKey, Map<String, dynamic> payload);
}
