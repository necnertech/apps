import 'package:flutter/material.dart';

import '../../../app/theme/app_colors.dart';
import 'merchant_webview_screen.dart';

/// Common merchant account/settings workspace.
/// These are real existing PHP customer-workspace pages, opened through the
/// same mobile workspace bridge so the normal merchant session is reused.
class CommonSettingsScreen extends StatelessWidget {
  final bool profileOnly;

  const CommonSettingsScreen({super.key, this.profileOnly = false});

  static const _items = <_CommonSettingItem>[
    _CommonSettingItem('Business Profile', 'Logo, business name & profile', Icons.store_rounded, '/customer/profile.php', 'profile'),
    _CommonSettingItem('Account Settings', 'Notifications, language & account', Icons.manage_accounts_rounded, '/customer/settings.php', 'account'),
    _CommonSettingItem('Security', 'Change password & active sessions', Icons.lock_rounded, '/customer/security.php', 'security'),
    _CommonSettingItem('Team & Users', 'Team members and access', Icons.groups_rounded, '/customer/team.php', 'team'),
    _CommonSettingItem('WhatsApp Business', 'Numbers and WhatsApp workspace', Icons.chat_rounded, '/customer/whatsapp.php', 'whatsapp'),
    _CommonSettingItem('Contacts', 'Customers, leads and phone numbers', Icons.contacts_rounded, '/customer/contacts.php', 'contacts'),
    _CommonSettingItem('Message Templates', 'WhatsApp message templates', Icons.description_rounded, '/customer/templates.php', 'templates'),
    _CommonSettingItem('Automation', 'Automations and workflows', Icons.smart_toy_rounded, '/customer/automation.php', 'automation'),
    _CommonSettingItem('Subscription & Billing', 'Plan, billing and renewal', Icons.receipt_long_rounded, '/customer/subscription.php', 'billing'),
    _CommonSettingItem('Analytics', 'Business analytics and reports', Icons.analytics_rounded, '/customer/analytics.php', 'analytics'),
  ];

  List<_CommonSettingItem> get _visibleItems {
    if (!profileOnly) return _items;
    return _items.where((item) => const {'profile', 'account', 'security', 'team'}.contains(item.key)).toList(growable: false);
  }

  void _open(BuildContext context, _CommonSettingItem item) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => MerchantWebViewScreen(title: item.title, path: item.path),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final items = _visibleItems;
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D2028),
        foregroundColor: Colors.white,
        title: Text(profileOnly ? 'Profile Settings' : 'Settings', style: const TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: RefreshIndicator(
        color: AppColors.primaryEmerald,
        onRefresh: () async {},
        child: GridView.builder(
          padding: const EdgeInsets.fromLTRB(14, 18, 14, 32),
          itemCount: items.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 12,
            mainAxisSpacing: 22,
            childAspectRatio: .82,
          ),
          itemBuilder: (_, index) {
            final item = items[index];
            return InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () => _open(context, item),
              child: Column(
                children: [
                  Container(
                    width: 66,
                    height: 66,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFFE3F4F0),
                      border: Border.all(color: AppColors.primaryTeal.withValues(alpha: .18)),
                    ),
                    alignment: Alignment.center,
                    child: Icon(item.icon, color: AppColors.primaryTeal, size: 29),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    item.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 12.5, height: 1.15, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    item.subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 9.5, color: AppColors.textSecondaryLight, height: 1.1),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _CommonSettingItem {
  final String title;
  final String subtitle;
  final IconData icon;
  final String path;
  final String key;

  const _CommonSettingItem(this.title, this.subtitle, this.icon, this.path, this.key);
}
