import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../app/theme/app_colors.dart';
import '../../../core/actions/action_definition.dart';
import '../../../core/actions/action_engine.dart';
import '../../../core/entities/entity_relationship_resolver.dart';
import '../../../core/permissions/permission_evaluator.dart';
import '../../../data/models/module_schema_models.dart' hide ActionDefinition;
import '../../../data/models/service_models.dart';
import '../../auth/session/auth_controller.dart';
import '../engine/service_adapter.dart';

class GenericDetailScreen extends StatefulWidget {
  final MerchantServiceAdapter adapter;
  final String moduleKey;
  final String recordId;
  final String recordTitle;
  final List<ServiceAction> actions;

  const GenericDetailScreen({
    super.key,
    required this.adapter,
    required this.moduleKey,
    required this.recordId,
    required this.recordTitle,
    this.actions = const [],
  });

  @override
  State<GenericDetailScreen> createState() => _GenericDetailScreenState();
}

class _GenericDetailScreenState extends State<GenericDetailScreen> {
  bool _isLoading = true;
  EntityRecord? _record;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadRecord();
  }

  Future<void> _loadRecord() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    final result = await widget.adapter.getRecordDetail(widget.moduleKey, widget.recordId);

    if (mounted) {
      setState(() {
        _isLoading = false;
        result.when(
          success: (rec) => _record = rec,
          failure: (err) => _errorMessage = err.message,
        );
      });
    }
  }

  void _executeRecordAction(String actionKey, String title) async {
    final authCtrl = context.read<AuthController>();
    final session = authCtrl.currentSession;
    final permissions = session?.effectivePermissions ?? [];
    final assignedServices = session?.assignedServices ?? [];

    final evaluator = PermissionEvaluator(
      userPermissions: permissions,
      assignedServices: assignedServices,
    );

    final actionEngine = context.read<ActionEngine>();

    final action = ActionDefinition(
      actionKey: actionKey,
      title: title,
      description: 'Perform action "$title" on record #${widget.recordId}',
      serviceKey: widget.adapter.serviceKey,
      moduleKey: widget.moduleKey,
      entityType: widget.moduleKey.replaceAll('s', ''),
      permissionRequired: '${widget.adapter.serviceKey}.manage',
      requiresConfirmation: true,
      confirmationMessage: 'Are you sure you want to mark "${widget.recordTitle}" as $title?',
      requiresIdempotency: true,
    );

    final result = await actionEngine.execute(
      action: action,
      payload: {
        'record_id': widget.recordId,
        'title': widget.recordTitle,
        'action': actionKey,
      },
      permissionEvaluator: evaluator,
      context: context,
    );

    if (mounted) {
      if (result.success) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${action.title} executed successfully!'),
            backgroundColor: AppColors.primaryEmerald,
          ),
        );
        _loadRecord();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result.message),
            backgroundColor: AppColors.badgeRed,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: Text(widget.recordTitle),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadRecord,
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryEmerald)),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 48, color: AppColors.badgeRed),
              const SizedBox(height: 12),
              Text(_errorMessage!, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              ElevatedButton(onPressed: _loadRecord, child: const Text('Retry')),
            ],
          ),
        ),
      );
    }

    final record = _record ?? EntityRecord(
      id: widget.recordId,
      title: widget.recordTitle,
      status: 'active',
      data: {'reference': 'REF-${widget.recordId}', 'priority': 'Normal'},
      createdAt: DateTime.now(),
    );

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header Card
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        record.title,
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'ID: #${record.id} · Service: ${widget.adapter.serviceName}',
                        style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getStatusColor(record.status).withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _getStatusColor(record.status).withValues(alpha: 0.3)),
                  ),
                  child: Text(
                    record.status.toUpperCase(),
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: _getStatusColor(record.status),
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Metadata Attributes
          const Text(
            'Record Attributes',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppColors.textPrimaryLight),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: Column(
              children: record.data.entries.map((e) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _formatKey(e.key),
                        style: const TextStyle(fontSize: 13, color: AppColors.textSecondaryLight),
                      ),
                      Text(
                        '${e.value}',
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimaryLight),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),

          const SizedBox(height: 16),

          // Multi-Entity Related Actions
          Builder(builder: (context) {
            final authCtrl = context.read<AuthController>();
            final session = authCtrl.currentSession;
            final evaluator = PermissionEvaluator(
              userPermissions: session?.effectivePermissions ?? [],
              assignedServices: session?.assignedServices ?? [],
            );
            final links = EntityRelationshipResolver.resolveLinks(
              serviceKey: widget.adapter.serviceKey,
              moduleKey: widget.moduleKey,
              record: record,
              evaluator: evaluator,
            );

            if (links.isEmpty) return const SizedBox.shrink();

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Connected Context & Relationships',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textPrimaryLight),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: links.map((link) {
                    return ActionChip(
                      avatar: Icon(link.icon, size: 16, color: const Color(0xFF075E54)),
                      label: Text(link.label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                      backgroundColor: Colors.white,
                      side: const BorderSide(color: Color(0xFF075E54), width: 0.8),
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Opening ${link.label}...'),
                            duration: const Duration(seconds: 1),
                          ),
                        );
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
              ],
            );
          }),

          const Text(
            'Operational Actions',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppColors.textPrimaryLight),
          ),
          const SizedBox(height: 8),
          if (widget.actions.isNotEmpty)
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: widget.actions.map((action) {
                final destructive = action.actionKey.toLowerCase().contains('cancel') || action.actionKey.toLowerCase().contains('reject');
                return ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: destructive ? Colors.white : const Color(0xFF075E54),
                    foregroundColor: destructive ? AppColors.badgeRed : Colors.white,
                    side: destructive ? const BorderSide(color: AppColors.badgeRed) : null,
                    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
                  ),
                  icon: Icon(destructive ? Icons.cancel_outlined : Icons.check_circle_outline, size: 17),
                  label: Text(action.title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                  onPressed: () => _executeRecordAction(action.actionKey, action.title),
                );
              }).toList(),
            )
          else
            const Text('No service actions were published for this record.', style: TextStyle(color: AppColors.textSecondaryLight, fontSize: 12)),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'confirmed':
      case 'completed':
      case 'active':
        return AppColors.primaryEmerald;
      case 'pending':
      case 'scheduled':
        return const Color(0xFF0284C7);
      case 'cancelled':
      case 'failed':
        return AppColors.badgeRed;
      default:
        return const Color(0xFF6B7280);
    }
  }

  String _formatKey(String key) {
    return key
        .replaceAll('_', ' ')
        .split(' ')
        .map((w) => w.isNotEmpty ? w[0].toUpperCase() + w.substring(1) : '')
        .join(' ');
  }
}
