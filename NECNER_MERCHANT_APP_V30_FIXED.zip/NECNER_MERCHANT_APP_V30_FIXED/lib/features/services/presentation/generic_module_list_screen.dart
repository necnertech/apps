import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../app/theme/app_colors.dart';
import '../../../core/actions/action_definition.dart';
import '../../../core/permissions/permission_evaluator.dart';
import '../../../data/models/module_schema_models.dart' hide ActionDefinition;
import '../../../data/models/service_models.dart';
import '../../auth/session/auth_controller.dart';
import '../engine/service_adapter.dart';
import 'generic_detail_screen.dart';
import 'hardened_schema_form_screen.dart';

class GenericModuleListScreen extends StatefulWidget {
  final MerchantServiceAdapter adapter;
  final String moduleKey;
  final String moduleTitle;
  final bool isReadOnly;
  final List<ServiceAction> actions;

  const GenericModuleListScreen({
    super.key,
    required this.adapter,
    required this.moduleKey,
    required this.moduleTitle,
    this.isReadOnly = false,
    this.actions = const [],
  });

  @override
  State<GenericModuleListScreen> createState() => _GenericModuleListScreenState();
}

class _GenericModuleListScreenState extends State<GenericModuleListScreen> {
  bool _isLoading = true;
  List<EntityRecord> _records = [];
  String? _errorMessage;
  String _searchQuery = '';
  String _selectedStatusFilter = 'ALL';

  @override
  void initState() {
    super.initState();
    _fetchRecords();
  }

  Future<void> _fetchRecords() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    final result = await widget.adapter.listRecords(widget.moduleKey);

    if (mounted) {
      setState(() {
        _isLoading = false;
        result.when(
          success: (items) => _records = items,
          failure: (err) => _errorMessage = err.message,
        );
      });
    }
  }

  List<EntityRecord> get _filteredRecords {
    return _records.where((r) {
      if (_selectedStatusFilter != 'ALL' &&
          r.status.toUpperCase() != _selectedStatusFilter) {
        return false;
      }
      if (_searchQuery.trim().isNotEmpty) {
        final query = _searchQuery.toLowerCase();
        final matchTitle = r.title.toLowerCase().contains(query);
        final matchId = r.id.toLowerCase().contains(query);
        return matchTitle || matchId;
      }
      return true;
    }).toList();
  }

  void _openCreateForm() {
    final formAction = ActionDefinition(
      actionKey: 'create_${widget.moduleKey.replaceAll("s", "")}',
      title: 'New ${widget.moduleTitle.replaceAll("s", "")}',
      description: 'Create a new record in ${widget.moduleTitle}',
      serviceKey: widget.adapter.serviceKey,
      moduleKey: widget.moduleKey,
      entityType: widget.moduleKey.replaceAll("s", ""),
      permissionRequired: '${widget.adapter.serviceKey}.manage',
      fields: const [
        FieldDefinition(
          key: 'title',
          label: 'Title / Subject',
          type: FieldType.text,
          required: true,
          placeholder: 'Enter title or name',
        ),
        FieldDefinition(
          key: 'customer_name',
          label: 'Customer / Patient Name',
          type: FieldType.text,
          required: true,
          placeholder: 'Full name',
        ),
        FieldDefinition(
          key: 'notes',
          label: 'Notes / Description',
          type: FieldType.text,
          required: false,
          placeholder: 'Additional details',
        ),
      ],
      requiresConfirmation: false,
      requiresIdempotency: true,
    );

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (ctx) => HardenedSchemaFormScreen(
          adapter: widget.adapter,
          actionDefinition: formAction,
          onSuccess: _fetchRecords,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authCtrl = context.watch<AuthController>();
    final session = authCtrl.currentSession;
    final evaluator = PermissionEvaluator(
      userPermissions: session?.effectivePermissions ?? [],
      assignedServices: session?.assignedServices ?? [],
    );

    final canCreate = !widget.isReadOnly &&
        evaluator.hasPermission('${widget.adapter.serviceKey}.manage');

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.moduleTitle),
            Text(
              '${widget.adapter.serviceName} · ${widget.isReadOnly ? "Read-Only" : "Active"}',
              style: const TextStyle(fontSize: 11, color: Colors.white70),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          // Search & Filter Row
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Column(
              children: [
                TextField(
                  onChanged: (val) => setState(() => _searchQuery = val),
                  decoration: InputDecoration(
                    hintText: 'Search ${widget.moduleTitle.toLowerCase()}...',
                    prefixIcon: const Icon(Icons.search, size: 20),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: AppColors.borderLight),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    _buildStatusChip('ALL', 'All'),
                    const SizedBox(width: 8),
                    _buildStatusChip('ACTIVE', 'Active'),
                    const SizedBox(width: 8),
                    _buildStatusChip('PENDING', 'Pending'),
                    const SizedBox(width: 8),
                    _buildStatusChip('COMPLETED', 'Completed'),
                  ],
                ),
              ],
            ),
          ),

          // Main Records List
          Expanded(child: _buildBody()),
        ],
      ),
      floatingActionButton: canCreate
          ? FloatingActionButton(
              backgroundColor: const Color(0xFF075E54),
              onPressed: _openCreateForm,
              child: const Icon(Icons.add, color: Colors.white),
            )
          : null,
    );
  }

  Widget _buildStatusChip(String key, String label) {
    final isSelected = _selectedStatusFilter == key;
    return GestureDetector(
      onTap: () => setState(() => _selectedStatusFilter = key),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF075E54) : Colors.grey.shade100,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 11.5,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            color: isSelected ? Colors.white : AppColors.textPrimaryLight,
          ),
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryEmerald)),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline_rounded, size: 48, color: AppColors.badgeRed),
              const SizedBox(height: 12),
              Text(_errorMessage!, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: _fetchRecords,
                icon: const Icon(Icons.refresh, size: 18),
                label: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    final items = _filteredRecords;
    if (items.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.inbox_outlined, size: 56, color: AppColors.textSecondaryLight),
              const SizedBox(height: 12),
              Text(
                'No ${widget.moduleTitle.toLowerCase()} found.',
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppColors.textPrimaryLight),
              ),
              const SizedBox(height: 4),
              const Text(
                'Records will appear as operations are executed.',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
              ),
            ],
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _fetchRecords,
      color: AppColors.primaryEmerald,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final record = items[index];
          return Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: ListTile(
              title: Text(
                record.title,
                style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600),
              ),
              subtitle: Text(
                'ID: #${record.id} · Status: ${record.status.toUpperCase()}',
                style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondaryLight),
              ),
              trailing: const Icon(Icons.chevron_right, size: 20, color: AppColors.textSecondaryLight),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (ctx) => GenericDetailScreen(
                      adapter: widget.adapter,
                      moduleKey: widget.moduleKey,
                      recordId: record.id,
                      recordTitle: record.title,
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
