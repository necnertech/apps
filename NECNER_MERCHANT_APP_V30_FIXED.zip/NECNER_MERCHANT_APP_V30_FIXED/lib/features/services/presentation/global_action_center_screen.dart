import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../app/theme/app_colors.dart';
import '../../../core/actions/action_definition.dart';
import '../../../core/actions/action_engine.dart';
import '../../../core/network/api_client.dart';
import '../../../core/permissions/permission_evaluator.dart';
import '../../../core/secure_storage/secure_storage_service.dart';
import '../../../app/config/app_config.dart';
import '../../auth/session/auth_controller.dart';

class GlobalActionCenterScreen extends StatefulWidget {
  const GlobalActionCenterScreen({super.key});

  @override
  State<GlobalActionCenterScreen> createState() => _GlobalActionCenterScreenState();
}

class _GlobalActionCenterScreenState extends State<GlobalActionCenterScreen> {
  bool _isLoading = true;
  List<Map<String, dynamic>> _tasks = [];
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadPendingActions();
  }

  Future<void> _loadPendingActions() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    final config = context.read<AppConfig>();
    final storage = SecureStorageService();
    final apiClient = ApiClient(config: config, storage: storage, onSessionExpired: () {});

    final res = await apiClient.get<Map<String, dynamic>>(
      '/mobile/services/pending_actions.php',
      parser: (data) => data is Map<String, dynamic> ? data : {},
    );

    if (mounted) {
      res.when(
        success: (data) {
          final items = data['items'] as List<dynamic>? ?? [];
          setState(() {
            _tasks = items.map((i) => Map<String, dynamic>.from(i as Map)).toList();
            _isLoading = false;
          });
        },
        failure: (err) {
          setState(() {
            _errorMessage = err.message;
            _isLoading = false;
          });
        },
      );
    }
  }

  Future<void> _executePendingAction(Map<String, dynamic> task) async {
    final authCtrl = context.read<AuthController>();
    final session = authCtrl.currentSession;
    final evaluator = PermissionEvaluator(
      userPermissions: session?.effectivePermissions ?? [],
      assignedServices: session?.assignedServices ?? [],
    );

    final actionEngine = context.read<ActionEngine>();
    final serviceKey = task['service_key']?.toString() ?? 'doctor';
    final actionKey = task['action_key']?.toString() ?? 'confirm';
    final title = task['title']?.toString() ?? 'Pending Action';
    final payload = Map<String, dynamic>.from(task['payload'] as Map? ?? {});

    final actionDef = ActionDefinition(
      actionKey: actionKey,
      title: title,
      description: task['description']?.toString() ?? '',
      serviceKey: serviceKey,
      moduleKey: task['module_key']?.toString() ?? 'appointments',
      entityType: task['entity_type']?.toString() ?? 'appointment',
      permissionRequired: '$serviceKey.manage',
      requiresConfirmation: true,
      confirmationMessage: 'Proceed with "$title"?',
      requiresIdempotency: true,
    );

    final result = await actionEngine.execute(
      action: actionDef,
      payload: payload,
      permissionEvaluator: evaluator,
      context: context,
    );

    if (mounted) {
      if (result.success) {
        setState(() {
          _tasks.removeWhere((t) => t['id'] == task['id']);
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$title completed successfully!'),
            backgroundColor: AppColors.primaryEmerald,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result.message),
            backgroundColor: AppColors.badgeRed,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: const Text('Pending Action Center'),
        backgroundColor: const Color(0xFF075E54),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadPendingActions,
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryEmerald)),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 48, color: AppColors.badgeRed),
              const SizedBox(height: 8),
              Text(_errorMessage!, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              ElevatedButton(onPressed: _loadPendingActions, child: const Text('Retry')),
            ],
          ),
        ),
      );
    }

    if (_tasks.isEmpty) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.check_circle_outline, size: 56, color: Color(0xFF059669)),
            SizedBox(height: 12),
            Text(
              'All Caught Up!',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textPrimaryLight),
            ),
            SizedBox(height: 4),
            Text(
              'No pending orders, requests, or collections require review.',
              style: TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadPendingActions,
      color: AppColors.primaryEmerald,
      child: ListView.separated(
        padding: const EdgeInsets.all(12),
        itemCount: _tasks.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final task = _tasks[index];
          final title = task['title']?.toString() ?? 'Pending Task';
          final desc = task['description']?.toString() ?? '';
          final priority = task['priority']?.toString() ?? 'normal';
          final serviceKey = task['service_key']?.toString() ?? 'doctor';

          final isHigh = priority == 'high';

          return Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isHigh ? const Color(0xFFFCA5A5) : AppColors.borderLight,
                width: isHigh ? 1.5 : 1,
              ),
            ),
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: isHigh ? const Color(0xFFFEE2E2) : const Color(0xFFE0F2FE),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        isHigh ? 'HIGH PRIORITY' : 'NORMAL',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: isHigh ? const Color(0xFF991B1B) : const Color(0xFF0369A1),
                        ),
                      ),
                    ),
                    Text(
                      serviceKey.toUpperCase(),
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF075E54)),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  title,
                  style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                Text(
                  desc,
                  style: const TextStyle(fontSize: 12.5, color: Color(0xFF4B5563)),
                ),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerRight,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF075E54),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    ),
                    onPressed: () => _executePendingAction(task),
                    child: const Text('Execute Action', style: TextStyle(color: Colors.white, fontSize: 12)),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
