import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../app/theme/app_colors.dart';
import '../../../core/network/api_client.dart';
import '../../../core/secure_storage/secure_storage_service.dart';
import '../../../app/config/app_config.dart';
import '../../auth/session/auth_controller.dart';
import '../engine/dynamic_module_registry.dart';
import 'generic_detail_screen.dart';

class MasterSearchScreen extends StatefulWidget {
  const MasterSearchScreen({super.key});

  @override
  State<MasterSearchScreen> createState() => _MasterSearchScreenState();
}

class _MasterSearchScreenState extends State<MasterSearchScreen> {
  final TextEditingController _queryController = TextEditingController();
  Timer? _debounceTimer;
  bool _isLoading = false;
  List<Map<String, dynamic>> _results = [];
  String? _errorMessage;
  String _selectedServiceFilter = 'all';

  @override
  void dispose() {
    _queryController.dispose();
    _debounceTimer?.cancel();
    super.dispose();
  }

  void _onQueryChanged(String query) {
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 300), () {
      _executeSearch(query);
    });
  }

  Future<void> _executeSearch(String query) async {
    final trimmed = query.trim();
    if (trimmed.isEmpty) {
      setState(() {
        _results = [];
        _isLoading = false;
        _errorMessage = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    final config = context.read<AppConfig>();
    final storage = SecureStorageService();
    final apiClient = ApiClient(config: config, storage: storage, onSessionExpired: () {});

    final params = <String, dynamic>{
      'query': trimmed,
    };
    if (_selectedServiceFilter != 'all') {
      params['service_key'] = _selectedServiceFilter;
    }

    final res = await apiClient.get<Map<String, dynamic>>(
      '/mobile/services/search.php',
      queryParameters: params,
      parser: (data) => data is Map<String, dynamic> ? data : {},
    );

    if (mounted) {
      res.when(
        success: (data) {
          final items = data['items'] as List<dynamic>? ?? [];
          setState(() {
            _results = items.map((i) => Map<String, dynamic>.from(i as Map)).toList();
            _isLoading = false;
          });
        },
        failure: (err) {
          setState(() {
            _errorMessage = err.message;
            _isLoading = false;
          });
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final authCtrl = context.watch<AuthController>();
    final assignedServices = authCtrl.currentSession?.assignedServices ?? const [];

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: const Text('Master Search'),
        backgroundColor: const Color(0xFF075E54),
      ),
      body: Column(
        children: [
          // Search Input Bar
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                TextField(
                  controller: _queryController,
                  autofocus: true,
                  onChanged: _onQueryChanged,
                  decoration: InputDecoration(
                    hintText: 'Search orders, patients, invoices...',
                    prefixIcon: const Icon(Icons.search, color: Color(0xFF075E54)),
                    suffixIcon: _queryController.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear, size: 18),
                            onPressed: () {
                              _queryController.clear();
                              _executeSearch('');
                            },
                          )
                        : null,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: AppColors.borderLight),
                    ),
                  ),
                ),
                const SizedBox(height: 8),

                // Service Filter Chips
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _buildChip('all', 'All Services'),
                      ...assignedServices.map((s) => _buildChip(s, _formatServiceName(s))),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Results List
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildChip(String key, String label) {
    final isSelected = _selectedServiceFilter == key;
    return Padding(
      padding: const EdgeInsets.only(right: 6.0),
      child: ChoiceChip(
        label: Text(label, style: TextStyle(fontSize: 11.5, color: isSelected ? Colors.white : AppColors.textPrimaryLight)),
        selected: isSelected,
        selectedColor: const Color(0xFF075E54),
        backgroundColor: Colors.grey.shade100,
        onSelected: (val) {
          setState(() => _selectedServiceFilter = key);
          _executeSearch(_queryController.text);
        },
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryEmerald)),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 48, color: AppColors.badgeRed),
              const SizedBox(height: 8),
              Text(_errorMessage!, textAlign: TextAlign.center),
            ],
          ),
        ),
      );
    }

    if (_queryController.text.trim().isEmpty) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.search, size: 56, color: AppColors.textSecondaryLight),
            SizedBox(height: 12),
            Text(
              'Search across all assigned services',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppColors.textPrimaryLight),
            ),
            SizedBox(height: 4),
            Text(
              'Find records, appointments, prescriptions and customers.',
              style: TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
            ),
          ],
        ),
      );
    }

    if (_results.isEmpty) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inbox_outlined, size: 56, color: AppColors.textSecondaryLight),
            SizedBox(height: 12),
            Text('No matching records found', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
          ],
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.all(12),
      itemCount: _results.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, index) {
        final item = _results[index];
        final serviceKey = item['service_key']?.toString() ?? 'general';
        final moduleKey = item['module_key']?.toString() ?? 'records';
        final title = item['title']?.toString() ?? 'Record';
        final snippet = item['snippet']?.toString() ?? '';
        final status = item['status']?.toString() ?? 'active';
        final recordId = item['record_id']?.toString() ?? '$index';

        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.borderLight),
          ),
          child: ListTile(
            title: Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: const Color(0xFFDCFCE7),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    serviceKey.toUpperCase(),
                    style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF166534)),
                  ),
                ),
              ],
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 4),
                Text(snippet, style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight)),
                const SizedBox(height: 2),
                Text('Status: ${status.toUpperCase()}', style: const TextStyle(fontSize: 10.5, color: Color(0xFF0284C7))),
              ],
            ),
            trailing: const Icon(Icons.chevron_right, size: 18, color: Colors.grey),
            onTap: () {
              final config = context.read<AppConfig>();
              final storage = SecureStorageService();
              final apiClient = ApiClient(config: config, storage: storage, onSessionExpired: () {});
              final adapter = ServiceAdapterRegistry(apiClient).getAdapter(serviceKey);

              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (ctx) => GenericDetailScreen(
                    adapter: adapter,
                    moduleKey: moduleKey,
                    recordId: recordId,
                    recordTitle: title,
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  String _formatServiceName(String key) {
    if (key == 'doctor') return 'Doctor & Clinic';
    if (key == 'ecommerce') return 'Pharmacy & Store';
    if (key == 'booking') return 'Salon & Booking';
    return key[0].toUpperCase() + key.substring(1);
  }
}
