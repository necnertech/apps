import 'package:flutter/material.dart';

enum DegradationReason {
  none,
  offline,
  serverUnavailable,
  serviceDisabled,
  permissionDenied,
}

class OfflineDegradedBanner extends StatelessWidget {
  final DegradationReason reason;
  final String? lastSyncedAt;
  final VoidCallback? onRetry;

  const OfflineDegradedBanner({
    super.key,
    required this.reason,
    this.lastSyncedAt,
    this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    if (reason == DegradationReason.none) {
      return const SizedBox.shrink();
    }

    Color bgColor;
    Color textColor;
    IconData icon;
    String message;

    switch (reason) {
      case DegradationReason.offline:
        bgColor = const Color(0xFFFEF3C7);
        textColor = const Color(0xFF92400E);
        icon = Icons.wifi_off;
        message = 'You are offline. Showing cached records${lastSyncedAt != null ? ' (synced $lastSyncedAt).' : '.'}';
        break;
      case DegradationReason.serverUnavailable:
        bgColor = const Color(0xFFFEE2E2);
        textColor = const Color(0xFF991B1B);
        icon = Icons.cloud_off;
        message = 'Gateway temporarily unreachable. Retrying automatically...';
        break;
      case DegradationReason.serviceDisabled:
        bgColor = const Color(0xFFF3F4F6);
        textColor = const Color(0xFF4B5563);
        icon = Icons.block;
        message = 'This service is currently disabled in your subscription.';
        break;
      case DegradationReason.permissionDenied:
        bgColor = const Color(0xFFFEE2E2);
        textColor = const Color(0xFF991B1B);
        icon = Icons.lock_outline;
        message = 'Insufficient permissions to perform write actions on this module.';
        break;
      case DegradationReason.none:
        return const SizedBox.shrink();
    }

    return Container(
      width: double.infinity,
      color: bgColor,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Icon(icon, size: 16, color: textColor),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              message,
              style: TextStyle(fontSize: 12, color: textColor, fontWeight: FontWeight.w500),
            ),
          ),
          if (onRetry != null && reason == DegradationReason.offline)
            TextButton(
              onPressed: onRetry,
              style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(40, 24)),
              child: Text('Retry', style: TextStyle(color: textColor, fontWeight: FontWeight.bold, fontSize: 12)),
            ),
        ],
      ),
    );
  }
}
