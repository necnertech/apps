import 'package:flutter/material.dart';
import '../../../app/theme/app_colors.dart';
import '../../../data/models/module_schema_models.dart';
import '../engine/service_adapter.dart';

class SchemaFormScreen extends StatefulWidget {
  final MerchantServiceAdapter adapter;
  final ActionDefinition actionDefinition;
  final VoidCallback? onSuccess;

  const SchemaFormScreen({
    super.key,
    required this.adapter,
    required this.actionDefinition,
    this.onSuccess,
  });

  @override
  State<SchemaFormScreen> createState() => _SchemaFormScreenState();
}

class _SchemaFormScreenState extends State<SchemaFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _formData = {};
  bool _isSubmitting = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    for (final field in widget.actionDefinition.fields) {
      if (field.defaultValue != null) {
        _formData[field.key] = field.defaultValue;
      }
    }
  }

  Future<void> _submitForm() async {
    if (_isSubmitting) return; // Duplicate-submit prevention
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();

    setState(() {
      _isSubmitting = true;
      _errorMessage = null;
    });

    final result = await widget.adapter.executeAction(
      widget.actionDefinition.actionKey,
      _formData,
    );

    if (mounted) {
      result.when(
        success: (data) {
          setState(() => _isSubmitting = false);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${widget.actionDefinition.title} submitted successfully!'),
              backgroundColor: AppColors.primaryEmerald,
            ),
          );
          widget.onSuccess?.call();
          Navigator.of(context).pop(true);
        },
        failure: (err) {
          setState(() {
            _isSubmitting = false;
            _errorMessage = err.message;
          });
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.actionDefinition.title),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (widget.actionDefinition.description.isNotEmpty) ...[
                  Text(
                    widget.actionDefinition.description,
                    style: const TextStyle(fontSize: 13, color: AppColors.textSecondaryLight),
                  ),
                  const SizedBox(height: 20),
                ],

                if (_errorMessage != null) ...[
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color: AppColors.badgeRed.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.badgeRed.withValues(alpha: 0.4)),
                    ),
                    child: Text(
                      _errorMessage!,
                      style: const TextStyle(fontSize: 12, color: AppColors.badgeRed),
                    ),
                  ),
                ],

                // Render dynamic fields
                ...widget.actionDefinition.fields.map(_buildFieldWidget),

                const SizedBox(height: 32),

                // Submit Button
                ElevatedButton(
                  onPressed: _isSubmitting ? null : _submitForm,
                  child: _isSubmitting
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        )
                      : Text('Submit ${widget.actionDefinition.title}'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFieldWidget(FieldDefinition field) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                field.label,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimaryLight),
              ),
              if (field.required)
                const Text(' *', style: TextStyle(color: AppColors.badgeRed, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 6),
          if (field.type == FieldType.boolean)
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: Text(field.placeholder ?? field.label, style: const TextStyle(fontSize: 13)),
              value: _formData[field.key] == true,
              onChanged: (val) => setState(() => _formData[field.key] = val),
            )
          else if (field.type == FieldType.select && field.options != null)
            DropdownButtonFormField<String>(
              initialValue: _formData[field.key] as String?,
              items: field.options!
                  .map((opt) => DropdownMenuItem(value: opt, child: Text(opt, style: const TextStyle(fontSize: 13))))
                  .toList(),
              onChanged: (val) => _formData[field.key] = val,
              validator: (val) {
                if (field.required && (val == null || val.isEmpty)) {
                  return 'Please select a value';
                }
                return null;
              },
            )
          else
            TextFormField(
              initialValue: field.defaultValue,
              maxLines: field.type == FieldType.multiline ? 3 : 1,
              keyboardType: _getKeyboardType(field.type),
              decoration: InputDecoration(
                hintText: field.placeholder,
              ),
              onSaved: (val) => _formData[field.key] = val?.trim(),
              validator: (val) {
                if (field.required && (val == null || val.trim().isEmpty)) {
                  return 'This field is required';
                }
                return null;
              },
            ),
        ],
      ),
    );
  }

  TextInputType _getKeyboardType(FieldType type) {
    switch (type) {
      case FieldType.number:
      case FieldType.currency:
        return const TextInputType.numberWithOptions(decimal: true);
      case FieldType.multiline:
        return TextInputType.multiline;
      default:
        return TextInputType.text;
    }
  }
}
