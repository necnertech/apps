import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../app/theme/app_colors.dart';
import '../../../data/models/service_models.dart';
import '../engine/service_adapter.dart';

class ServiceDashboardView extends StatelessWidget {
  final ServiceManifest manifest;
  final MerchantServiceAdapter adapter;
  final VoidCallback onRefresh;
  const ServiceDashboardView({super.key, required this.manifest, required this.adapter, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    // A service screen must contain ONLY the functions belonging to the
    // selected assigned service. Common merchant functions live under the
    // separate Settings screen.
    final serviceModules = manifest.modules.where((m) => !m.common).toList();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _header(context, serviceModules.length),
      const SizedBox(height: 14),
      _sectionTitle('Service Functions'),
      const SizedBox(height: 8),
      _moduleList(context, serviceModules),
    ]);
  }

  Widget _header(BuildContext context, int count) => Container(
    padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFF075E54), Color(0xFF008069)], begin: Alignment.topLeft, end: Alignment.bottomRight),
      borderRadius: BorderRadius.circular(16),
    ),
    child: Row(children: [
      Container(width: 50, height: 50, decoration: BoxDecoration(color: Colors.white.withOpacity(.16), borderRadius: BorderRadius.circular(14)), alignment: Alignment.center,
        child: const Icon(Icons.business_center_rounded, color: Colors.white, size: 27)),
      const SizedBox(width: 13),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(manifest.serviceName, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
        const SizedBox(height: 4), Text('$count functions available', style: TextStyle(color: Colors.white.withOpacity(.86), fontSize: 12)),
      ])),
      IconButton(tooltip: 'Refresh', onPressed: onRefresh, icon: const Icon(Icons.refresh_rounded, color: Colors.white)),
    ]),
  );

  Widget _sectionTitle(String title) => Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimaryLight));

  Widget _moduleList(BuildContext context, List<ServiceModule> modules) => modules.isEmpty ? _empty('No service functions were published for this service.') : _listCard(context, modules);

  Widget _groupedCommonList(BuildContext context, List<ServiceModule> modules) {
    final groups = <String, List<ServiceModule>>{};
    for (final m in modules) groups.putIfAbsent(m.group.isEmpty ? 'Common' : m.group, () => []).add(m);
    return Column(children: groups.entries.map((e) => Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.only(left: 4, bottom: 7), child: Text(e.key, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textSecondaryLight))),
        _listCard(context, e.value),
      ]),
    )).toList());
  }

  Widget _listCard(BuildContext context, List<ServiceModule> modules) => Container(
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.borderLight)),
    child: ListView.separated(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: modules.length,
      separatorBuilder: (_, __) => Divider(height: 1, color: Colors.grey.shade200),
      itemBuilder: (context, index) => _functionTile(context, modules[index])),
  );

  Widget _functionTile(BuildContext context, ServiceModule module) {
    final enabled = module.capability == CapabilityState.available || module.capability == CapabilityState.readOnly;
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: enabled ? () => context.push('/services/${adapter.serviceKey}/modules/${module.moduleKey}', extra: {'adapter': adapter, 'module': module}) : null,
      child: Padding(padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11), child: Row(children: [
        Container(width: 42, height: 42, decoration: BoxDecoration(color: enabled ? const Color(0xFFE8F5E9) : Colors.grey.shade100, borderRadius: BorderRadius.circular(11)), alignment: Alignment.center,
          child: Text(_iconText(module.icon), style: const TextStyle(fontSize: 20))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(module.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: enabled ? AppColors.textPrimaryLight : Colors.grey)),
          if (module.actions.isNotEmpty) ...[const SizedBox(height: 3), Text('${module.actions.length} actions', style: const TextStyle(fontSize: 10.5, color: AppColors.textSecondaryLight))],
        ])),
        if (module.capability != CapabilityState.available) Padding(padding: const EdgeInsets.only(right: 5), child: Text(module.capability.label, style: const TextStyle(fontSize: 9, color: AppColors.textSecondaryLight))),
        const Icon(Icons.chevron_right_rounded, color: Colors.grey),
      ])),
    );
  }

  Widget _empty(String text) => Container(width: double.infinity, padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.borderLight)), child: Text(text, style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight)));
  String _iconText(String icon) => icon.isEmpty || icon == 'grid' || icon.startsWith('fa-') ? '▦' : icon;
}
