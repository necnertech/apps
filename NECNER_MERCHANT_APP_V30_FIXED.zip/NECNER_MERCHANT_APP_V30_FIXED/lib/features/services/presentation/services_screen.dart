import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../../app/theme/app_colors.dart';
import '../state/services_controller.dart';
import 'offline_degraded_banner.dart';

class ServicesScreen extends StatefulWidget {
  const ServicesScreen({super.key});

  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final ctrl = context.read<ServicesController>();
      // main.dart already starts discovery immediately after authentication.
      // This call is guarded by the controller's in-flight request protection,
      // so it is safe on cold navigation and on restored sessions as well.
      await ctrl.loadAssignedServices();
      if (!mounted) return;
      if (ctrl.services.length == 1) {
        context.go('/services/${ctrl.services.first.serviceKey}');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final ctrl = context.watch<ServicesController>();
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: AppColors.primaryTeal,
        title: const Text('Services', style: TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            tooltip: 'Settings',
            onPressed: () => context.push('/settings'),
          ),
        ],
      ),
      body: Column(
        children: [
          const OfflineDegradedBanner(reason: DegradationReason.none),
          Expanded(child: _content(ctrl)),
        ],
      ),
    );
  }

  Widget _content(ServicesController ctrl) {
    if (ctrl.isLoading && ctrl.services.isEmpty) {
      return const Center(child: CircularProgressIndicator(color: AppColors.primaryEmerald));
    }
    if (ctrl.error != null && ctrl.services.isEmpty) {
      return Center(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.error_outline, size: 48, color: AppColors.badgeRed),
          const SizedBox(height: 12),
          Text(ctrl.error!.message, textAlign: TextAlign.center),
          const SizedBox(height: 18),
          ElevatedButton.icon(onPressed: ctrl.loadAssignedServices, icon: const Icon(Icons.refresh), label: const Text('Retry')),
        ]),
      ));
    }
    if (ctrl.services.isEmpty) {
      return RefreshIndicator(
        onRefresh: ctrl.loadAssignedServices,
        child: ListView(children: const [SizedBox(height: 180), Center(child: Text('No services assigned to this merchant'))]),
      );
    }

    return RefreshIndicator(
      color: AppColors.primaryEmerald,
      onRefresh: ctrl.loadAssignedServices,
      child: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(14, 4, 14, 20),
            sliver: SliverToBoxAdapter(child: Text(
              'Your Assigned Services',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
            )),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (context, index) => _serviceCard(ctrl.services[index]),
                childCount: ctrl.services.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 0.98,
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(14, 18, 14, 8),
            sliver: SliverToBoxAdapter(child: _settingsButton()),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 28)),
        ],
      ),
    );
  }

  Widget _settingsButton() => Container(
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppColors.borderLight),
    ),
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      leading: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: const Color(0xFFE8F5E9),
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Icon(Icons.settings_outlined, color: AppColors.primaryTeal),
      ),
      title: const Text('Settings', style: TextStyle(fontWeight: FontWeight.w800)),
      subtitle: const Text('Common merchant settings & tools'),
      trailing: const Icon(Icons.chevron_right_rounded),
      onTap: () => context.push('/settings'),
    ),
  );

  Widget _serviceCard(dynamic item) {
    final color = _getServiceColor(item.category);
    return Card(
      elevation: 0,
      margin: EdgeInsets.zero,
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: AppColors.borderLight)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => context.go('/services/${item.serviceKey}'),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 13, 10, 11),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(width: 46, height: 46, decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(13)), child: Icon(_getServiceIcon(item.category, item.serviceKey), color: color, size: 25)),
              const Spacer(),
              const Icon(Icons.chevron_right_rounded, color: AppColors.textSecondaryLight, size: 19),
            ]),
            const Spacer(),
            Text(item.serviceName, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800, color: AppColors.textPrimaryLight)),
            const SizedBox(height: 4),
            Text('${item.permissions.length} permissions', style: const TextStyle(fontSize: 10.5, color: AppColors.textSecondaryLight)),
            const SizedBox(height: 7),
            Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3), decoration: BoxDecoration(color: color.withValues(alpha: .09), borderRadius: BorderRadius.circular(6)), child: Text(item.category.toString().toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: color, letterSpacing: .3))),
          ]),
        ),
      ),
    );
  }

  Color _getServiceColor(String category) {
    switch (category.toLowerCase()) {
      case 'healthcare': return const Color(0xFF008069);
      case 'retail': return const Color(0xFF0284C7);
      case 'food': return const Color(0xFFD97706);
      case 'travel': return const Color(0xFF7C3AED);
      case 'transport': return const Color(0xFF2563EB);
      default: return const Color(0xFF0F766E);
    }
  }

  IconData _getServiceIcon(String category, String key) {
    final k = key.toLowerCase();
    if (k.contains('doctor') || k.contains('clinic')) return Icons.medical_services_rounded;
    if (k.contains('ecommerce') || k.contains('store') || k.contains('shop')) return Icons.shopping_cart_rounded;
    if (k.contains('booking') || k.contains('hotel')) return Icons.calendar_month_rounded;
    if (k.contains('pharmacy')) return Icons.medication_rounded;
    if (k.contains('restaurant') || k.contains('food')) return Icons.restaurant_rounded;
    if (k.contains('taxi') || k.contains('cab')) return Icons.local_taxi_rounded;
    if (k.contains('pathology') || k.contains('lab')) return Icons.biotech_rounded;
    switch (category.toLowerCase()) {
      case 'healthcare': return Icons.local_hospital_rounded;
      case 'retail': return Icons.storefront_rounded;
      case 'food': return Icons.restaurant_rounded;
      default: return Icons.business_center_rounded;
    }
  }
}
