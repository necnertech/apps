import 'package:flutter/foundation.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/logging/app_logger.dart';
import '../../../data/models/service_models.dart';
import '../../../data/repositories/service_repository.dart';

class ServicesController extends ChangeNotifier {
  final ServiceRepository _repository;

  bool _isLoading = false;
  List<ServiceDiscoveryItem> _services = [];
  final Map<String, ServiceManifest> _manifests = {};
  AppException? _error;
  Future<void>? _activeLoad;

  ServicesController(this._repository);

  bool get isLoading => _isLoading;
  List<ServiceDiscoveryItem> get services => _services;
  AppException? get error => _error;

  ServiceManifest? getManifest(String serviceKey) => _manifests[serviceKey];

  /// Loads services actively assigned to the merchant tenant
  Future<void> loadAssignedServices() {
    // Login bootstrap and ServicesScreen can both request discovery at nearly
    // the same time. Reuse the in-flight request instead of hitting the
    // endpoint twice and racing two state updates.
    final active = _activeLoad;
    if (active != null) return active;

    final future = _loadAssignedServicesInternal();
    _activeLoad = future;
    return future.whenComplete(() => _activeLoad = null);
  }

  Future<void> _loadAssignedServicesInternal() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    AppLogger.info('Discovering assigned merchant services from registry...');

    try {
      final result = await _repository.getAssignedServices();

      result.when(
        success: (items) {
          // The backend is authoritative. Keep only active+assigned records
          // even if a future gateway version returns additional metadata.
          _services = items
              .where((item) => item.active && item.assigned)
              .toList(growable: false);
          _isLoading = false;
          _error = null;
          AppLogger.info('Discovered ${_services.length} active assigned services.');
          notifyListeners();
        },
        failure: (err) {
          _error = err;
          _isLoading = false;
          AppLogger.error(
            'Service discovery failed: ${err.errorCode} / ${err.statusCode} / ${err.message}',
          );
          notifyListeners();
        },
      );
    } catch (e, st) {
      _isLoading = false;
      _error = const AppException(
        errorCode: 'SERVICE_DISCOVERY_PARSE_ERROR',
        message: 'Unable to read assigned services from the server. Please retry.',
      );
      AppLogger.error('Service discovery unexpected exception: $e\n$st');
      notifyListeners();
    }
  }

  /// Loads dynamic manifest with explicit capability states
  Future<ServiceManifest?> loadManifest(String serviceKey) async {
    if (_manifests.containsKey(serviceKey)) {
      return _manifests[serviceKey];
    }

    _isLoading = true;
    notifyListeners();

    final result = await _repository.getServiceManifest(serviceKey);

    return result.when(
      success: (manifest) {
        _manifests[serviceKey] = manifest;
        _isLoading = false;
        notifyListeners();
        return manifest;
      },
      failure: (err) {
        _error = err;
        _isLoading = false;
        notifyListeners();
        return null;
      },
    );
  }
}
