import 'package:flutter/material.dart';
import '../../../app/theme/app_colors.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../chat/state/chat_controller.dart';
import '../../notifications/state/notifications_controller.dart';

class MainShellScreen extends StatelessWidget {
  final StatefulNavigationShell navigationShell;

  const MainShellScreen({
    super.key,
    required this.navigationShell,
  });

  void _onTap(int index) {
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    final chatCtrl = context.watch<ChatController>();
    final notifCtrl = context.watch<NotificationsController>();

    final chatUnread = chatCtrl.totalUnreadCount;
    final alertUnread = notifCtrl.unreadCount;

    return Scaffold(
      body: navigationShell,
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: AppColors.primaryTeal,
        currentIndex: navigationShell.currentIndex,
        onTap: _onTap,
        selectedItemColor: AppColors.accentGreen,
        unselectedItemColor: const Color(0xFF8B9AA3),
        type: BottomNavigationBarType.fixed,
        selectedFontSize: 12,
        unselectedFontSize: 12,
        elevation: 8,
        items: [
          BottomNavigationBarItem(
            icon: Badge(
              isLabelVisible: chatUnread > 0,
              label: Text('$chatUnread'),
              backgroundColor: const Color(0xFF25D366),
              child: const Icon(Icons.chat_bubble_outline_rounded),
            ),
            activeIcon: Badge(
              isLabelVisible: chatUnread > 0,
              label: Text('$chatUnread'),
              backgroundColor: const Color(0xFF25D366),
              child: const Icon(Icons.chat_bubble_rounded),
            ),
            label: 'Chats',
          ),
          BottomNavigationBarItem(
            icon: Badge(
              isLabelVisible: alertUnread > 0,
              label: Text('$alertUnread'),
              backgroundColor: const Color(0xFFDC2626),
              child: const Icon(Icons.notifications_none_rounded),
            ),
            activeIcon: Badge(
              isLabelVisible: alertUnread > 0,
              label: Text('$alertUnread'),
              backgroundColor: const Color(0xFFDC2626),
              child: const Icon(Icons.notifications_rounded),
            ),
            label: 'Notifications',
          ),
          const BottomNavigationBarItem(
            icon: Icon(Icons.grid_view_rounded),
            activeIcon: Icon(Icons.grid_view_sharp),
            label: 'Services',
          ),
          const BottomNavigationBarItem(
            icon: Icon(Icons.settings_outlined),
            activeIcon: Icon(Icons.settings_rounded),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
