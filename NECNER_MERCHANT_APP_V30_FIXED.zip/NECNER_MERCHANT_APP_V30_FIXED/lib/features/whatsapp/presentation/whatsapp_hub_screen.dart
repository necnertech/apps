import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../app/config/app_config.dart';
import '../../../app/theme/app_colors.dart';
import '../../../core/network/api_client.dart';
import '../../../core/secure_storage/secure_storage_service.dart';

class WhatsAppHubScreen extends StatefulWidget {
  const WhatsAppHubScreen({super.key});
  @override State<WhatsAppHubScreen> createState() => _WhatsAppHubScreenState();
}

class _WhatsAppHubScreenState extends State<WhatsAppHubScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  late final ApiClient _api;
  bool _loading = true;
  String? _error;
  List<Map<String,dynamic>> _contacts=[];
  List<Map<String,dynamic>> _groups=[];
  List<Map<String,dynamic>> _templates=[];
  List<Map<String,dynamic>> _campaigns=[];

  @override void initState(){super.initState();_tabs=TabController(length:4,vsync:this);final cfg=context.read<AppConfig>();_api=ApiClient(config:cfg,storage:SecureStorageService(),onSessionExpired:(){});_loadAll();}
  @override void dispose(){_tabs.dispose();super.dispose();}

  Future<List<Map<String,dynamic>>> _get(String path) async {
    final r=await _api.get<Map<String,dynamic>>(path,parser:(d)=>Map<String,dynamic>.from(d as Map));
    List<Map<String,dynamic>> out=[];r.when(success:(d){final a=d['items'];if(a is List)out=a.whereType<Map>().map((e)=>Map<String,dynamic>.from(e)).toList();},failure:(e){throw Exception(e.message);});return out;
  }
  Future<Map<String,dynamic>> _post(String path,Map<String,dynamic> body) async {
    final r=await _api.post<Map<String,dynamic>>(path,data:body,parser:(d)=>Map<String,dynamic>.from(d as Map));Map<String,dynamic> out={};r.when(success:(d){out=d;},failure:(e){throw Exception(e.message);});return out;
  }
  Future<void> _loadAll() async {setState(()=>_loading=true);try{final c=await _get('/mobile/whatsapp/contacts.php');final g=await _get('/mobile/whatsapp/groups.php');final t=await _get('/mobile/whatsapp/templates.php');final b=await _get('/mobile/whatsapp/campaigns.php');if(mounted)setState((){_contacts=c;_groups=g;_templates=t;_campaigns=b;_error=null;_loading=false;});}catch(e){if(mounted)setState((){_error=e.toString();_loading=false;});}}

  @override Widget build(BuildContext context){return Scaffold(backgroundColor:AppColors.backgroundLight,appBar:AppBar(backgroundColor:const Color(0xFF075E54),title:const Text('WhatsApp Business',style:TextStyle(fontWeight:FontWeight.w800)),actions:[IconButton(onPressed:_loadAll,icon:const Icon(Icons.refresh)),],bottom:TabBar(controller:_tabs,isScrollable:true,indicatorColor:const Color(0xFF25D366),tabs:const[Tab(text:'Contacts'),Tab(text:'Groups'),Tab(text:'Templates'),Tab(text:'Bulk Messages')]),),body: _loading ? const Center(child: CircularProgressIndicator(color: Color(0xFF25D366))) : _error != null ? _errorView() : TabBarView(controller: _tabs, children: [_contactsTab(), _groupsTab(), _templatesTab(), _campaignsTab()]));}
  Widget _errorView()=>Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.cloud_off_rounded,size:52,color:Colors.grey),const SizedBox(height:12),Text('WhatsApp data could not be loaded',style:const TextStyle(fontWeight:FontWeight.w700)),const SizedBox(height:6),Text(_error!,textAlign:TextAlign.center,style:const TextStyle(color:Colors.grey)),const SizedBox(height:16),ElevatedButton.icon(onPressed:_loadAll,icon:const Icon(Icons.refresh),label:const Text('Retry'))])));
  Widget _contactsTab()=>_sectionList(_contacts,empty:'No contacts saved yet.',icon:Icons.contacts_rounded,add:()=>_contactDialog());
  Widget _groupsTab()=>_sectionList(_groups,empty:'No groups created yet.',icon:Icons.groups_rounded,add:()=>_groupDialog(),titleKey:'group_name',subtitleKey:'member_count');
  Widget _templatesTab()=>_sectionList(_templates,empty:'No templates yet.',icon:Icons.article_rounded,add:()=>_templateDialog(),titleKey:'template_name',subtitleKey:'status');
  Widget _campaignsTab()=>_sectionList(_campaigns,empty:'No bulk campaigns yet.',icon:Icons.campaign_rounded,add:()=>_campaignDialog(),titleKey:'name',subtitleKey:'status');
  Widget _sectionList(List<Map<String,dynamic>> items,{required String empty,required IconData icon,required VoidCallback add,String titleKey='name',String subtitleKey='phone'}){return RefreshIndicator(onRefresh:_loadAll,color:const Color(0xFF25D366),child:items.isEmpty?ListView(children:[const SizedBox(height:140),Center(child:Text(empty,style:const TextStyle(color:Colors.grey))),const SizedBox(height:18),Center(child:FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:const Text('Create')))]):ListView.separated(padding:const EdgeInsets.all(14),itemCount:items.length+1,itemBuilder:(c,i){if(i==0)return _heroCard(icon);final x=items[i-1];return Card(elevation:0,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16),side:const BorderSide(color:Color(0xFFE5E7EB))),child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:16,vertical:5),leading:CircleAvatar(backgroundColor:const Color(0xFFE8F5E9),child:Icon(icon,color:const Color(0xFF075E54))),title:Text((x[titleKey]??'Item').toString(),style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text((x[subtitleKey]??'').toString(),style:const TextStyle(color:Colors.grey)),trailing:const Icon(Icons.chevron_right_rounded)));},separatorBuilder:(_,__)=>const SizedBox(height:8)));}
  Widget _heroCard(IconData icon)=>Container(margin:const EdgeInsets.only(bottom:8),padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:const Color(0xFF075E54),borderRadius:BorderRadius.circular(18)),child:Row(children:[CircleAvatar(radius:24,backgroundColor:const Color(0xFF25D366),child:Icon(icon,color:Colors.white)),const SizedBox(width:12),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Communication Center',style:TextStyle(color:Colors.white,fontSize:16,fontWeight:FontWeight.w800)),SizedBox(height:4),Text('Contacts • Groups • Templates • Bulk messaging',style:TextStyle(color:Colors.white70,fontSize:12))]))]));

  Future<void> _contactDialog() async {final name=TextEditingController(),phone=TextEditingController(),email=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(c)=>_formDialog('Save Customer Contact',[_field(name,'Customer name'),_field(phone,'WhatsApp number (+91...)',keyboard:TextInputType.phone),_field(email,'Email (optional)',keyboard:TextInputType.emailAddress)],()=>_post('/mobile/whatsapp/contacts.php',{'action':'create','name':name.text,'phone':phone.text,'email':email.text,'opt_in_status':'opted_in'})));if(ok==true)_loadAll();}
  Future<void> _groupDialog() async {final name=TextEditingController(),desc=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(c)=>_formDialog('Create WhatsApp Group',[_field(name,'Group name'),_field(desc,'Description')],()=>_post('/mobile/whatsapp/groups.php',{'action':'create','group_name':name.text,'description':desc.text})));if(ok==true)_loadAll();}
  Future<void> _templateDialog() async {final name=TextEditingController(),body=TextEditingController(),footer=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(c)=>_formDialog('Create Message Template',[_field(name,'Template name (lowercase)'),_field(body,'Message body e.g. Hello {{1}}',max:5),_field(footer,'Footer (optional)')],()=>_post('/mobile/whatsapp/templates.php',{'action':'create','template_name':name.text,'body':body.text,'footer':footer.text,'category':'UTILITY','language':'en_US'})));if(ok==true)_loadAll();}
  Future<void> _campaignDialog() async {final name=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(c)=>_formDialog('New Bulk Campaign',[_field(name,'Campaign name')],()=>_post('/mobile/whatsapp/campaigns.php',{'action':'create','name':name.text,'target_type':'opt_in_only'})));if(ok==true)_loadAll();}
  Widget _field(TextEditingController c,String hint,{TextInputType? keyboard,int max=1})=>TextField(controller:c,keyboardType:keyboard,maxLines:max,decoration:InputDecoration(labelText:hint,border:OutlineInputBorder(borderRadius:BorderRadius.circular(12))));
  Widget _formDialog(String title,List<Widget> fields,Future<Map<String,dynamic>> Function() submit)=>AlertDialog(title:Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),content:SizedBox(width:430,child:Column(mainAxisSize:MainAxisSize.min,children:fields.map((f)=>Padding(padding:const EdgeInsets.only(bottom:10),child:f)).toList())),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Cancel')),FilledButton(onPressed:()async{try{await submit();if(mounted)Navigator.pop(context,true);}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}},child:const Text('Save'))]);
}
