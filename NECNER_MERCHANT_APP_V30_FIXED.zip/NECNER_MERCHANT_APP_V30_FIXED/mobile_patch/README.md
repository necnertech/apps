NECNER Merchant App V29 Mobile Patch

Upload these NEW files only (do not replace existing production files):

1. mobile/chat/start.php
   Starts/reuses a tenant-scoped chat for a CRM contact.

2. mobile/workspace-bridge.php
   Converts the authenticated mobile Bearer session into the existing merchant web session and opens the existing business pages inside the app.

3. mobile/storefront-url.php
   Returns the current merchant's real public storefront URL for the chat URL card.

The Flutter app is intentionally still registry/manifest driven. Existing service business logic remains on the server.
