<?php
declare(strict_types=1);

/**
 * NEW endpoint: starts/reuses a merchant mobile chat for an existing CRM
 * contact. Upload as /public_html/mobile/chat/start.php
 *
 * Existing mobile/index.php is not modified.
 */
if (!defined('NECNER_APP_INIT')) define('NECNER_APP_INIT', true);
if (!defined('MOBILE_PLATFORM_REQUEST')) define('MOBILE_PLATFORM_REQUEST', true);
if (empty($_SERVER['HTTP_AUTHORIZATION']) && !empty($_SERVER['HTTP_X_AUTHORIZATION'])) {
    $_SERVER['HTTP_AUTHORIZATION'] = (string)$_SERVER['HTTP_X_AUTHORIZATION'];
}

require_once dirname(__DIR__, 2) . '/mobile-platform/includes/bootstrap.php';
require_once dirname(__DIR__, 2) . '/mobile-platform/includes/JsonResponse.php';

\MobileJsonResponse::preflight();
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') exit;

try {
    if (!class_exists('SellerAuth')) {
        \MobileJsonResponse::error('Authentication service unavailable.', 'AUTH_UNAVAILABLE', 503);
    }

    $ctx = \SellerAuth::authenticateBearer();
    $pdo = \Database::getConnection();
    $tenantId = (int)$ctx->getTenantId();
    $contactId = (int)($_POST['contact_id'] ?? $_GET['contact_id'] ?? 0);

    if ($contactId <= 0) {
        $raw = file_get_contents('php://input');
        $json = $raw !== false ? json_decode($raw, true) : null;
        if (is_array($json)) $contactId = (int)($json['contact_id'] ?? 0);
    }
    if ($contactId <= 0) {
        \MobileJsonResponse::error('A valid contact is required.', 'CONTACT_REQUIRED', 422);
    }

    $contact = $pdo->prepare(
        'SELECT id,name,phone,email,status,opt_in_status FROM contacts WHERE id=:id AND tenant_id=:t LIMIT 1'
    );
    $contact->execute([':id' => $contactId, ':t' => $tenantId]);
    $row = $contact->fetch(PDO::FETCH_ASSOC);
    if (!$row) \MobileJsonResponse::error('Contact not found.', 'CONTACT_NOT_FOUND', 404);

    $phone = trim((string)($row['phone'] ?? ''));
    $name = trim((string)($row['name'] ?? '')) ?: ($phone !== '' ? $phone : 'Contact');

    // The mobile chat table is provisioned by the existing chat system. Use
    // its actual columns so this additive endpoint remains compatible with
    // small schema variations across installations.
    $columnsStmt = $pdo->prepare(
        'SELECT COLUMN_NAME FROM information_schema.columns WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=:table'
    );
    $columnsStmt->execute([':table' => 'mobile_chat_conversations']);
    $columns = array_map('strval', $columnsStmt->fetchAll(PDO::FETCH_COLUMN));
    if (!$columns) {
        \MobileJsonResponse::error('Mobile chat storage is not configured on this server.', 'CHAT_STORAGE_UNAVAILABLE', 503);
    }

    $existing = null;
    if (in_array('contact_id', $columns, true)) {
        $q = $pdo->prepare('SELECT * FROM mobile_chat_conversations WHERE tenant_id=:t AND contact_id=:c ORDER BY id DESC LIMIT 1');
        $q->execute([':t' => $tenantId, ':c' => $contactId]);
        $existing = $q->fetch(PDO::FETCH_ASSOC) ?: null;
    }
    if (!$existing && $phone !== '' && in_array('customer_phone', $columns, true)) {
        $q = $pdo->prepare('SELECT * FROM mobile_chat_conversations WHERE tenant_id=:t AND customer_phone=:p ORDER BY id DESC LIMIT 1');
        $q->execute([':t' => $tenantId, ':p' => $phone]);
        $existing = $q->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    if ($existing) {
        \MobileJsonResponse::ok($existing, 'Conversation opened');
    }

    $values = [];
    $params = [];
    $put = static function(string $column, mixed $value) use (&$values, &$params, $columns): void {
        if (!in_array($column, $columns, true)) return;
        $key = ':v_' . preg_replace('/[^a-z0-9_]/i', '_', $column);
        $values[] = '`' . $column . '`';
        $params[$key] = $value;
        $params['_keys'][] = $key;
    };

    $put('tenant_id', $tenantId);
    $put('contact_id', $contactId);
    $put('conversation_key', 'contact_' . $contactId);
    $put('customer_name', $name);
    $put('customer_phone', $phone);
    $put('service_key', 'general');
    $put('service_label', 'Customer Chat');
    $put('last_message', '');
    $put('last_message_time', date('Y-m-d H:i:s'));
    $put('unread_count', 0);
    $put('status', 'open');
    $put('created_at', date('Y-m-d H:i:s'));
    $put('updated_at', date('Y-m-d H:i:s'));

    $keys = $params['_keys'] ?? [];
    unset($params['_keys']);
    if (!$values || !$keys) {
        \MobileJsonResponse::error('Mobile chat table does not expose a writable conversation schema.', 'CHAT_SCHEMA_UNSUPPORTED', 503);
    }

    $placeholders = implode(',', $keys);
    $sql = 'INSERT INTO mobile_chat_conversations (' . implode(',', $values) . ') VALUES (' . $placeholders . ')';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $newId = (int)$pdo->lastInsertId();

    $q = $pdo->prepare('SELECT * FROM mobile_chat_conversations WHERE id=:id AND tenant_id=:t LIMIT 1');
    $q->execute([':id' => $newId, ':t' => $tenantId]);
    $conversation = $q->fetch(PDO::FETCH_ASSOC);
    if (!$conversation) {
        \MobileJsonResponse::error('Conversation was created but could not be reloaded.', 'CHAT_CREATE_RELOAD_FAILED', 500);
    }

    \MobileJsonResponse::ok($conversation, 'Conversation started');
} catch (Throwable $e) {
    error_log('[MOBILE CHAT START] ' . $e->getMessage());
    \MobileJsonResponse::error('Unable to start the chat.', 'CHAT_START_FAILED', 500);
}
