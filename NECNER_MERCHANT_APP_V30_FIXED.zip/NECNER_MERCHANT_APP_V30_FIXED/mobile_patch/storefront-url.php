<?php
declare(strict_types=1);

/**
 * NEW endpoint only.
 * Upload as /public_html/mobile/storefront-url.php
 * Returns the authenticated merchant's real public storefront URL.
 */
if (!defined('NECNER_APP_INIT')) define('NECNER_APP_INIT', true);
if (!defined('MOBILE_PLATFORM_REQUEST')) define('MOBILE_PLATFORM_REQUEST', true);
if (empty($_SERVER['HTTP_AUTHORIZATION']) && !empty($_SERVER['HTTP_X_AUTHORIZATION'])) {
    $_SERVER['HTTP_AUTHORIZATION'] = (string)$_SERVER['HTTP_X_AUTHORIZATION'];
}

require_once dirname(__DIR__) . '/mobile-platform/includes/bootstrap.php';
require_once dirname(__DIR__) . '/mobile-platform/includes/JsonResponse.php';

\MobileJsonResponse::preflight();
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') exit;

try {
    if (!class_exists('SellerAuth') || !method_exists('SellerAuth', 'authenticateBearer')) {
        \MobileJsonResponse::error('Merchant authentication service is unavailable.', 'AUTH_UNAVAILABLE', 503);
    }

    $ctx = \SellerAuth::authenticateBearer();
    $tenantId = (int)$ctx->getTenantId();
    if ($tenantId <= 0) {
        \MobileJsonResponse::error('Active merchant session is required.', 'AUTHENTICATION_REQUIRED', 401);
    }

    $db = \WaSaaS\Database::getInstance();
    $tenant = $db->fetchOne('SELECT * FROM tenants WHERE id=:id LIMIT 1', [':id' => $tenantId]);
    if (!$tenant) {
        \MobileJsonResponse::error('Merchant account was not found.', 'TENANT_NOT_FOUND', 404);
    }

    $url = '';
    if (class_exists('\\WaSaaS\\ServiceRegistry') && method_exists('\\WaSaaS\\ServiceRegistry', 'storefrontUrl')) {
        $url = (string)\WaSaaS\ServiceRegistry::storefrontUrl($tenant);
    }

    if ($url === '') {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = (string)($_SERVER['HTTP_HOST'] ?? 'udidesign.in');
        $slug = trim((string)($tenant['storefront_slug'] ?? $tenant['slug'] ?? ''), '/');
        $url = $slug !== '' ? $scheme . '://' . $host . '/store/' . rawurlencode($slug) : $scheme . '://' . $host . '/customer/commerce/store.php';
    }

    \MobileJsonResponse::ok([
        'url' => $url,
        'business_name' => (string)($tenant['business_name'] ?? $tenant['name'] ?? 'Merchant'),
    ], 'Storefront URL loaded');
} catch (Throwable $e) {
    error_log('[MOBILE STOREFRONT URL] ' . $e->getMessage());
    \MobileJsonResponse::error('Unable to load the merchant storefront URL.', 'STOREFRONT_URL_FAILED', 500);
}
