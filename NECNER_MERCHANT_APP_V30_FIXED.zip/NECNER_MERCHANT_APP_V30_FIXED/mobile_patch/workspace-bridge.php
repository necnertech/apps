<?php
declare(strict_types=1);

/**
 * NECNER Merchant Mobile Workspace Bridge — V29
 *
 * NEW FILE ONLY. Upload as:
 *   /public_html/mobile/workspace-bridge.php
 *
 * It converts the Flutter merchant Bearer session into the existing PHP
 * customer workspace session, then opens the REAL existing PHP page.
 * Existing service business pages are not copied into Flutter.
 */

if (!defined('NECNER_APP_INIT')) define('NECNER_APP_INIT', true);
if (!defined('MOBILE_PLATFORM_REQUEST')) define('MOBILE_PLATFORM_REQUEST', true);

// Some Apache/LiteSpeed setups expose the fallback header but not the normal
// Authorization header to PHP. SellerAuth uses Authorization, so normalize it.
if (empty($_SERVER['HTTP_AUTHORIZATION']) && !empty($_SERVER['HTTP_X_AUTHORIZATION'])) {
    $_SERVER['HTTP_AUTHORIZATION'] = (string)$_SERVER['HTTP_X_AUTHORIZATION'];
}

require_once dirname(__DIR__) . '/mobile-platform/includes/bootstrap.php';

function bridge_error(string $message, int $status = 401): never {
    http_response_code($status);
    header('Content-Type: text/plain; charset=utf-8');
    echo $message;
    exit;
}

function bridge_safe_path(string $path): string {
    $path = trim($path);
    if ($path === '') $path = '/customer/dashboard.php';
    if ($path[0] !== '/') $path = '/' . $path;
    if (str_contains($path, '..') || preg_match('~^//|^[a-z][a-z0-9+.-]*://~i', $path)) {
        bridge_error('Invalid workspace path.', 400);
    }
    return $path;
}

try {
    if (!class_exists('SellerAuth') || !method_exists('SellerAuth', 'authenticateBearer')) {
        bridge_error('Merchant authentication service is unavailable.', 503);
    }

    $ctx = \SellerAuth::authenticateBearer();
    $tenantId = (int)$ctx->getTenantId();
    $sellerId = (int)$ctx->getSellerId();
    if ($tenantId <= 0 || $sellerId <= 0) bridge_error('Active merchant session is required.', 401);

    $db = \WaSaaS\Database::getInstance();

    // Load the same role fields used by the normal customer web login.
    $user = $db->fetchOne(
        'SELECT u.*, r.name AS role_name, r.display_name AS role_display
         FROM users u
         LEFT JOIN roles r ON r.id = u.role_id
         WHERE u.id = :user_id AND u.tenant_id = :tenant_id
         LIMIT 1',
        [':user_id' => $sellerId, ':tenant_id' => $tenantId]
    );
    if (!$user) bridge_error('Merchant account was not found.', 403);

    $tenant = $db->fetchOne(
        'SELECT * FROM tenants WHERE id = :tenant_id LIMIT 1',
        [':tenant_id' => $tenantId]
    );
    if (!$tenant || strtolower((string)($tenant['status'] ?? 'active')) !== 'active') {
        bridge_error('Merchant account is inactive.', 403);
    }

    $serviceKey = strtolower(trim((string)($_GET['service'] ?? '')));
    $path = bridge_safe_path((string)($_GET['path'] ?? '/customer/dashboard.php'));

    // Service access is still checked server-side. The Flutter client cannot
    // open an unassigned service simply by changing the URL.
    if ($serviceKey !== '') {
        $assigned = false;
        $tenantService = strtolower(trim((string)($tenant['service_type'] ?? $tenant['panel_key'] ?? '')));
        if ($tenantService !== '' && in_array($tenantService, [$serviceKey, str_replace('store', 'ecommerce', $serviceKey)], true)) {
            $assigned = true;
        }

        foreach (['tenant_service_assignments', 'service_tenant_links'] as $table) {
            try {
                $exists = (int)$db->fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.tables WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table',
                    [':table' => $table]
                )['c'];
                if ($exists < 1) continue;

                $row = $db->fetchOne(
                    "SELECT * FROM `$table` WHERE tenant_id = :tenant_id AND (service_key = :service_key OR service_code = :service_key) LIMIT 1",
                    [':tenant_id' => $tenantId, ':service_key' => $serviceKey]
                );
                if ($row && (($row['active'] ?? 1) === 1 || (string)($row['status'] ?? 'active') === 'active')) {
                    $assigned = true;
                }
            } catch (Throwable $ignored) {
                // Keep the single-service tenant check above as fallback.
            }
        }

        if (!$assigned) bridge_error('This service is not assigned to the current merchant.', 403);

        // Resolve relative service routes from the central registry. For
        // example: service=exports + admin/products.php -> /exports/admin/products.php
        if (!str_starts_with($path, '/')) $path = '/' . $path;
        $service = class_exists('WaSaaS\\ServiceRegistry')
            ? \WaSaaS\ServiceRegistry::get($serviceKey)
            : null;
        $prefix = trim((string)($service['url_prefix'] ?? $service['module_path'] ?? $serviceKey), '/');
        if ($prefix !== '') {
            $servicePrefix = '/' . $prefix . '/';
            $normalized = '/' . ltrim($path, '/');
            if (!str_starts_with($normalized, $servicePrefix) && $normalized !== '/' . $prefix) {
                $path = '/' . $prefix . $normalized;
            }
        }
    }

    // Reuse the existing web authentication/session implementation instead
    // of inventing a second session format for the mobile app.
    if (class_exists('WaSaaS\\Auth') && method_exists('WaSaaS\\Auth', 'login')) {
        \WaSaaS\Auth::login($user);
    } else {
        bridge_error('Merchant web session service is unavailable.', 503);
    }

    $parts = parse_url($path);
    $cleanPath = (string)($parts['path'] ?? $path);
    $query = [];
    if (!empty($parts['query'])) parse_str((string)$parts['query'], $query);
    // Existing PHP customer/service pages already have iframe-safe layouts.
    $query['iframe'] = '1';

    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = (string)($_SERVER['HTTP_HOST'] ?? 'udidesign.in');
    $target = $scheme . '://' . $host . $cleanPath . '?' . http_build_query($query);

    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');
    header('Location: ' . $target, true, 302);
    exit;
} catch (Throwable $e) {
    error_log('[MOBILE WORKSPACE BRIDGE V29] ' . $e->getMessage());
    bridge_error('Unable to open the merchant workspace.', 503);
}
