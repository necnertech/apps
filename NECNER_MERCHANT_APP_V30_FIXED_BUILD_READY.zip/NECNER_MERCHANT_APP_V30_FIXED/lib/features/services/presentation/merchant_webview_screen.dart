import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

import '../../../app/config/app_config.dart';
import '../../../app/theme/app_colors.dart';
import '../../../core/secure_storage/secure_storage_service.dart';

/// Opens the existing merchant workspace with the authenticated mobile
/// session. The web workspace remains the business-data source of truth.
/// Android file selectors are explicitly bridged so HTML image/file inputs
/// work inside the WebView instead of doing nothing.
class MerchantWebViewScreen extends StatefulWidget {
  final String title;
  final String path;
  final String? serviceKey;

  const MerchantWebViewScreen({
    super.key,
    required this.title,
    required this.path,
    this.serviceKey,
  });

  @override
  State<MerchantWebViewScreen> createState() => _MerchantWebViewScreenState();
}

class _MerchantWebViewScreenState extends State<MerchantWebViewScreen> {
  late final WebViewController _controller;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFFF7F8FA))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) => setState(() {
            _loading = true;
            _error = null;
          }),
          onPageFinished: (_) async {
            await _applyMobileWorkspaceCss();
            if (mounted) setState(() => _loading = false);
          },
          onWebResourceError: (error) {
            if (mounted && error.isForMainFrame == true) {
              setState(() {
                _loading = false;
                _error = error.description;
              });
            }
          },
        ),
      );

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await _configureAndroidFilePicker();
      await _loadWorkspace();
    });
  }

  Future<void> _configureAndroidFilePicker() async {
    if (kIsWeb || !Platform.isAndroid) return;
    final platform = _controller.platform;
    if (platform is! AndroidWebViewController) return;

    await platform.setAllowFileAccess(true);
    await platform.setAllowContentAccess(true);
    await platform.setOnShowFileSelector((params) async {
      final accept = params.acceptTypes.where((e) => e.trim().isNotEmpty).toList();
      final imagesOnly = accept.isNotEmpty && accept.every((e) => e.startsWith('image/'));
      final result = await FilePicker.platform.pickFiles(
        allowMultiple: params.mode == FileSelectorMode.openMultiple,
        type: imagesOnly ? FileType.image : FileType.any,
        withData: false,
      );
      if (result == null) return <String>[];
      return result.files
          .map((f) => f.path)
          .whereType<String>()
          .where((p) => p.isNotEmpty)
          .toList(growable: false);
    });
  }

  Future<void> _applyMobileWorkspaceCss() async {
    try {
      await _controller.runJavaScript(r"""
        (function(){
          try {
            var m=document.querySelector('meta[name="viewport"]');
            if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}
            m.setAttribute('content','width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no');
            var style=document.getElementById('necner-mobile-workspace-style');
            if(!style){
              style=document.createElement('style');
              style.id='necner-mobile-workspace-style';
              document.head.appendChild(style);
            }
            style.textContent='''
              html,body{margin:0!important;width:100%!important;min-width:0!important;background:#f7f8fa!important;overflow-x:hidden!important;}
              .desktop-sidebar,#sidebar,.sidebar,.sidebar-menu,.workspace-sidebar,.app-sidebar,#appSidebar,.desktop-header,.desktop-footer,#footer,.topbar,.workspace-topbar,
              .sidebar-overlay,.drawer,.offcanvas,.offcanvas-backdrop,.modal-backdrop{display:none!important;visibility:hidden!important;}
              body>aside,body>nav{display:none!important;}
              main,.main-content,.content,.page-content,.workspace-content,.dashboard-content{margin-left:0!important;width:100%!important;max-width:100%!important;}
              .container,.container-fluid{max-width:100%!important;width:100%!important;padding-left:12px!important;padding-right:12px!important;}
              input[type=file]{display:block!important;opacity:1!important;visibility:visible!important;pointer-events:auto!important;}
            ''';
            document.documentElement.style.webkitTextSizeAdjust='100%';
            var buttons=document.querySelectorAll('button,[role="button"],a');
            buttons.forEach(function(b){b.style.webkitTapHighlightColor='transparent';});
          }catch(e){}
        })();
      """);
    } catch (_) {}
  }

  Future<void> _loadWorkspace() async {
    final cfg = context.read<AppConfig>();
    final storage = SecureStorageService();
    final token = await storage.getAccessToken();
    if (!mounted) return;
    if (token == null || token.isEmpty) {
      setState(() {
        _loading = false;
        _error = 'Merchant session is not available. Please sign in again.';
      });
      return;
    }

    final origin = Uri.parse(cfg.bootstrapOrigin);
    final requestedPath = widget.path.trim().isEmpty ? '/customer/dashboard.php' : widget.path.trim();
    final normalizedPath = requestedPath.startsWith('/') ? requestedPath : '/$requestedPath';

    // Manifest routes may point directly at a service mobile API. Those
    // endpoints require the Bearer token and must NOT be converted into a
    // browser session redirect. Existing PHP workspace pages use the bridge.
    final isBearerApiRoute = normalizedPath.contains('/api/') ||
        normalizedPath.startsWith('/mobile/') ||
        normalizedPath.endsWith('.json');

    final target = isBearerApiRoute
        ? origin.replace(path: normalizedPath.split('?').first, queryParameters: Uri.tryParse(normalizedPath)?.queryParameters)
        : origin.replace(
            path: '/mobile/workspace-bridge.php',
            queryParameters: {
              'path': normalizedPath,
              if (widget.serviceKey != null && widget.serviceKey!.isNotEmpty) 'service': widget.serviceKey!,
            },
          );

    await _controller.loadRequest(
      target,
      headers: {
        'Authorization': 'Bearer $token',
        'X-Authorization': 'Bearer $token',
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: AppColors.primaryTeal,
        foregroundColor: Colors.white,
        title: Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          IconButton(tooltip: 'Refresh', onPressed: () => _controller.reload(), icon: const Icon(Icons.refresh_rounded)),
        ],
      ),
      body: Stack(
        children: [
          if (_error == null) WebViewWidget(controller: _controller),
          if (_error != null)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.error_outline_rounded, size: 48, color: Colors.redAccent),
                  const SizedBox(height: 12),
                  Text(_error!, textAlign: TextAlign.center),
                  const SizedBox(height: 16),
                  FilledButton.icon(onPressed: _loadWorkspace, icon: const Icon(Icons.refresh), label: const Text('Retry')),
                ]),
              ),
            ),
          if (_loading && _error == null)
            const LinearProgressIndicator(minHeight: 2, color: AppColors.accentGreen, backgroundColor: Colors.transparent),
        ],
      ),
    );
  }
}
