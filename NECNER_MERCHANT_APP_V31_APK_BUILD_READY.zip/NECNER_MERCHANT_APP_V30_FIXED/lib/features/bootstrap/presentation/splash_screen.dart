import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../../app/theme/app_colors.dart';
import '../state/bootstrap_controller.dart';
import '../../auth/session/auth_controller.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _startStartupSequence());
  }

  Future<void> _startStartupSequence() async {
    final bootstrapCtrl = context.read<BootstrapController>();
    final authCtrl = context.read<AuthController>();
    await bootstrapCtrl.executeBootstrap();
    if (!mounted) return;
    if (bootstrapCtrl.status == BootstrapStatus.maintenance) { context.go('/maintenance'); return; }
    if (bootstrapCtrl.status == BootstrapStatus.forceUpdate) { context.go('/force-update'); return; }
    if (bootstrapCtrl.status == BootstrapStatus.error) { context.go('/config-error'); return; }
    await authCtrl.checkExistingSession();
    if (!mounted) return;
    context.go(authCtrl.isAuthenticated ? '/chats' : '/login');
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: AppColors.primaryTeal,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            NecnerSaasLogo(size: 96),
            SizedBox(height: 18),
            Text(
              'necner saas',
              style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800),
            ),
            SizedBox(height: 36),
            SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                strokeWidth: 2.5,
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white70),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class NecnerSaasLogo extends StatelessWidget {
  final double size;
  const NecnerSaasLogo({super.key, required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(color: AppColors.accentGreen, shape: BoxShape.circle),
      child: Center(
        child: Container(
          width: size * .58,
          height: size * .44,
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
          child: Icon(Icons.chat_rounded, size: size * .31, color: AppColors.primaryTeal),
        ),
      ),
    );
  }
}
