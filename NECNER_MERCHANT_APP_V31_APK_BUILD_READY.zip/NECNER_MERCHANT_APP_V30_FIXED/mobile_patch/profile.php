<?php
declare(strict_types=1);

/**
 * Additive Merchant Mobile Profile API.
 * Uses existing users.profile_image and tenants.business_name columns.
 * No schema migration is required.
 */
if (!defined('NECNER_APP_INIT')) define('NECNER_APP_INIT', true);
if (!defined('MOBILE_PLATFORM_REQUEST')) define('MOBILE_PLATFORM_REQUEST', true);

$cfg = require dirname(__DIR__) . '/mobile-platform/includes/bootstrap.php';
require_once dirname(__DIR__) . '/mobile-platform/includes/JsonResponse.php';
require_once dirname(__DIR__) . '/api/v1/seller/includes/SellerAuth.php';

MobileJsonResponse::preflight();
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') exit;

try {
    $ctx = SellerAuth::authenticateBearer();
    $pdo = Database::getConnection();
    $tenantId = (int)$ctx->getTenantId();
    $userId = (int)$ctx->getSellerId();

    $tenantStmt = $pdo->prepare('SELECT id,business_name,name,service_type,phone,email FROM tenants WHERE id=:t LIMIT 1');
    $tenantStmt->execute([':t'=>$tenantId]);
    $tenant = $tenantStmt->fetch(PDO::FETCH_ASSOC);
    if (!$tenant) MobileJsonResponse::error('Merchant tenant not found.','TENANT_NOT_FOUND',404);

    $userStmt = $pdo->prepare('SELECT id,name,email,phone,profile_image,status FROM users WHERE id=:u AND tenant_id=:t LIMIT 1');
    $userStmt->execute([':u'=>$userId,':t'=>$tenantId]);
    $user = $userStmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) MobileJsonResponse::error('Merchant profile not found.','USER_NOT_FOUND',404);

    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if ($method === 'GET') {
        $base = rtrim((string)($GLOBALS['cfg']['base_config']['app']['url'] ?? ''), '/');
        if ($base === '') {
            $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $base = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
        }
        $image = trim((string)($user['profile_image'] ?? ''));
        $avatar = $image === '' ? null : (preg_match('~^https?://~i',$image) ? $image : $base . '/' . ltrim($image,'/'));
        MobileJsonResponse::ok([
            'user'=>[
                'id'=>(int)$user['id'],
                'name'=>(string)$user['name'],
                'email'=>(string)$user['email'],
                'phone'=>(string)($user['phone']??''),
                'avatar_url'=>$avatar,
            ],
            'tenant'=>[
                'id'=>(int)$tenant['id'],
                'business_name'=>(string)$tenant['business_name'],
                'service_type'=>(string)($tenant['service_type']??''),
                'phone'=>(string)($tenant['phone']??''),
                'email'=>(string)($tenant['email']??''),
            ],
        ],'Merchant profile loaded');
    }

    if (!in_array($method,['POST','PUT','PATCH'],true)) {
        MobileJsonResponse::error('Method not allowed.','METHOD_NOT_ALLOWED',405);
    }

    $businessName = trim((string)($_POST['business_name'] ?? $_POST['merchant_name'] ?? ''));
    if ($businessName === '') {
        $raw = file_get_contents('php://input');
        if ($raw !== false && trim($raw) !== '') {
            $json = json_decode($raw,true);
            if (is_array($json)) $businessName = trim((string)($json['business_name'] ?? $json['merchant_name'] ?? ''));
        }
    }

    $changed = [];
    if ($businessName !== '') {
        if (mb_strlen($businessName) > 191) {
            MobileJsonResponse::error('Business name is too long.','VALIDATION_ERROR',422);
        }
        $pdo->beginTransaction();
        $st=$pdo->prepare('UPDATE tenants SET business_name=:n,name=:n,updated_at=NOW() WHERE id=:t');
        $st->execute([':n'=>$businessName,':t'=>$tenantId]);
        try {
            $up=$pdo->prepare('UPDATE settings SET setting_value=:v,updated_at=NOW() WHERE tenant_id=:t AND setting_key=:k');
            $up->execute([':v'=>$businessName,':t'=>$tenantId,':k'=>'business_name']);
            if ($up->rowCount()===0) {
                $ins=$pdo->prepare('INSERT INTO settings (tenant_id,setting_key,setting_value,is_encrypted) VALUES (:t,:k,:v,0)');
                $ins->execute([':t'=>$tenantId,':k'=>'business_name',':v'=>$businessName]);
            }
        } catch (Throwable $e) {}
        $pdo->commit();
        $changed[]='business_name';
    }

    if (!empty($_FILES['logo']) && is_array($_FILES['logo'])) {
        $file=$_FILES['logo'];
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            MobileJsonResponse::error('Logo upload failed.','UPLOAD_FAILED',422);
        }
        if ((int)($file['size']??0) > 5*1024*1024) {
            MobileJsonResponse::error('Logo must be 5 MB or smaller.','FILE_TOO_LARGE',422);
        }
        $tmp=(string)$file['tmp_name'];
        $mime=(new finfo(FILEINFO_MIME_TYPE))->file($tmp);
        $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
        if (!isset($allowed[$mime])) MobileJsonResponse::error('Only JPG, PNG or WebP logos are allowed.','INVALID_IMAGE',422);

        $relative='uploads/mobile/merchant-logos/merchant_'.$tenantId.'_'.bin2hex(random_bytes(10)).'.'.$allowed[$mime];
        $absolute=dirname(__DIR__).'/'.$relative;
        if (!is_dir(dirname($absolute))) mkdir(dirname($absolute),0755,true);
        if (!move_uploaded_file($tmp,$absolute)) MobileJsonResponse::error('Unable to store logo.','UPLOAD_STORAGE_FAILED',500);

        $old=$user['profile_image']??'';
        $st=$pdo->prepare('UPDATE users SET profile_image=:p,updated_at=NOW() WHERE id=:u AND tenant_id=:t');
        $st->execute([':p'=>$relative,':u'=>$userId,':t'=>$tenantId]);
        if ($old && str_starts_with((string)$old,'uploads/mobile/merchant-logos/')) {
            $oldPath=dirname(__DIR__).'/'.ltrim((string)$old,'/');
            if (is_file($oldPath)) @unlink($oldPath);
        }
        $changed[]='logo';
    }

    if (!$changed) MobileJsonResponse::error('No profile changes were submitted.','NO_CHANGES',422);

    $freshT=$pdo->prepare('SELECT id,business_name,name,service_type,phone,email FROM tenants WHERE id=:t LIMIT 1');
    $freshT->execute([':t'=>$tenantId]);
    $tenant=$freshT->fetch(PDO::FETCH_ASSOC);
    $freshU=$pdo->prepare('SELECT id,name,email,phone,profile_image,status FROM users WHERE id=:u AND tenant_id=:t LIMIT 1');
    $freshU->execute([':u'=>$userId,':t'=>$tenantId]);
    $user=$freshU->fetch(PDO::FETCH_ASSOC);

    $base = rtrim((string)($GLOBALS['cfg']['base_config']['app']['url'] ?? ''), '/');
    if ($base === '') {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $base = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
    }
    $image=trim((string)($user['profile_image']??''));
    $avatar=$image===''?null:(preg_match('~^https?://~i',$image)?$image:$base.'/'.ltrim($image,'/'));

    MobileJsonResponse::ok([
        'changed'=>$changed,
        'user'=>[
            'id'=>(int)$user['id'],'name'=>(string)$user['name'],'email'=>(string)$user['email'],
            'phone'=>(string)($user['phone']??''),'avatar_url'=>$avatar
        ],
        'tenant'=>[
            'id'=>(int)$tenant['id'],'business_name'=>(string)$tenant['business_name'],
            'service_type'=>(string)($tenant['service_type']??'')
        ],
    ],'Merchant profile updated');
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    error_log('[MOBILE PROFILE] '.$e->getMessage());
    MobileJsonResponse::error('Unable to update merchant profile.','PROFILE_UPDATE_FAILED',500);
}
