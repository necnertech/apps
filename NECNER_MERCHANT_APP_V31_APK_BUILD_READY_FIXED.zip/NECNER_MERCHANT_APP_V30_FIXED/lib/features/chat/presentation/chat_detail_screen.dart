import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/actions/action_definition.dart';
import '../../../core/actions/action_engine.dart';
import '../../../core/permissions/permission_evaluator.dart';
import '../../../data/models/chat_models.dart';
import '../../../data/repositories/call_repository.dart';
import '../../auth/session/auth_controller.dart';
import '../state/chat_controller.dart';

class ChatDetailScreen extends StatefulWidget {
  final String chatId;

  const ChatDetailScreen({super.key, required this.chatId});

  @override
  State<ChatDetailScreen> createState() => _ChatDetailScreenState();
}

class _ChatDetailScreenState extends State<ChatDetailScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _isComposing = false;
  bool _isPlayingVoice = false;
  double _voiceSpeed = 1.0;
  bool _autoUrlTestSent = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final ctrl = context.read<ChatController>();
      ctrl.openConversation(widget.chatId).then((_) {
        if (!mounted || _autoUrlTestSent || ctrl.activeMessages.isNotEmpty) return;
        _autoUrlTestSent = true;
        _sendStorefrontUrl(auto: true);
      });
    });
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent + 80,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _handleSend() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    _messageController.clear();
    setState(() => _isComposing = false);

    final chatCtrl = context.read<ChatController>();
    await chatCtrl.sendMessage(
      type: 'text',
      content: text,
    );
    _scrollToBottom();
  }

  Future<void> _sendStorefrontUrl({bool auto = false}) async {
    final chatCtrl = context.read<ChatController>();
    var url = await chatCtrl.getStorefrontUrl();
    if (url.isEmpty) url = 'https://udidesign.in/customer/commerce/store.php';
    final content = auto
        ? 'Test message: Open our merchant frontend from the button below.'
        : 'Open our merchant frontend: $url';
    await chatCtrl.sendMessage(
      type: 'url',
      content: content,
      metadata: {
        'url': url,
        'title': 'Merchant Frontend',
        'button_text': 'Open Merchant Frontend',
        'test_message': true,
      },
    );
    _scrollToBottom();
  }

  void _sendInteractiveCard(String type) async {
    final chatCtrl = context.read<ChatController>();

    if (type == 'order') {
      await chatCtrl.sendMessage(
        type: 'order',
        content: 'Prescription Order #10045 prepared for clinic desk pickup.',
        metadata: {
          'order_id': '10045',
          'order_number': '#10045',
          'items_summary': 'Asthmin Inhaler 50mg (2x), Vit-D 1000IU (1x)',
          'total_amount': 48.50,
          'currency': 'INR',
          'status': 'ready_for_pickup',
        },
      );
    } else if (type == 'appointment') {
      await chatCtrl.sendMessage(
        type: 'appointment',
        content: 'Clinical follow-up scheduled for tomorrow.',
        metadata: {
          'appointment_id': '8042',
          'service_name': 'In-Person Consultation',
          'doctor_name': 'Dr. Alena Vance',
          'date': 'Tomorrow 10:30 AM',
          'status': 'confirmed',
        },
      );
    } else if (type == 'payment') {
      await chatCtrl.sendMessage(
        type: 'payment',
        content: 'Invoice INV-2026-092 for medical consultation.',
        metadata: {
          'invoice_number': 'INV-2026-092',
          'amount': 75.00,
          'currency': 'INR',
          'status': 'pending',
          'due_date': 'Due on arrival',
        },
      );
    } else if (type == 'voice') {
      await chatCtrl.sendMessage(
        type: 'voice',
        content: 'Voice note (0:18)',
        metadata: {
          'duration': 18,
          'waveform': [4, 8, 12, 16, 20, 14, 10, 18, 22, 16, 8, 12, 14, 8, 4],
        },
      );
    }

    _scrollToBottom();
  }

  Future<void> _executeCardAction({
    required String messageId,
    required String actionKey,
    required String title,
    required String serviceKey,
    required Map<String, dynamic> payload,
    required String targetStatus,
  }) async {
    final authCtrl = context.read<AuthController>();
    final session = authCtrl.currentSession;
    final evaluator = PermissionEvaluator(
      userPermissions: session?.effectivePermissions ?? [],
      assignedServices: session?.assignedServices ?? [],
    );

    final actionEngine = context.read<ActionEngine>();
    final chatCtrl = context.read<ChatController>();

    final action = ActionDefinition(
      actionKey: actionKey,
      title: title,
      description: 'Execute operation "$title" from chat thread',
      serviceKey: serviceKey,
      moduleKey: serviceKey == 'doctor' ? 'appointments' : 'orders',
      entityType: serviceKey == 'doctor' ? 'appointment' : 'order',
      permissionRequired: '$serviceKey.manage',
      requiresConfirmation: true,
      confirmationMessage: 'Are you sure you want to proceed with "$title"?',
      requiresIdempotency: true,
    );

    final result = await actionEngine.execute(
      action: action,
      payload: payload,
      permissionEvaluator: evaluator,
      context: context,
    );

    if (result.success) {
      chatCtrl.updateCardAction(
        messageId: messageId,
        newStatus: targetStatus,
      );
      _showQuickActionToast('$title completed successfully!');
    } else {
      _showQuickActionToast(result.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    final chatCtrl = context.watch<ChatController>();
    final conversation = chatCtrl.activeConversation;
    final messages = chatCtrl.activeMessages;

    final customerName = conversation?.customerName ?? 'Sarah Jenkins';
    final serviceLabel = conversation?.serviceLabel ?? 'Doctor & Appointments';

    return Scaffold(
      backgroundColor: const Color(0xFF0B141B),
      appBar: AppBar(
        backgroundColor: const Color(0xFF075E54),
        elevation: 1,
        leadingWidth: 70,
        leading: Row(
          children: [
            const SizedBox(width: 4),
            IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.of(context).pop(),
            ),
            CircleAvatar(
              radius: 16,
              backgroundColor: Colors.white.withValues(alpha: 0.2),
              child: Text(
                customerName.isNotEmpty ? customerName[0].toUpperCase() : 'C',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
              ),
            ),
          ],
        ),
        title: InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: () => _showCustomerProfile(conversation),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  customerName,
                  style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                ),
                Text(
                  chatCtrl.isRecipientTyping ? 'typing...' : serviceLabel,
                  style: TextStyle(
                    color: chatCtrl.isRecipientTyping
                        ? const Color(0xFF25D366)
                        : Colors.white.withValues(alpha: 0.8),
                    fontSize: 11.5,
                    fontWeight: chatCtrl.isRecipientTyping ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.videocam, color: Colors.white),
            onPressed: () async {
            final repo=context.read<CallRepository>();
            final result=await repo.createVideoRoom(widget.chatId);
            result.when(success:(url) async {if(url.isNotEmpty) await repo.openVideoRoom(url);if(mounted)_showQuickActionToast('Video call room opened; the same link is posted in chat.');},failure:(e)=>_showQuickActionToast(e.message));
          },
          ),
          IconButton(
            icon: const Icon(Icons.call, color: Colors.white),
            onPressed: () async {
            final ok=await context.read<CallRepository>().startPhoneCall(conversation?.customerPhone??'');
            if(!ok&&mounted)_showQuickActionToast('Customer phone number is not available.');
          },
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: Colors.white),
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'info', child: Text('Contact Info')),
              const PopupMenuItem(value: 'clear', child: Text('Clear Chat')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Realtime Secure Banner
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            color: const Color(0xFF17232B),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.lock, size: 12, color: Colors.white60),
                const SizedBox(width: 6),
                Text(
                  'End-to-end encrypted with Necner SaaS tenant isolation',
                  style: const TextStyle(fontSize: 11, color: Colors.white70),
                ),
              ],
            ),
          ),

          _buildServiceActionStrip(),

          // Message Stream
          Expanded(
            child: Stack(
              children: [
                if (chatCtrl.isLoadingMessages && messages.isEmpty)
                  const Center(child: CircularProgressIndicator(color: Color(0xFF075E54)))
                else
                  ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    itemCount: messages.length,
                    itemBuilder: (context, index) => _buildMessageBubble(messages[index], chatCtrl),
                  ),
                IgnorePointer(
                  child: Center(
                    child: Transform.rotate(
                      angle: -0.20,
                      child: Opacity(
                        opacity: 0.075,
                        child: Text(
                          'NECNER TECHNOLOGY\nWhatsApp API Cloud System',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFF25D366), letterSpacing: 1.1),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Input Bar & Quick Action Composer
          _buildInputBar(),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessageItem msg, ChatController chatCtrl) {
    final isMerchant = msg.isMerchant;

    return Align(
      alignment: isMerchant ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.82,
        ),
        decoration: BoxDecoration(
          color: isMerchant ? const Color(0xFF005C4B) : const Color(0xFF202C33),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(12),
            topRight: const Radius.circular(12),
            bottomLeft: Radius.circular(isMerchant ? 12 : 2),
            bottomRight: Radius.circular(isMerchant ? 2 : 12),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.06),
              blurRadius: 2,
              offset: const Offset(0, 1),
            ),
          ],
        ),
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Sender header for group/merchant context
            if (!isMerchant)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(
                  msg.senderName,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF075E54),
                  ),
                ),
              ),

            // Bubble Content by Type
            if (msg.type == 'order')
              _buildOrderCard(msg, chatCtrl)
            else if (msg.type == 'appointment')
              _buildAppointmentCard(msg, chatCtrl)
            else if (msg.type == 'payment')
              _buildPaymentCard(msg, chatCtrl)
            else if (msg.type == 'voice')
              _buildVoiceMessage(msg)
            else if (msg.type == 'url')
              _buildUrlCard(msg)
            else
              Text(
                msg.content,
                style: const TextStyle(fontSize: 15, color: Color(0xFF111827), height: 1.3),
              ),

            const SizedBox(height: 4),

            // Timestamp and Status Checkmarks
            Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                const Spacer(),
                Text(
                  _formatTime(msg.createdAt),
                  style: const TextStyle(fontSize: 10.5, color: Color(0xFF6B7280)),
                ),
                if (isMerchant) ...[
                  const SizedBox(width: 4),
                  _buildDeliveryStatusIcon(msg.deliveryStatus),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDeliveryStatusIcon(MessageDeliveryStatus status) {
    switch (status) {
      case MessageDeliveryStatus.sending:
        return const Icon(Icons.access_time, size: 13, color: Color(0xFF9CA3AF));
      case MessageDeliveryStatus.sent:
        return const Icon(Icons.done, size: 14, color: Color(0xFF9CA3AF));
      case MessageDeliveryStatus.delivered:
        return const Icon(Icons.done_all, size: 14, color: Color(0xFF9CA3AF));
      case MessageDeliveryStatus.read:
        return const Icon(Icons.done_all, size: 14, color: Color(0xFF34B7F1)); // WhatsApp Cyan Blue
    }
  }

  // --- Interactive Message Card: Order ---
  Widget _buildOrderCard(ChatMessageItem msg, ChatController chatCtrl) {
    final meta = msg.metadata;
    final orderNum = meta['order_number'] ?? '#10045';
    final items = meta['items_summary'] ?? 'Prescription medication (2 items)';
    final amount = meta['total_amount'] ?? 48.50;
    final status = meta['status'] ?? 'ready_for_pickup';
    final isConfirmed = status == 'confirmed';

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.shopping_bag, size: 16, color: Color(0xFF059669)),
                  const SizedBox(width: 6),
                  Text(
                    'Order $orderNum',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: isConfirmed ? const Color(0xFFDCFCE7) : const Color(0xFFFEF3C7),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  isConfirmed ? 'Confirmed' : 'Ready',
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.bold,
                    color: isConfirmed ? const Color(0xFF166534) : const Color(0xFF92400E),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(items, style: const TextStyle(fontSize: 13, color: Color(0xFF374151))),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Total: \$$amount',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5, color: Color(0xFF111827)),
              ),
              if (!isConfirmed)
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF059669),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    minimumSize: const Size(60, 28),
                  ),
                  onPressed: () {
                    _executeCardAction(
                      messageId: msg.id,
                      actionKey: 'confirm_order',
                      title: 'Confirm Order $orderNum',
                      serviceKey: 'ecommerce',
                      payload: {'order_id': orderNum, 'amount': amount},
                      targetStatus: 'confirmed',
                    );
                  },
                  child: const Text('Confirm', style: TextStyle(fontSize: 11.5, color: Colors.white)),
                ),
            ],
          ),
        ],
      ),
    );
  }

  // --- Interactive Message Card: Appointment ---
  Widget _buildAppointmentCard(ChatMessageItem msg, ChatController chatCtrl) {
    final meta = msg.metadata;
    final doctor = meta['doctor_name'] ?? 'Dr. Alena Vance';
    final date = meta['date'] ?? 'Tomorrow 10:30 AM';
    final service = meta['service_name'] ?? 'Consultation';
    final status = meta['status'] ?? 'scheduled';
    final isConfirmed = status == 'confirmed';

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFBAE6FD)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.calendar_month, size: 16, color: Color(0xFF0284C7)),
              const SizedBox(width: 6),
              Text(
                service,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text('Doctor: $doctor', style: const TextStyle(fontSize: 12.5, color: Color(0xFF374151))),
          Text('Time: $date', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: Color(0xFF0369A1))),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(
                style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2)),
                onPressed: () => _showQuickActionToast('Reschedule modal opened'),
                child: const Text('Reschedule', style: TextStyle(fontSize: 11.5, color: Color(0xFF6B7280))),
              ),
              const SizedBox(width: 6),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: isConfirmed ? const Color(0xFF0284C7) : const Color(0xFF0284C7),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  minimumSize: const Size(60, 28),
                ),
                onPressed: isConfirmed
                    ? null
                    : () {
                        _executeCardAction(
                          messageId: msg.id,
                          actionKey: 'confirm_appointment',
                          title: 'Confirm Appointment with $doctor',
                          serviceKey: 'doctor',
                          payload: {'appointment_id': meta['appointment_id'] ?? '8042', 'date': date},
                          targetStatus: 'confirmed',
                        );
                      },
                child: Text(
                  isConfirmed ? 'Confirmed' : 'Confirm',
                  style: const TextStyle(fontSize: 11.5, color: Colors.white),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // --- Interactive Message Card: Payment ---
  Widget _buildPaymentCard(ChatMessageItem msg, ChatController chatCtrl) {
    final meta = msg.metadata;
    final invoice = meta['invoice_number'] ?? 'INV-2026-092';
    final amount = meta['amount'] ?? 75.00;
    final status = meta['status'] ?? 'pending';
    final isPaid = status == 'paid';

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFD1D5DB)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.receipt_long, size: 16, color: Color(0xFF075E54)),
                  const SizedBox(width: 6),
                  Text('Invoice $invoice', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5)),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: isPaid ? const Color(0xFFDCFCE7) : const Color(0xFFFEE2E2),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  isPaid ? 'PAID' : 'PENDING',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: isPaid ? const Color(0xFF166534) : const Color(0xFF991B1B),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text('Amount Due: \$$amount USD', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              if (!isPaid)
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF075E54),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    minimumSize: const Size(100, 28),
                  ),
                  icon: const Icon(Icons.payment, size: 14, color: Colors.white),
                  label: const Text('Collect', style: TextStyle(fontSize: 11.5, color: Colors.white)),
                  onPressed: () {
                    _executeCardAction(
                      messageId: msg.id,
                      actionKey: 'collect_payment',
                      title: 'Collect Payment for $invoice',
                      serviceKey: 'doctor',
                      payload: {'invoice_number': invoice, 'amount': amount},
                      targetStatus: 'paid',
                    );
                  },
                )
              else
                TextButton.icon(
                  icon: const Icon(Icons.check_circle, size: 14, color: Color(0xFF059669)),
                  label: const Text('Receipt Sent', style: TextStyle(fontSize: 11.5, color: Color(0xFF059669))),
                  onPressed: () => _showQuickActionToast('Receipt #INV-2026-092 opened'),
                ),
            ],
          ),
        ],
      ),
    );
  }

  // --- Voice Message Player ---
  Widget _buildVoiceMessage(ChatMessageItem msg) {
    return Row(
      children: [
        IconButton(
          icon: Icon(_isPlayingVoice ? Icons.pause_circle : Icons.play_circle, size: 36, color: const Color(0xFF075E54)),
          onPressed: () {
            setState(() => _isPlayingVoice = !_isPlayingVoice);
          },
        ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: List.generate(
                  15,
                  (i) => Expanded(
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 1),
                      height: ((i * 7) % 20 + 8).toDouble(),
                      color: _isPlayingVoice && i < 8 ? const Color(0xFF075E54) : Colors.grey.shade400,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              const Text('0:18', style: TextStyle(fontSize: 11, color: Color(0xFF6B7280))),
            ],
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: () {
            setState(() {
              if (_voiceSpeed == 1.0) {
                _voiceSpeed = 1.5;
              } else if (_voiceSpeed == 1.5) {
                _voiceSpeed = 2.0;
              } else {
                _voiceSpeed = 1.0;
              }
            });
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              '${_voiceSpeed}x',
              style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      color: const Color(0xFFF0F2F5),
      child: SafeArea(
        child: Row(
          children: [
            // Quick Attachment Button
            IconButton(
              icon: const Icon(Icons.add_circle, color: Color(0xFF075E54), size: 28),
              onPressed: _showAttachmentMenu,
            ),

            // Text Input Field
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: const Color(0xFFF4F8F6),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _messageController,
                        maxLines: 4,
                        minLines: 1,
                        textCapitalization: TextCapitalization.sentences,
                        decoration: const InputDecoration(
                          hintText: 'Message or send action...',
                          hintStyle: TextStyle(color: Color(0xFF9CA3AF), fontSize: 15),
                          border: InputBorder.none,
                          isDense: true,
                          contentPadding: EdgeInsets.symmetric(vertical: 10),
                        ),
                        onChanged: (text) {
                          final composing = text.trim().isNotEmpty;
                          if (composing != _isComposing) {
                            setState(() => _isComposing = composing);
                          }
                        },
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.attach_file, color: Color(0xFF6B7280), size: 22),
                      onPressed: _showAttachmentMenu,
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(width: 6),

            // Send / Voice Button
            CircleAvatar(
              radius: 22,
              backgroundColor: const Color(0xFF075E54),
              child: IconButton(
                icon: Icon(
                  _isComposing ? Icons.send : Icons.mic,
                  color: Colors.white,
                  size: 20,
                ),
                onPressed: _isComposing
                    ? _handleSend
                    : () => _sendInteractiveCard('voice'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildServiceActionStrip() {
    final key = chatCtrlServiceKey();
    final actions = <Map<String, dynamic>>[
      {'label': 'Open Service', 'icon': Icons.grid_view_rounded, 'onTap': () => _openAssignedService()},
      if (key.contains('doctor') || key.contains('booking')) {'label': 'Appointments', 'icon': Icons.calendar_month_rounded, 'onTap': () => _openAssignedService()},
      if (key.contains('ecommerce') || key.contains('store')) {'label': 'Products', 'icon': Icons.inventory_2_rounded, 'onTap': () => _openAssignedService()},
      if (key.contains('restaurant') || key.contains('food')) {'label': 'Orders', 'icon': Icons.shopping_bag_rounded, 'onTap': () => _openAssignedService()},
      {'label': 'Send URL', 'icon': Icons.link_rounded, 'onTap': () => _sendStorefrontUrl()},
    ];
    return Container(
      color: const Color(0xFF0F2E2A),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: SizedBox(
        height: 42,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: actions.length,
          separatorBuilder: (_, __) => const SizedBox(width: 7),
          itemBuilder: (_, i) {
            final a = actions[i];
            return OutlinedButton.icon(
              onPressed: a['onTap'] as VoidCallback,
              icon: Icon(a['icon'] as IconData, size: 16),
              label: Text(a['label'] as String),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.white,
                side: const BorderSide(color: Color(0xFF39756C)),
                backgroundColor: const Color(0xFF153B36),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                padding: const EdgeInsets.symmetric(horizontal: 12),
                textStyle: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700),
              ),
            );
          },
        ),
      ),
    );
  }

  String chatCtrlServiceKey() {
    final c = context.read<ChatController>().activeConversation;
    return (c?.serviceKey ?? '').toLowerCase();
  }

  void _openAssignedService() {
    final key = chatCtrlServiceKey();
    if (key.isEmpty || key == 'general') {
      _showQuickActionToast('No specific service is attached to this chat.');
      return;
    }
    context.push('/services/$key');
  }

  Widget _buildUrlCard(ChatMessageItem msg) {
    final url = msg.metadata['url']?.toString() ?? '';
    final title = msg.metadata['title']?.toString() ?? 'Merchant Frontend';
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFFEAF7F1), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFB9E4D2))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Icon(Icons.link_rounded, color: Color(0xFF075E54)), const SizedBox(width: 8), Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF075E54))))]),
        const SizedBox(height: 6),
        Text(url, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Color(0xFF4B5563))),
        const SizedBox(height: 10),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: url.isEmpty ? null : () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication), icon: const Icon(Icons.open_in_new_rounded, size: 17), label: const Text('Open Merchant Frontend'))),
      ]),
    );
  }

  void _showCustomerProfile(ConversationSummary conversation) {
    final customerName = conversation.customerName.trim().isEmpty
        ? 'Customer'
        : conversation.customerName.trim();
    final customerPhone = conversation.customerPhone.trim();
    final serviceLabel = conversation.serviceLabel.trim().isEmpty
        ? 'Service'
        : conversation.serviceLabel.trim();
    final avatarUrl = conversation.customerAvatarUrl?.trim() ?? '';

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF101A21),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
                const SizedBox(height: 18),
                CircleAvatar(
                  radius: 42,
                  backgroundColor: const Color(0xFF075E54),
                  backgroundImage: avatarUrl.isNotEmpty
                      ? NetworkImage(avatarUrl)
                      : null,
                  child: avatarUrl.isEmpty
                      ? Text(
                          customerName[0].toUpperCase(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight: FontWeight.w700,
                          ),
                        )
                      : null,
                ),
                const SizedBox(height: 12),
                Text(
                  customerName,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  serviceLabel,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 13,
                  ),
                ),
                if (customerPhone.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(
                    customerPhone,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 13,
                    ),
                  ),
                ],
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: customerPhone.isEmpty
                            ? null
                            : () async {
                                final ok = await context
                                    .read<CallRepository>()
                                    .startPhoneCall(customerPhone);
                                if (!ok && mounted) {
                                  _showQuickActionToast(
                                    'Customer phone number is not available.',
                                  );
                                }
                              },
                        icon: const Icon(Icons.call_rounded, size: 18),
                        label: const Text('Call'),
                        style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFF075E54),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => Navigator.of(sheetContext).pop(),
                        icon: const Icon(
                          Icons.chat_bubble_outline_rounded,
                          size: 18,
                        ),
                        label: const Text('Chat'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(color: Colors.white24),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showAttachmentMenu() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Attach Interactive Service Action',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildActionItem(
                  icon: Icons.shopping_bag,
                  color: const Color(0xFF059669),
                  label: 'Order Card',
                  onTap: () {
                    Navigator.pop(ctx);
                    _sendInteractiveCard('order');
                  },
                ),
                _buildActionItem(
                  icon: Icons.calendar_today,
                  color: const Color(0xFF0284C7),
                  label: 'Appointment',
                  onTap: () {
                    Navigator.pop(ctx);
                    _sendInteractiveCard('appointment');
                  },
                ),
                _buildActionItem(
                  icon: Icons.receipt,
                  color: const Color(0xFF7C3AED),
                  label: 'Invoice',
                  onTap: () {
                    Navigator.pop(ctx);
                    _sendInteractiveCard('payment');
                  },
                ),
                _buildActionItem(
                  icon: Icons.link_rounded,
                  color: const Color(0xFF075E54),
                  label: 'Frontend URL',
                  onTap: () {
                    Navigator.pop(ctx);
                    _sendStorefrontUrl();
                  },
                ),
                _buildActionItem(
                  icon: Icons.mic,
                  color: const Color(0xFFDC2626),
                  label: 'Voice Note',
                  onTap: () {
                    Navigator.pop(ctx);
                    _sendInteractiveCard('voice');
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionItem({
    required IconData icon,
    required Color color,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 26,
            backgroundColor: color.withValues(alpha: 0.12),
            child: Icon(icon, color: color, size: 26),
          ),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  void _showQuickActionToast(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
        backgroundColor: const Color(0xFF075E54),
      ),
    );
  }

  String _formatTime(String timeStr) {
    if (timeStr.isEmpty) return '';
    try {
      final dt = DateTime.parse(timeStr);
      final hour = dt.hour.toString().padLeft(2, '0');
      final minute = dt.minute.toString().padLeft(2, '0');
      return '$hour:$minute';
    } catch (_) {
      return timeStr.contains(' ') ? timeStr.split(' ').last : timeStr;
    }
  }
}
