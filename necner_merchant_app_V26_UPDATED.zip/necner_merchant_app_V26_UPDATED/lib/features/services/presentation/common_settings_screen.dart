import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../app/theme/app_colors.dart';
import '../../../data/models/service_models.dart';
import '../state/services_controller.dart';
import 'merchant_webview_screen.dart';

class CommonSettingsScreen extends StatefulWidget {
  final bool profileOnly;

  const CommonSettingsScreen({super.key, this.profileOnly = false});

  @override
  State<CommonSettingsScreen> createState() => _CommonSettingsScreenState();
}

class _CommonSettingsScreenState extends State<CommonSettingsScreen> {
  bool _loading = true;
  String? _error;
  List<ServiceModule> _modules = const [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final controller = context.read<ServicesController>();
    if (controller.services.isEmpty) await controller.loadAssignedServices();
    if (controller.services.isEmpty) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'No assigned service is available for loading merchant settings.';
      });
      return;
    }

    final merged = <String, ServiceModule>{};
    for (final service in controller.services) {
      final manifest = await controller.loadManifest(service.serviceKey);
      if (manifest == null) continue;
      for (final module in manifest.commonModules) {
        merged[module.moduleKey] = module;
      }
    }

    var modules = merged.values.toList()
      ..sort((a, b) {
        final group = a.group.compareTo(b.group);
        return group != 0 ? group : a.sortOrder.compareTo(b.sortOrder);
      });

    if (widget.profileOnly) {
      modules = modules.where((m) {
        final g = m.group.toLowerCase();
        final id = m.id.toLowerCase();
        return g.contains('account') || g.contains('profile') || id.contains('profile') || id.contains('team') || id.contains('staff') || id.contains('account') || id.contains('password');
      }).toList(growable: false);
    }

    if (!mounted) return;
    setState(() {
      _modules = modules;
      _loading = false;
      if (modules.isEmpty) {
        _error = widget.profileOnly
            ? 'No profile/account functions are configured for this merchant.'
            : 'No common merchant settings are configured.';
      }
    });
  }

  Future<void> _openFunction(ServiceModule module) async {
    var route = module.route.trim();
    if (route.isNotEmpty) {
      final absolute = Uri.tryParse(route);
      if (absolute != null && absolute.hasScheme && absolute.host.isNotEmpty) {
        route = absolute.path + (absolute.hasQuery ? '?${absolute.query}' : '');
      }
    }
    if (route.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${module.title} has no web route configured.')));
      return;
    }
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => MerchantWebViewScreen(title: module.title, path: route),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.profileOnly ? 'Profile Settings' : 'Settings';
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded))],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppColors.primaryEmerald));
    if (_error != null && _modules.isEmpty) {
      return Center(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.settings_outlined, size: 48, color: AppColors.textSecondaryLight),
          const SizedBox(height: 12),
          Text(_error!, textAlign: TextAlign.center),
          const SizedBox(height: 18),
          FilledButton.icon(onPressed: _load, icon: const Icon(Icons.refresh), label: const Text('Retry')),
        ]),
      ));
    }

    final groups = <String, List<ServiceModule>>{};
    for (final module in _modules) groups.putIfAbsent(module.group.isEmpty ? 'Settings' : module.group, () => []).add(module);

    return RefreshIndicator(
      onRefresh: _load,
      color: AppColors.primaryEmerald,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 30),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF075E54), Color(0xFF008069)]),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(children: [
              Container(width: 48, height: 48, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .15), borderRadius: BorderRadius.circular(13)), child: Icon(widget.profileOnly ? Icons.manage_accounts_rounded : Icons.settings_rounded, color: Colors.white, size: 26)),
              const SizedBox(width: 12),
              Expanded(child: Text(widget.profileOnly ? 'Profile, team and account functions.' : 'Common merchant functions shared across assigned services.', style: const TextStyle(color: Colors.white, fontSize: 13, height: 1.35))),
            ]),
          ),
          const SizedBox(height: 16),
          ...groups.entries.map((entry) => Padding(padding: const EdgeInsets.only(bottom: 16), child: _group(entry.key, entry.value))),
        ],
      ),
    );
  }

  Widget _group(String title, List<ServiceModule> modules) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Padding(padding: const EdgeInsets.only(left: 4, bottom: 7), child: Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800))),
    Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.borderLight)),
      child: ListView.separated(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: modules.length, separatorBuilder: (_, __) => Divider(height: 1, color: Colors.grey.shade200), itemBuilder: (_, i) => _tile(modules[i])),
    ),
  ]);

  Widget _tile(ServiceModule module) => ListTile(
    contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 4),
    leading: Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFFE8F5E9), borderRadius: BorderRadius.circular(11)), alignment: Alignment.center, child: Icon(_icon(module.icon), color: AppColors.primaryTeal, size: 22)),
    title: Text(module.title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
    subtitle: const Text('Open merchant workspace'),
    trailing: const Icon(Icons.chevron_right_rounded, color: Colors.grey),
    onTap: () => _openFunction(module),
  );

  IconData _icon(String raw) {
    final s = raw.toLowerCase();
    if (s.contains('whatsapp') || s.contains('message') || s.contains('chat')) return Icons.chat_rounded;
    if (s.contains('crm') || s.contains('contact') || s.contains('customer')) return Icons.people_alt_rounded;
    if (s.contains('automation') || s.contains('ai')) return Icons.smart_toy_rounded;
    if (s.contains('report') || s.contains('analytic')) return Icons.analytics_rounded;
    if (s.contains('billing') || s.contains('subscription') || s.contains('payment')) return Icons.receipt_long_rounded;
    if (s.contains('profile') || s.contains('account')) return Icons.manage_accounts_rounded;
    if (s.contains('team') || s.contains('staff') || s.contains('user')) return Icons.groups_rounded;
    if (s.contains('support') || s.contains('help')) return Icons.support_agent_rounded;
    return Icons.settings_rounded;
  }
}
