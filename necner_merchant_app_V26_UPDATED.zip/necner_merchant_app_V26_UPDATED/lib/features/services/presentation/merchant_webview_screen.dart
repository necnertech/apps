import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../../app/config/app_config.dart';
import '../../../app/theme/app_colors.dart';
import '../../../core/secure_storage/secure_storage_service.dart';

/// Opens the existing merchant web workspace inside the Flutter app.
/// The backend workspace bridge converts the authenticated mobile bearer token
/// into the normal merchant web session and then redirects to the requested
/// existing desktop/iframe page. This keeps the existing business UI/data as
/// the source of truth instead of recreating old product/order screens in Dart.
class MerchantWebViewScreen extends StatefulWidget {
  final String title;
  final String path;
  final String? serviceKey;

  const MerchantWebViewScreen({
    super.key,
    required this.title,
    required this.path,
    this.serviceKey,
  });

  @override
  State<MerchantWebViewScreen> createState() => _MerchantWebViewScreenState();
}

class _MerchantWebViewScreenState extends State<MerchantWebViewScreen> {
  late final WebViewController _controller;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFFF0F2F5))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) => setState(() {
            _loading = true;
            _error = null;
          }),
          onPageFinished: (_) async {
            await _controller.runJavaScript('''
              (function(){
                var m=document.querySelector('meta[name="viewport"]');
                if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}
                m.setAttribute('content','width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no');
                document.documentElement.style.webkitTextSizeAdjust='100%';
              })();
            ''');
            if (mounted) setState(() => _loading = false);
          },
          onWebResourceError: (error) {
            if (mounted && error.isForMainFrame == true) {
              setState(() {
                _loading = false;
                _error = error.description;
              });
            }
          },
        ),
      );

    WidgetsBinding.instance.addPostFrameCallback((_) => _loadWorkspace());
  }

  Future<void> _loadWorkspace() async {
    final cfg = context.read<AppConfig>();
    final storage = SecureStorageService();
    final token = await storage.getAccessToken();
    if (!mounted) return;
    if (token == null || token.isEmpty) {
      setState(() {
        _loading = false;
        _error = 'Merchant session is not available.';
      });
      return;
    }

    final origin = Uri.parse(cfg.bootstrapOrigin);
    final requestedPath = widget.path.trim().isEmpty ? '/customer/dashboard.php' : widget.path.trim();
    final bridge = origin.replace(
      path: '/mobile/workspace-bridge.php',
      queryParameters: {
        'path': requestedPath.startsWith('/') ? requestedPath : '/$requestedPath',
        if (widget.serviceKey != null && widget.serviceKey!.isNotEmpty) 'service': widget.serviceKey!,
      },
    );

    await _controller.loadRequest(
      bridge,
      headers: {
        'Authorization': 'Bearer $token',
        'X-Authorization': 'Bearer $token',
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: () => _controller.reload(),
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: Stack(
        children: [
          if (_error == null) WebViewWidget(controller: _controller),
          if (_error != null)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline_rounded, size: 48, color: Colors.redAccent),
                    const SizedBox(height: 12),
                    Text(_error!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: _loadWorkspace,
                      icon: const Icon(Icons.refresh),
                      label: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            ),
          if (_loading && _error == null)
            const LinearProgressIndicator(minHeight: 2, color: AppColors.primaryEmerald),
        ],
      ),
    );
  }
}
