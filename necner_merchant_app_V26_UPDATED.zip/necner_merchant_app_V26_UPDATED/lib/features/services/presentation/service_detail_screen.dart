import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../app/theme/app_colors.dart';
import '../state/services_controller.dart';
import 'merchant_webview_screen.dart';

class ServiceDetailScreen extends StatefulWidget {
  final String serviceKey;

  const ServiceDetailScreen({super.key, required this.serviceKey});

  @override
  State<ServiceDetailScreen> createState() => _ServiceDetailScreenState();
}

class _ServiceDetailScreenState extends State<ServiceDetailScreen> {
  bool _loading = true;
  String? _error;
  String _title = 'Service';
  String _path = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _prepare());
  }

  Future<void> _prepare() async {
    final controller = context.read<ServicesController>();
    if (controller.services.isEmpty) await controller.loadAssignedServices();

    final matches = controller.services.where((s) => s.serviceKey == widget.serviceKey).toList();
    if (matches.isEmpty) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'This service is not assigned to the current merchant.';
      });
      return;
    }

    final service = matches.first;
    final prefix = service.urlPrefix.trim().replaceAll(RegExp(r'^/+|/+$'), '');
    var entry = service.panelEntryFile.trim().replaceAll(RegExp(r'^/+'), '');
    if (entry.isEmpty) entry = 'admin/index.php';

    String path;
    if (prefix.isNotEmpty) {
      path = '/$prefix/$entry';
    } else {
      path = _fallbackPanelPath(service.serviceKey);
    }

    if (path.contains('?')) {
      path = '$path&iframe=1';
    } else {
      path = '$path?iframe=1';
    }

    if (!mounted) return;
    setState(() {
      _title = service.serviceName;
      _path = path;
      _loading = false;
    });
  }

  String _fallbackPanelPath(String key) {
    switch (key.toLowerCase()) {
      case 'ecommerce':
      case 'store':
        return '/store/admin/index.php?iframe=1';
      case 'doctor':
        return '/doctor/admin/?iframe=1';
      case 'restaurant':
        return '/restaurant/admin/?iframe=1';
      case 'hotel':
        return '/hotel/admin/?iframe=1';
      case 'taxi':
        return '/taxi/admin/?iframe=1';
      case 'pharmacy':
        return '/pharmacy/admin/?iframe=1';
      case 'pathology':
        return '/pathology/admin/?iframe=1';
      case 'exports':
      case 'exportwave':
        return '/exports/admin/?iframe=1';
      case 'realestate':
        return '/realestate/admin/?iframe=1';
      default:
        return '/customer/dashboard.php?iframe=1';
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: AppColors.backgroundLight,
        body: Center(child: CircularProgressIndicator(color: AppColors.primaryEmerald)),
      );
    }
    if (_error != null) {
      return Scaffold(
        backgroundColor: AppColors.backgroundLight,
        appBar: AppBar(title: const Text('Service')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.block_rounded, size: 48, color: Colors.redAccent),
                const SizedBox(height: 12),
                Text(_error!, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton.icon(onPressed: _prepare, icon: const Icon(Icons.refresh), label: const Text('Retry')),
              ],
            ),
          ),
        ),
      );
    }
    return MerchantWebViewScreen(title: _title, path: _path, serviceKey: widget.serviceKey);
  }
}
