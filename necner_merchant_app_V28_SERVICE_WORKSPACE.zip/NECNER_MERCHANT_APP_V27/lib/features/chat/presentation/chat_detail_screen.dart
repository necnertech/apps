import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/actions/action_definition.dart';
import '../../../core/actions/action_engine.dart';
import '../../../core/permissions/permission_evaluator.dart';
import '../../../data/models/chat_models.dart';
import '../../../data/repositories/call_repository.dart';
import '../../auth/session/auth_controller.dart';
import '../state/chat_controller.dart';

class ChatDetailScreen extends StatefulWidget {
  final String chatId;

  const ChatDetailScreen({super.key, required this.chatId});

  @override
  State<ChatDetailScreen> createState() => _ChatDetailScreenState();
}

class _ChatDetailScreenState extends State<ChatDetailScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _isComposing = false;
  bool _isPlayingVoice = false;
  double _voiceSpeed = 1.0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ChatController>().openConversation(widget.chatId);
    });
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent + 80,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _handleSend() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    _messageController.clear();
    setState(() => _isComposing = false);

    final chatCtrl = context.read<ChatController>();
    await chatCtrl.sendMessage(
      type: 'text',
      content: text,
    );
    _scrollToBottom();
  }

  void _sendInteractiveCard(String type) async {
    final chatCtrl = context.read<ChatController>();

    if (type == 'order') {
      await chatCtrl.sendMessage(
        type: 'order',
        content: 'Prescription Order #10045 prepared for clinic desk pickup.',
        metadata: {
          'order_id': '10045',
          'order_number': '#10045',
          'items_summary': 'Asthmin Inhaler 50mg (2x), Vit-D 1000IU (1x)',
          'total_amount': 48.50,
          'currency': 'INR',
          'status': 'ready_for_pickup',
        },
      );
    } else if (type == 'appointment') {
      await chatCtrl.sendMessage(
        type: 'appointment',
        content: 'Clinical follow-up scheduled for tomorrow.',
        metadata: {
          'appointment_id': '8042',
          'service_name': 'In-Person Consultation',
          'doctor_name': 'Dr. Alena Vance',
          'date': 'Tomorrow 10:30 AM',
          'status': 'confirmed',
        },
      );
    } else if (type == 'payment') {
      await chatCtrl.sendMessage(
        type: 'payment',
        content: 'Invoice INV-2026-092 for medical consultation.',
        metadata: {
          'invoice_number': 'INV-2026-092',
          'amount': 75.00,
          'currency': 'INR',
          'status': 'pending',
          'due_date': 'Due on arrival',
        },
      );
    } else if (type == 'voice') {
      await chatCtrl.sendMessage(
        type: 'voice',
        content: 'Voice note (0:18)',
        metadata: {
          'duration': 18,
          'waveform': [4, 8, 12, 16, 20, 14, 10, 18, 22, 16, 8, 12, 14, 8, 4],
        },
      );
    }

    _scrollToBottom();
  }

  Future<void> _executeCardAction({
    required String messageId,
    required String actionKey,
    required String title,
    required String serviceKey,
    required Map<String, dynamic> payload,
    required String targetStatus,
  }) async {
    final authCtrl = context.read<AuthController>();
    final session = authCtrl.currentSession;
    final evaluator = PermissionEvaluator(
      userPermissions: session?.effectivePermissions ?? [],
      assignedServices: session?.assignedServices ?? [],
    );

    final actionEngine = context.read<ActionEngine>();
    final chatCtrl = context.read<ChatController>();

    final action = ActionDefinition(
      actionKey: actionKey,
      title: title,
      description: 'Execute operation "$title" from chat thread',
      serviceKey: serviceKey,
      moduleKey: serviceKey == 'doctor' ? 'appointments' : 'orders',
      entityType: serviceKey == 'doctor' ? 'appointment' : 'order',
      permissionRequired: '$serviceKey.manage',
      requiresConfirmation: true,
      confirmationMessage: 'Are you sure you want to proceed with "$title"?',
      requiresIdempotency: true,
    );

    final result = await actionEngine.execute(
      action: action,
      payload: payload,
      permissionEvaluator: evaluator,
      context: context,
    );

    if (result.success) {
      chatCtrl.updateCardAction(
        messageId: messageId,
        newStatus: targetStatus,
      );
      _showQuickActionToast('$title completed successfully!');
    } else {
      _showQuickActionToast(result.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    final chatCtrl = context.watch<ChatController>();
    final conversation = chatCtrl.activeConversation;
    final messages = chatCtrl.activeMessages;

    final customerName = conversation?.customerName ?? 'Sarah Jenkins';
    final serviceLabel = conversation?.serviceLabel ?? 'Doctor & Appointments';

    return Scaffold(
      backgroundColor: const Color(0xFFEFEAE2), // WhatsApp Classic Chat Wallpaper Color
      appBar: AppBar(
        backgroundColor: const Color(0xFF075E54),
        elevation: 1,
        leadingWidth: 70,
        leading: Row(
          children: [
            const SizedBox(width: 4),
            IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.of(context).pop(),
            ),
            CircleAvatar(
              radius: 16,
              backgroundColor: Colors.white.withValues(alpha: 0.2),
              child: Text(
                customerName.isNotEmpty ? customerName[0].toUpperCase() : 'C',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
              ),
            ),
          ],
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              customerName,
              style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Text(
              chatCtrl.isRecipientTyping ? 'typing...' : serviceLabel,
              style: TextStyle(
                color: chatCtrl.isRecipientTyping
                    ? const Color(0xFF25D366)
                    : Colors.white.withValues(alpha: 0.8),
                fontSize: 11.5,
                fontWeight: chatCtrl.isRecipientTyping ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.videocam, color: Colors.white),
            onPressed: () async {
            final repo=context.read<CallRepository>();
            final result=await repo.createVideoRoom(widget.chatId);
            result.when(success:(url) async {if(url.isNotEmpty) await repo.openVideoRoom(url);if(mounted)_showQuickActionToast('Video call room opened; the same link is posted in chat.');},failure:(e)=>_showQuickActionToast(e.message));
          },
          ),
          IconButton(
            icon: const Icon(Icons.call, color: Colors.white),
            onPressed: () async {
            final ok=await context.read<CallRepository>().startPhoneCall(conversation?.customerPhone??'');
            if(!ok&&mounted)_showQuickActionToast('Customer phone number is not available.');
          },
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: Colors.white),
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'info', child: Text('Contact Info')),
              const PopupMenuItem(value: 'clear', child: Text('Clear Chat')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Realtime Secure Banner
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            color: const Color(0xFFFCF4CB),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.lock, size: 12, color: Color(0xFF6B7280)),
                const SizedBox(width: 6),
                Text(
                  'End-to-end encrypted with Necner SaaS tenant isolation',
                  style: TextStyle(fontSize: 11, color: Colors.grey.shade800),
                ),
              ],
            ),
          ),

          // Message Stream
          Expanded(
            child: chatCtrl.isLoadingMessages && messages.isEmpty
                ? const Center(
                    child: CircularProgressIndicator(color: Color(0xFF075E54)),
                  )
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    itemCount: messages.length,
                    itemBuilder: (context, index) {
                      final msg = messages[index];
                      return _buildMessageBubble(msg, chatCtrl);
                    },
                  ),
          ),

          // Input Bar & Quick Action Composer
          _buildInputBar(),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessageItem msg, ChatController chatCtrl) {
    final isMerchant = msg.isMerchant;

    return Align(
      alignment: isMerchant ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.82,
        ),
        decoration: BoxDecoration(
          color: isMerchant ? const Color(0xFFE7FFDB) : Colors.white, // WhatsApp bubble tones
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(12),
            topRight: const Radius.circular(12),
            bottomLeft: Radius.circular(isMerchant ? 12 : 2),
            bottomRight: Radius.circular(isMerchant ? 2 : 12),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.06),
              blurRadius: 2,
              offset: const Offset(0, 1),
            ),
          ],
        ),
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Sender header for group/merchant context
            if (!isMerchant)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(
                  msg.senderName,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF075E54),
                  ),
                ),
              ),

            // Bubble Content by Type
            if (msg.type == 'order')
              _buildOrderCard(msg, chatCtrl)
            else if (msg.type == 'appointment')
              _buildAppointmentCard(msg, chatCtrl)
            else if (msg.type == 'payment')
              _buildPaymentCard(msg, chatCtrl)
            else if (msg.type == 'voice')
              _buildVoiceMessage(msg)
            else
              Text(
                msg.content,
                style: const TextStyle(fontSize: 15, color: Color(0xFF111827), height: 1.3),
              ),

            const SizedBox(height: 4),

            // Timestamp and Status Checkmarks
            Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                const Spacer(),
                Text(
                  _formatTime(msg.createdAt),
                  style: const TextStyle(fontSize: 10.5, color: Color(0xFF6B7280)),
                ),
                if (isMerchant) ...[
                  const SizedBox(width: 4),
                  _buildDeliveryStatusIcon(msg.deliveryStatus),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDeliveryStatusIcon(MessageDeliveryStatus status) {
    switch (status) {
      case MessageDeliveryStatus.sending:
        return const Icon(Icons.access_time, size: 13, color: Color(0xFF9CA3AF));
      case MessageDeliveryStatus.sent:
        return const Icon(Icons.done, size: 14, color: Color(0xFF9CA3AF));
      case MessageDeliveryStatus.delivered:
        return const Icon(Icons.done_all, size: 14, color: Color(0xFF9CA3AF));
      case MessageDeliveryStatus.read:
        return const Icon(Icons.done_all, size: 14, color: Color(0xFF34B7F1)); // WhatsApp Cyan Blue
    }
  }

  // --- Interactive Message Card: Order ---
  Widget _buildOrderCard(ChatMessageItem msg, ChatController chatCtrl) {
    final meta = msg.metadata;
    final orderNum = meta['order_number'] ?? '#10045';
    final items = meta['items_summary'] ?? 'Prescription medication (2 items)';
    final amount = meta['total_amount'] ?? 48.50;
    final status = meta['status'] ?? 'ready_for_pickup';
    final isConfirmed = status == 'confirmed';

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.shopping_bag, size: 16, color: Color(0xFF059669)),
                  const SizedBox(width: 6),
                  Text(
                    'Order $orderNum',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: isConfirmed ? const Color(0xFFDCFCE7) : const Color(0xFFFEF3C7),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  isConfirmed ? 'Confirmed' : 'Ready',
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.bold,
                    color: isConfirmed ? const Color(0xFF166534) : const Color(0xFF92400E),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(items, style: const TextStyle(fontSize: 13, color: Color(0xFF374151))),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Total: \$$amount',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5, color: Color(0xFF111827)),
              ),
              if (!isConfirmed)
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF059669),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    minimumSize: const Size(60, 28),
                  ),
                  onPressed: () {
                    _executeCardAction(
                      messageId: msg.id,
                      actionKey: 'confirm_order',
                      title: 'Confirm Order $orderNum',
                      serviceKey: 'ecommerce',
                      payload: {'order_id': orderNum, 'amount': amount},
                      targetStatus: 'confirmed',
                    );
                  },
                  child: const Text('Confirm', style: TextStyle(fontSize: 11.5, color: Colors.white)),
                ),
            ],
          ),
        ],
      ),
    );
  }

  // --- Interactive Message Card: Appointment ---
  Widget _buildAppointmentCard(ChatMessageItem msg, ChatController chatCtrl) {
    final meta = msg.metadata;
    final doctor = meta['doctor_name'] ?? 'Dr. Alena Vance';
    final date = meta['date'] ?? 'Tomorrow 10:30 AM';
    final service = meta['service_name'] ?? 'Consultation';
    final status = meta['status'] ?? 'scheduled';
    final isConfirmed = status == 'confirmed';

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFBAE6FD)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.calendar_month, size: 16, color: Color(0xFF0284C7)),
              const SizedBox(width: 6),
              Text(
                service,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text('Doctor: $doctor', style: const TextStyle(fontSize: 12.5, color: Color(0xFF374151))),
          Text('Time: $date', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: Color(0xFF0369A1))),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(
                style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2)),
                onPressed: () => _showQuickActionToast('Reschedule modal opened'),
                child: const Text('Reschedule', style: TextStyle(fontSize: 11.5, color: Color(0xFF6B7280))),
              ),
              const SizedBox(width: 6),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: isConfirmed ? const Color(0xFF0284C7) : const Color(0xFF0284C7),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  minimumSize: const Size(60, 28),
                ),
                onPressed: isConfirmed
                    ? null
                    : () {
                        _executeCardAction(
                          messageId: msg.id,
                          actionKey: 'confirm_appointment',
                          title: 'Confirm Appointment with $doctor',
                          serviceKey: 'doctor',
                          payload: {'appointment_id': meta['appointment_id'] ?? '8042', 'date': date},
                          targetStatus: 'confirmed',
                        );
                      },
                child: Text(
                  isConfirmed ? 'Confirmed' : 'Confirm',
                  style: const TextStyle(fontSize: 11.5, color: Colors.white),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // --- Interactive Message Card: Payment ---
  Widget _buildPaymentCard(ChatMessageItem msg, ChatController chatCtrl) {
    final meta = msg.metadata;
    final invoice = meta['invoice_number'] ?? 'INV-2026-092';
    final amount = meta['amount'] ?? 75.00;
    final status = meta['status'] ?? 'pending';
    final isPaid = status == 'paid';

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFD1D5DB)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.receipt_long, size: 16, color: Color(0xFF075E54)),
                  const SizedBox(width: 6),
                  Text('Invoice $invoice', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5)),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: isPaid ? const Color(0xFFDCFCE7) : const Color(0xFFFEE2E2),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  isPaid ? 'PAID' : 'PENDING',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: isPaid ? const Color(0xFF166534) : const Color(0xFF991B1B),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text('Amount Due: \$$amount USD', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              if (!isPaid)
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF075E54),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    minimumSize: const Size(100, 28),
                  ),
                  icon: const Icon(Icons.payment, size: 14, color: Colors.white),
                  label: const Text('Collect', style: TextStyle(fontSize: 11.5, color: Colors.white)),
                  onPressed: () {
                    _executeCardAction(
                      messageId: msg.id,
                      actionKey: 'collect_payment',
                      title: 'Collect Payment for $invoice',
                      serviceKey: 'doctor',
                      payload: {'invoice_number': invoice, 'amount': amount},
                      targetStatus: 'paid',
                    );
                  },
                )
              else
                TextButton.icon(
                  icon: const Icon(Icons.check_circle, size: 14, color: Color(0xFF059669)),
                  label: const Text('Receipt Sent', style: TextStyle(fontSize: 11.5, color: Color(0xFF059669))),
                  onPressed: () => _showQuickActionToast('Receipt #INV-2026-092 opened'),
                ),
            ],
          ),
        ],
      ),
    );
  }

  // --- Voice Message Player ---
  Widget _buildVoiceMessage(ChatMessageItem msg) {
    return Row(
      children: [
        IconButton(
          icon: Icon(_isPlayingVoice ? Icons.pause_circle : Icons.play_circle, size: 36, color: const Color(0xFF075E54)),
          onPressed: () {
            setState(() => _isPlayingVoice = !_isPlayingVoice);
          },
        ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: List.generate(
                  15,
                  (i) => Expanded(
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 1),
                      height: ((i * 7) % 20 + 8).toDouble(),
                      color: _isPlayingVoice && i < 8 ? const Color(0xFF075E54) : Colors.grey.shade400,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              const Text('0:18', style: TextStyle(fontSize: 11, color: Color(0xFF6B7280))),
            ],
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: () {
            setState(() {
              if (_voiceSpeed == 1.0) {
                _voiceSpeed = 1.5;
              } else if (_voiceSpeed == 1.5) {
                _voiceSpeed = 2.0;
              } else {
                _voiceSpeed = 1.0;
              }
            });
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              '${_voiceSpeed}x',
              style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      color: const Color(0xFFF0F2F5),
      child: SafeArea(
        child: Row(
          children: [
            // Quick Attachment Button
            IconButton(
              icon: const Icon(Icons.add_circle, color: Color(0xFF075E54), size: 28),
              onPressed: _showAttachmentMenu,
            ),

            // Text Input Field
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _messageController,
                        maxLines: 4,
                        minLines: 1,
                        textCapitalization: TextCapitalization.sentences,
                        decoration: const InputDecoration(
                          hintText: 'Message or send action...',
                          hintStyle: TextStyle(color: Color(0xFF9CA3AF), fontSize: 15),
                          border: InputBorder.none,
                          isDense: true,
                          contentPadding: EdgeInsets.symmetric(vertical: 10),
                        ),
                        onChanged: (text) {
                          final composing = text.trim().isNotEmpty;
                          if (composing != _isComposing) {
                            setState(() => _isComposing = composing);
                          }
                        },
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.attach_file, color: Color(0xFF6B7280), size: 22),
                      onPressed: _showAttachmentMenu,
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(width: 6),

            // Send / Voice Button
            CircleAvatar(
              radius: 22,
              backgroundColor: const Color(0xFF075E54),
              child: IconButton(
                icon: Icon(
                  _isComposing ? Icons.send : Icons.mic,
                  color: Colors.white,
                  size: 20,
                ),
                onPressed: _isComposing
                    ? _handleSend
                    : () => _sendInteractiveCard('voice'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAttachmentMenu() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Attach Interactive Service Action',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildActionItem(
                  icon: Icons.shopping_bag,
                  color: const Color(0xFF059669),
                  label: 'Order Card',
                  onTap: () {
                    Navigator.pop(ctx);
                    _sendInteractiveCard('order');
                  },
                ),
                _buildActionItem(
                  icon: Icons.calendar_today,
                  color: const Color(0xFF0284C7),
                  label: 'Appointment',
                  onTap: () {
                    Navigator.pop(ctx);
                    _sendInteractiveCard('appointment');
                  },
                ),
                _buildActionItem(
                  icon: Icons.receipt,
                  color: const Color(0xFF7C3AED),
                  label: 'Invoice',
                  onTap: () {
                    Navigator.pop(ctx);
                    _sendInteractiveCard('payment');
                  },
                ),
                _buildActionItem(
                  icon: Icons.mic,
                  color: const Color(0xFFDC2626),
                  label: 'Voice Note',
                  onTap: () {
                    Navigator.pop(ctx);
                    _sendInteractiveCard('voice');
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionItem({
    required IconData icon,
    required Color color,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 26,
            backgroundColor: color.withValues(alpha: 0.12),
            child: Icon(icon, color: color, size: 26),
          ),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  void _showQuickActionToast(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
        backgroundColor: const Color(0xFF075E54),
      ),
    );
  }

  String _formatTime(String timeStr) {
    if (timeStr.isEmpty) return '';
    try {
      final dt = DateTime.parse(timeStr);
      final hour = dt.hour.toString().padLeft(2, '0');
      final minute = dt.minute.toString().padLeft(2, '0');
      return '$hour:$minute';
    } catch (_) {
      return timeStr.contains(' ') ? timeStr.split(' ').last : timeStr;
    }
  }
}
