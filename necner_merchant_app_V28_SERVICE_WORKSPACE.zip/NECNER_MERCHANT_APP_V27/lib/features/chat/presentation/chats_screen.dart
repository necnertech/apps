import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../app/theme/app_colors.dart';
import '../../../data/models/chat_models.dart';
import '../../auth/session/auth_controller.dart';
import '../state/chat_controller.dart';

class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});

  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  final TextEditingController _searchController = TextEditingController();
  bool _isSearching = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<ChatController>().loadConversations());
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final chatCtrl = context.watch<ChatController>();
    final auth = context.watch<AuthController>();
    final session = auth.currentSession;
    final businessName = session?.tenant.name ?? 'Necner Merchant';
    final logo = session?.user.avatarUrl;

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: const Color(0xFF075E54),
        elevation: 0,
        toolbarHeight: 70,
        titleSpacing: 14,
        title: _isSearching
            ? Container(
                height: 46,
                decoration: BoxDecoration(color: const Color(0xFF0C3E3A), borderRadius: BorderRadius.circular(14)),
                child: TextField(
                  controller: _searchController,
                  autofocus: true,
                  style: const TextStyle(color: Colors.white, fontSize: 15),
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search_rounded, color: Colors.white70),
                    hintText: 'Search chats, customers or orders',
                    hintStyle: const TextStyle(color: Colors.white60),
                    border: InputBorder.none,
                    suffixIcon: IconButton(icon: const Icon(Icons.close, color: Colors.white), onPressed: _closeSearch),
                  ),
                  onChanged: chatCtrl.setSearchQuery,
                ),
              )
            : Row(
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: Colors.white.withValues(alpha: .15),
                    backgroundImage: _imageProvider(logo),
                    child: logo == null || logo.isEmpty ? const Icon(Icons.business_rounded, color: Colors.white, size: 24) : null,
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(businessName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
                    const Text('WhatsApp Business Gateway', style: TextStyle(color: Colors.white70, fontSize: 11.5)),
                  ])),
                ],
              ),
        actions: [
          if (!_isSearching)
            IconButton(tooltip: 'Search', icon: const Icon(Icons.search_rounded, color: Colors.white), onPressed: () => setState(() => _isSearching = true)),
          PopupMenuButton<String>(
            tooltip: 'More',
            icon: const Icon(Icons.more_vert_rounded, color: Colors.white),
            onSelected: (value) {
              if (value == 'refresh') chatCtrl.loadConversations();
              if (value == 'settings') context.push('/settings');
              if (value == 'profile') context.push('/profile');
              if (value == 'whatsapp') context.push('/whatsapp');
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'refresh', child: Text('Refresh Conversations')),
              PopupMenuItem(value: 'profile', child: Text('Profile & Account')),
              PopupMenuItem(value: 'settings', child: Text('Common Settings')),
              PopupMenuItem(value: 'whatsapp', child: Text('WhatsApp Business')),
            ],
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: chatCtrl.loadConversations,
        color: const Color(0xFF075E54),
        child: _buildBody(chatCtrl),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF25D366),
        foregroundColor: Colors.white,
        tooltip: 'New chat',
        onPressed: () => _showNewChat(context),
        child: const Icon(Icons.chat_rounded),
      ),
    );
  }

  ImageProvider? _imageProvider(String? url) {
    if (url == null || url.trim().isEmpty) return null;
    return NetworkImage(url);
  }

  void _closeSearch() {
    context.read<ChatController>().setSearchQuery('');
    _searchController.clear();
    setState(() => _isSearching = false);
  }

  Widget _buildBody(ChatController ctrl) {
    if (ctrl.isLoadingConversations && ctrl.filteredConversations.isEmpty) {
      return const Center(child: CircularProgressIndicator(color: Color(0xFF075E54)));
    }
    final conversations = ctrl.filteredConversations;
    if (conversations.isEmpty) {
      return ListView(children: [
        const SizedBox(height: 210),
        Icon(Icons.chat_bubble_outline_rounded, size: 64, color: Colors.grey.shade400),
        const SizedBox(height: 16),
        Center(child: Text(ctrl.searchQuery.isNotEmpty ? 'No chats found' : 'No active chat conversations.', style: TextStyle(fontSize: 16, color: Colors.grey.shade700, fontWeight: FontWeight.w700))),
        const SizedBox(height: 8),
        Center(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 40), child: Text('Customer inquiries and order chats will appear here in real time.', textAlign: TextAlign.center, style: TextStyle(fontSize: 13, color: Colors.grey.shade500)))),
      ]);
    }
    return ListView.separated(
      itemCount: conversations.length,
      separatorBuilder: (_, __) => const Divider(height: 1, indent: 82),
      itemBuilder: (_, i) => _conversationTile(conversations[i]),
    );
  }

  Widget _conversationTile(ConversationSummary conv) {
    final unread = conv.unreadCount > 0;
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      minVerticalPadding: 7,
      onTap: () => context.push('/chats/${conv.id}'),
      leading: CircleAvatar(
        radius: 27,
        backgroundColor: const Color(0xFFE7F4F1),
        child: Text(_initials(conv.customerName), style: const TextStyle(color: Color(0xFF075E54), fontWeight: FontWeight.w800, fontSize: 16)),
      ),
      title: Row(children: [
        Expanded(child: Text(conv.customerName, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: unread ? FontWeight.w800 : FontWeight.w600, fontSize: 16))),
        Text(_formatTime(conv.lastMessageTime), style: TextStyle(fontSize: 11.5, color: unread ? const Color(0xFF008069) : Colors.grey.shade600, fontWeight: unread ? FontWeight.w700 : FontWeight.normal)),
      ]),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 5),
        child: Row(children: [
          Expanded(child: Text(conv.lastMessage.isEmpty ? conv.customerPhone : conv.lastMessage, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: unread ? Colors.black87 : Colors.grey.shade600, fontWeight: unread ? FontWeight.w600 : FontWeight.normal))),
          if (unread) Container(margin: const EdgeInsets.only(left: 8), padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3), decoration: const BoxDecoration(color: Color(0xFF25D366), shape: BoxShape.circle), child: Text('${conv.unreadCount}', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800))),
        ]),
      ),
    );
  }

  Future<void> _showNewChat(BuildContext context) async {
    final contacts = <Contact>[];
    var loading = true;
    var permissionMessage = '';
    final search = TextEditingController();
    var query = '';

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (sheetContext) {
        return StatefulBuilder(builder: (ctx, setSheet) {
          Future<void> loadContacts() async {
            setSheet(() => loading = true);
            try {
              final permission = await FlutterContacts.permissions.request(PermissionType.read);
              if (permission == PermissionStatus.granted) {
                final list = await FlutterContacts.getAll(properties: {ContactProperty.name, ContactProperty.phone});
                contacts
                  ..clear()
                  ..addAll(list.where((c) => c.displayName.trim().isNotEmpty && c.phones.isNotEmpty));
                permissionMessage = '';
              } else {
                permissionMessage = 'Contacts permission is required to show phone contacts like WhatsApp.';
              }
            } catch (e) {
              permissionMessage = 'Unable to read phone contacts on this device.';
            }
            setSheet(() => loading = false);
          }

          if (loading && contacts.isEmpty && permissionMessage.isEmpty) {
            Future.microtask(loadContacts);
          }

          final visible = contacts.where((c) {
            final q = query.trim().toLowerCase();
            if (q.isEmpty) return true;
            return c.displayName.toLowerCase().contains(q) || c.phones.any((p) => p.number.contains(q));
          }).toList();

          return SafeArea(
            child: SizedBox(
              height: MediaQuery.of(context).size.height * .86,
              child: Column(children: [
                Padding(padding: const EdgeInsets.fromLTRB(18, 14, 10, 8), child: Row(children: [
                  const Expanded(child: Text('New chat', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
                  IconButton(onPressed: () => Navigator.pop(ctx), icon: const Icon(Icons.close_rounded)),
                ])),
                Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6), child: TextField(
                  controller: search,
                  onChanged: (v) => setSheet(() => query = v),
                  decoration: InputDecoration(prefixIcon: const Icon(Icons.search_rounded), hintText: 'Search contacts', filled: true, fillColor: const Color(0xFFF1F3F5), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
                )),
                ListTile(
                  leading: const CircleAvatar(backgroundColor: Color(0xFFE6F4F1), child: Icon(Icons.person_add_alt_1_rounded, color: Color(0xFF075E54))),
                  title: const Text('New contact', style: TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: const Text('Add a contact to your phone first'),
                  onTap: () {},
                ),
                const Divider(height: 1),
                Expanded(child: loading
                    ? const Center(child: CircularProgressIndicator(color: Color(0xFF075E54)))
                    : permissionMessage.isNotEmpty
                        ? Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.contacts_outlined, size: 54, color: Colors.grey), const SizedBox(height: 12), Text(permissionMessage, textAlign: TextAlign.center), const SizedBox(height: 14), FilledButton(onPressed: loadContacts, child: const Text('Allow Contacts'))])))
                        : visible.isEmpty
                            ? const Center(child: Text('No contacts found'))
                            : ListView.separated(
                                itemCount: visible.length,
                                separatorBuilder: (_, __) => const Divider(height: 1, indent: 76),
                                itemBuilder: (_, i) {
                                  final c = visible[i];
                                  final phone = c.phones.first.number;
                                  return ListTile(
                                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                                    leading: CircleAvatar(radius: 25, backgroundColor: const Color(0xFFE7F4F1), child: Text(_initials(c.displayName), style: const TextStyle(color: Color(0xFF075E54), fontWeight: FontWeight.w800))),
                                    title: Text(c.displayName, style: const TextStyle(fontWeight: FontWeight.w700)),
                                    subtitle: Text(phone),
                                    onTap: () {
                                      Navigator.pop(ctx);
                                      final existing = context.read<ChatController>().filteredConversations.where((x) => _normalizePhone(x.customerPhone) == _normalizePhone(phone)).toList();
                                      if (existing.isNotEmpty) {
                                        context.push('/chats/${existing.first.id}');
                                      } else {
                                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${c.displayName} is saved in phone contacts. No existing merchant chat was found yet.')));
                                      }
                                    },
                                  );
                                },
                              )),
              ]),
            ),
          );
        });
      },
    );
    search.dispose();
  }

  String _normalizePhone(String value) => value.replaceAll(RegExp(r'\D'), '').replaceFirst(RegExp(r'^91'), '');
  String _initials(String name) { final p = name.trim().split(RegExp(r'\s+')); if (p.isEmpty || p.first.isEmpty) return 'C'; return p.length == 1 ? p.first[0].toUpperCase() : '${p.first[0]}${p.last[0]}'.toUpperCase(); }
  String _formatTime(String value) { if (value.isEmpty) return ''; try { final d = DateTime.parse(value); return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}'; } catch (_) { return value.contains(' ') ? value.split(' ').last : value; } }
}
