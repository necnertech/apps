import 'dart:async';
import 'package:flutter/foundation.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/logging/app_logger.dart';
import '../../../core/realtime/realtime_service.dart';
import '../../../data/models/chat_models.dart';
import '../../../data/repositories/chat_repository.dart';

class ChatController extends ChangeNotifier {
  final ChatRepository _repository;
  final RealtimeService _realtimeService;
  final String Function()? _merchantNameProvider;

  List<ConversationSummary> _conversations = [];
  final Map<String, List<ChatMessageItem>> _messagesByChatId = {};
  String? _activeChatId;

  bool _isLoadingConversations = false;
  bool _isLoadingMessages = false;
  AppException? _error;

  String _searchQuery = '';
  String _activeFilter = 'all'; // 'all' | 'unread' | 'doctor' | 'ecommerce'
  bool _isRecipientTyping = false;

  StreamSubscription<RealtimeEvent>? _realtimeSubscription;

  ChatController({
    required ChatRepository repository,
    required RealtimeService realtimeService,
    String Function()? merchantNameProvider,
  })  : _repository = repository,
        _realtimeService = realtimeService,
        _merchantNameProvider = merchantNameProvider {
    _listenToRealtimeEvents();
  }

  bool get isLoadingConversations => _isLoadingConversations;
  bool get isLoadingMessages => _isLoadingMessages;
  AppException? get error => _error;
  String? get activeChatId => _activeChatId;
  String get searchQuery => _searchQuery;
  String get activeFilter => _activeFilter;
  bool get isRecipientTyping => _isRecipientTyping;

  int get totalUnreadCount {
    return _conversations.fold<int>(0, (sum, c) => sum + c.unreadCount);
  }

  List<ConversationSummary> get filteredConversations {
    return _conversations.where((conv) {
      // 1. Search Query Filter
      if (_searchQuery.isNotEmpty) {
        final query = _searchQuery.toLowerCase();
        final matchName = conv.customerName.toLowerCase().contains(query);
        final matchPhone = conv.customerPhone.toLowerCase().contains(query);
        final matchMsg = conv.lastMessage.toLowerCase().contains(query);
        final matchService = conv.serviceLabel.toLowerCase().contains(query);
        if (!matchName && !matchPhone && !matchMsg && !matchService) {
          return false;
        }
      }

      // 2. Tab Filter
      if (_activeFilter == 'unread') {
        return conv.unreadCount > 0;
      } else if (_activeFilter == 'doctor') {
        return conv.serviceKey == 'doctor';
      } else if (_activeFilter == 'ecommerce') {
        return conv.serviceKey == 'ecommerce';
      }

      return true;
    }).toList();
  }

  List<ChatMessageItem> get activeMessages {
    if (_activeChatId == null) return [];
    return _messagesByChatId[_activeChatId] ?? [];
  }

  ConversationSummary? get activeConversation {
    if (_activeChatId == null) return null;
    try {
      return _conversations.firstWhere((c) => c.id == _activeChatId);
    } catch (_) {
      return null;
    }
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void setActiveFilter(String filter) {
    _activeFilter = filter;
    notifyListeners();
  }

  /// Loads conversation list from backend
  Future<void> loadConversations() async {
    _isLoadingConversations = true;
    _error = null;
    notifyListeners();

    final result = await _repository.getConversations();

    result.when(
      success: (items) {
        _conversations = items;
        _isLoadingConversations = false;
        notifyListeners();
      },
      failure: (err) {
        _error = err;
        _isLoadingConversations = false;
        notifyListeners();
      },
    );
  }

  /// Sets active conversation and loads its messages
  Future<void> openConversation(String chatId) async {
    _activeChatId = chatId;
    _isRecipientTyping = false;
    _isLoadingMessages = true;
    notifyListeners();

    // Mark conversation read optimistically
    _markConversationAsRead(chatId);

    final result = await _repository.getMessages(chatId);

    result.when(
      success: (items) {
        _messagesByChatId[chatId] = items;
        _isLoadingMessages = false;
        notifyListeners();
      },
      failure: (err) {
        _error = err;
        _isLoadingMessages = false;
        notifyListeners();
      },
    );

    // Call server to persist read status
    _repository.markAsRead(chatId);
  }

  /// Dispatches an interactive message optimistically
  Future<bool> sendMessage({
    required String type,
    required String content,
    Map<String, dynamic>? metadata,
  }) async {
    if (_activeChatId == null) return false;
    final chatId = _activeChatId!;

    final tempId = 'temp_${DateTime.now().millisecondsSinceEpoch}';
    final optimisticMessage = ChatMessageItem(
      id: tempId,
      chatId: chatId,
      senderType: 'merchant',
      senderId: 'current_user',
      senderName: _merchantNameProvider?.call() ?? 'Merchant',
      type: type,
      content: content,
      metadata: metadata ?? {},
      deliveryStatus: MessageDeliveryStatus.sending,
      createdAt: DateTime.now().toIso8601String().substring(0, 19).replaceAll('T', ' '),
    );

    // 1. Optimistic local update
    final currentList = List<ChatMessageItem>.from(_messagesByChatId[chatId] ?? []);
    currentList.add(optimisticMessage);
    _messagesByChatId[chatId] = currentList;

    // Update conversation preview
    _updateConversationPreview(chatId, content);
    notifyListeners();

    // 2. Dispatch to server
    final result = await _repository.sendMessage(
      chatId: chatId,
      type: type,
      content: content,
      metadata: metadata,
    );

    return result.when(
      success: (serverMessage) {
        // Replace temp message with server message
        final updatedList = List<ChatMessageItem>.from(_messagesByChatId[chatId] ?? []);
        final idx = updatedList.indexWhere((m) => m.id == tempId);
        if (idx != -1) {
          updatedList[idx] = serverMessage.copyWith(
            deliveryStatus: MessageDeliveryStatus.sent,
          );
          _messagesByChatId[chatId] = updatedList;
          notifyListeners();
        }
        return true;
      },
      failure: (err) {
        AppLogger.error('Failed to dispatch message: ${err.message}');
        return false;
      },
    );
  }

  /// Updates order or appointment card status interactively in message thread
  void updateCardAction({
    required String messageId,
    required String newStatus,
    String? additionalNote,
  }) {
    if (_activeChatId == null) return;
    final currentList = List<ChatMessageItem>.from(_messagesByChatId[_activeChatId!] ?? []);
    final idx = currentList.indexWhere((m) => m.id == messageId);
    if (idx != -1) {
      final msg = currentList[idx];
      final updatedMeta = Map<String, dynamic>.from(msg.metadata);
      updatedMeta['status'] = newStatus;
      if (additionalNote != null) {
        updatedMeta['note'] = additionalNote;
      }
      currentList[idx] = msg.copyWith(metadata: updatedMeta);
      _messagesByChatId[_activeChatId!] = currentList;
      notifyListeners();
    }
  }

  void _markConversationAsRead(String chatId) {
    final idx = _conversations.indexWhere((c) => c.id == chatId);
    if (idx != -1 && _conversations[idx].unreadCount > 0) {
      _conversations[idx] = _conversations[idx].copyWith(unreadCount: 0);
      notifyListeners();
    }
  }

  void _updateConversationPreview(String chatId, String lastMessage) {
    final idx = _conversations.indexWhere((c) => c.id == chatId);
    if (idx != -1) {
      _conversations[idx] = _conversations[idx].copyWith(
        lastMessage: lastMessage,
        lastMessageTime: 'Just now',
      );
    }
  }

  void _listenToRealtimeEvents() {
    _realtimeSubscription = _realtimeService.eventStream.listen((event) {
      if (event.eventType == 'chat.message_received') {
        final data = event.data;
        final chatId = data['chat_id']?.toString();
        if (chatId != null && data['message'] is Map<String, dynamic>) {
          final incoming = ChatMessageItem.fromJson(data['message'] as Map<String, dynamic>);

          // Append to active message list if currently viewed
          if (_activeChatId == chatId) {
            final list = List<ChatMessageItem>.from(_messagesByChatId[chatId] ?? []);
            list.add(incoming);
            _messagesByChatId[chatId] = list;
          }

          // Update conversation list
          final idx = _conversations.indexWhere((c) => c.id == chatId);
          if (idx != -1) {
            final current = _conversations[idx];
            final unreadInc = _activeChatId == chatId ? 0 : 1;
            _conversations[idx] = current.copyWith(
              lastMessage: incoming.content,
              lastMessageTime: 'Just now',
              unreadCount: current.unreadCount + unreadInc,
            );
          }
          notifyListeners();
        }
      } else if (event.eventType == 'chat.typing') {
        if (event.data['chat_id']?.toString() == _activeChatId) {
          _isRecipientTyping = event.data['is_typing'] == true;
          notifyListeners();
        }
      }
    });
  }

  @override
  void dispose() {
    _realtimeSubscription?.cancel();
    super.dispose();
  }
}
