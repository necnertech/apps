import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../app/theme/app_colors.dart';
import '../../../app/config/app_config.dart';
import '../../../core/constants/api_endpoints.dart';
import '../../../core/network/api_client.dart';
import '../../../core/secure_storage/secure_storage_service.dart';
import '../presentation/template_builder_screen.dart';
import '../../whatsapp/presentation/whatsapp_hub_screen.dart';

class GlobalToolsScreen extends StatefulWidget {
  const GlobalToolsScreen({super.key});

  @override
  State<GlobalToolsScreen> createState() => _GlobalToolsScreenState();
}

class _GlobalToolsScreenState extends State<GlobalToolsScreen> {
  late final ApiClient _api;
  bool _loading = true;
  String? _error;
  Map<String, dynamic> _overview = {};
  List<Map<String, dynamic>> _contacts = [];
  List<Map<String, dynamic>> _team = [];
  List<Map<String, dynamic>> _transactions = [];
  List<Map<String, dynamic>> _numbers = [];
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    _api = ApiClient(config: context.read<AppConfig>(), storage: SecureStorageService(), onSessionExpired: () {});
    _load();
  }

  Future<Map<String, dynamic>> _get(String route, {Map<String, dynamic>? query}) async {
    final result = await _api.get<Map<String, dynamic>>(
      ApiEndpoints.global,
      queryParameters: {'route': route, ...?query},
      parser: (data) => Map<String, dynamic>.from(data as Map),
    );
    Map<String, dynamic> out = {};
    result.when(success: (value) => out = value, failure: (e) => throw Exception(e.message));
    return out;
  }

  Future<Map<String, dynamic>> _post(String route, Map<String, dynamic> body) async {
    final result = await _api.post<Map<String, dynamic>>(
      ApiEndpoints.global,
      queryParameters: {'route': route},
      data: body,
      parser: (data) => Map<String, dynamic>.from(data as Map),
    );
    Map<String, dynamic> out = {};
    result.when(success: (value) => out = value, failure: (e) => throw Exception(e.message));
    return out;
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final overview = await _get('overview');
      final contacts = await _get('contacts');
      final team = await _get('team');
      final tx = await _get('transactions');
      final numbers = await _get('whatsapp-numbers');
      if (!mounted) return;
      setState(() {
        _overview = overview;
        _contacts = _list(contacts);
        _team = _list(team);
        _transactions = _list(tx);
        _numbers = _list(numbers);
        _error = null;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  List<Map<String, dynamic>> _list(Map<String, dynamic> value) {
    final raw = value['items'];
    return raw is List ? raw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList() : [];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: AppColors.primaryTeal,
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Merchant Tools', style: TextStyle(fontWeight: FontWeight.w800)),
          Text('Business communication & operations', style: TextStyle(fontSize: 11, color: Colors.white70)),
        ]),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded)), const SizedBox(width: 4)],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primaryEmerald))
          : _error != null
              ? _errorView()
              : Column(children: [
                  _hero(),
                  _tabs(),
                  Expanded(child: IndexedStack(index: _tab, children: [_communication(), _crm(), _billing(), _account()])),
                ]),
    );
  }

  Widget _hero() {
    final sub = _overview['subscription'] is Map ? Map<String, dynamic>.from(_overview['subscription']) : <String, dynamic>{};
    final payment = _overview['payments'] is Map ? Map<String, dynamic>.from(_overview['payments']) : <String, dynamic>{};
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 14, 14, 10),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF075E54), Color(0xFF008069)]),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [BoxShadow(color: const Color(0xFF075E54).withValues(alpha: .16), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      child: Row(children: [
        Container(width: 52, height: 52, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .14), borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.tune_rounded, color: Colors.white, size: 28)),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text((_overview['tenant'] as Map?)?['business_name']?.toString() ?? 'Your Business', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text('${sub['plan_name'] ?? 'Business Plan'}  •  Received ₹${payment['received'] ?? 0}', style: const TextStyle(color: Colors.white70, fontSize: 11.5)),
        ])),
      ]),
    );
  }

  Widget _tabs() => Container(
    margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
    padding: const EdgeInsets.all(4),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.borderLight)),
    child: Row(children: [
      _tabButton(0, 'WhatsApp', Icons.chat_rounded), _tabButton(1, 'CRM', Icons.people_alt_rounded), _tabButton(2, 'Billing', Icons.account_balance_wallet_rounded), _tabButton(3, 'Settings', Icons.settings_rounded),
    ]),
  );

  Widget _tabButton(int index, String title, IconData icon) => Expanded(child: InkWell(
    onTap: () => setState(() => _tab = index),
    borderRadius: BorderRadius.circular(10),
    child: AnimatedContainer(duration: const Duration(milliseconds: 180), padding: const EdgeInsets.symmetric(vertical: 9), decoration: BoxDecoration(color: _tab == index ? const Color(0xFFE6F4F1) : Colors.transparent, borderRadius: BorderRadius.circular(10)), child: Column(children: [Icon(icon, size: 18, color: _tab == index ? AppColors.primaryTeal : AppColors.textSecondaryLight), const SizedBox(height: 3), Text(title, style: TextStyle(fontSize: 10.5, fontWeight: _tab == index ? FontWeight.w800 : FontWeight.w500, color: _tab == index ? AppColors.primaryTeal : AppColors.textSecondaryLight))])),
  ));

  Widget _communication() => ListView(padding: const EdgeInsets.fromLTRB(14, 12, 14, 28), children: [
    _sectionTitle('WhatsApp Business', 'All communication tools in one place'),
    _grid([
      _tool('WhatsApp Center', 'Contacts, groups, templates & campaigns', Icons.chat_bubble_rounded, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WhatsAppHubScreen()))),
      _tool('Template Builder', 'Screenshot-style live template designer', Icons.article_rounded, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TemplateBuilderScreen()))),
      _tool('Broadcast', 'Create and queue campaigns', Icons.campaign_rounded, () => _showCampaignDialog()),
      _tool('CRM & Deals', 'Contacts, pipeline and follow-ups', Icons.insights_rounded, () => _openWeb('/admin/tenant-view.php?tab=crm')),
      _tool('WhatsApp Number', _numbers.isEmpty ? 'Connect / configure number' : '${_numbers.length} number(s) connected', Icons.phone_android_rounded, () => _showNumbers()),
    ]),
    const SizedBox(height: 18),
    _sectionTitle('Automation & AI', 'Global tools available across assigned services'),
    _grid([
      _tool('Automation Flows', 'Open the existing automation workspace', Icons.account_tree_rounded, () => _openWeb('/automation/index.php')),
      _tool('Auto Replies', 'Configure instant replies', Icons.reply_all_rounded, () => _openWeb('/automation/auto-replies.php')),
      _tool('Flow Builder', 'Build customer journeys', Icons.hub_rounded, () => _openWeb('/automation/builder.php')),
      _tool('AI Dashboard', 'AI activity and controls', Icons.smart_toy_rounded, () => _openWeb('/ai/index.php')),
      _tool('AI Knowledge Base', 'Manage business knowledge', Icons.menu_book_rounded, () => _openWeb('/ai/knowledge-base.php')),
      _tool('AI Logs', 'Review AI execution logs', Icons.receipt_long_rounded, () => _openWeb('/ai/logs.php')),
    ]),
  ]);

  Widget _crm() => ListView(padding: const EdgeInsets.fromLTRB(14, 12, 14, 28), children: [
    _sectionTitle('Contacts', '${_contacts.length} contacts in this merchant account'),
    _grid([
      _tool('Add Contact', 'Save a customer/lead', Icons.person_add_alt_1_rounded, _addContact),
      _tool('Sync Phone Contacts', 'Import from this device', Icons.sync_rounded, _syncPhoneContacts),
      _tool('Sync Google Contacts', 'Secure Google authorization sync', Icons.account_circle_rounded, _syncGoogleContacts),
      _tool('Import CSV', 'Bulk import contacts', Icons.upload_file_rounded, _importCsv),
      _tool('Export Contacts', 'Share a CSV export', Icons.download_rounded, _exportContacts),
    ]),
    const SizedBox(height: 10),
    _cardList(_contacts, title: 'Recent Contacts', icon: Icons.contacts_rounded, titleKey: 'name', subtitleKey: 'phone'),
    const SizedBox(height: 18),
    _sectionTitle('Team', '${_team.length} team records'),
    _grid([_tool('Team Members', 'Manage teams and members', Icons.groups_rounded, _showTeam), _tool('Add Team', 'Create a team', Icons.group_add_rounded, _addTeam)]),
    const SizedBox(height: 10),
    _cardList(_team, title: 'Team', icon: Icons.groups_rounded, titleKey: 'user_name', subtitleKey: 'email'),
  ]);

  Widget _billing() {
    final p = _overview['payments'] is Map ? Map<String, dynamic>.from(_overview['payments']) : <String, dynamic>{};
    final s = _overview['subscription'] is Map ? Map<String, dynamic>.from(_overview['subscription']) : <String, dynamic>{};
    return ListView(padding: const EdgeInsets.fromLTRB(14, 12, 14, 28), children: [
      _sectionTitle('Payment Overview', 'Live totals from the merchant account'),
      Row(children: [Expanded(child: _metric('Received', '₹${p['received'] ?? 0}', const Color(0xFF008069))), const SizedBox(width: 8), Expanded(child: _metric('Pending', '₹${p['pending'] ?? 0}', const Color(0xFFF59E0B))), const SizedBox(width: 8), Expanded(child: _metric('Refunded', '₹${p['refunded'] ?? 0}', const Color(0xFFEF4444)))]),
      const SizedBox(height: 14),
      _card(title: 'Current Plan', icon: Icons.workspace_premium_rounded, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(s['plan_name']?.toString() ?? 'No active plan', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)), const SizedBox(height: 6), Text('Status: ${s['status'] ?? '—'}   •   Valid until: ${s['end_date'] ?? '—'}', style: const TextStyle(color: AppColors.textSecondaryLight)), const SizedBox(height: 12), FilledButton.icon(onPressed: () => _openWeb('/admin/subscriptions.php'), icon: const Icon(Icons.autorenew_rounded), label: const Text('Renew / Manage Plan'))])),
      const SizedBox(height: 14),
      _card(title: 'Transactions', icon: Icons.receipt_long_rounded, child: Column(children: _transactions.take(12).map((x) => ListTile(contentPadding: EdgeInsets.zero, leading: CircleAvatar(backgroundColor: const Color(0xFFE8F5E9), child: Icon(x['kind'] == 'order' ? Icons.shopping_bag_rounded : Icons.payments_rounded, color: AppColors.primaryTeal)), title: Text((x['order_number'] ?? x['transaction_id'] ?? 'Transaction').toString(), style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${x['status'] ?? ''}  •  ${x['created_at'] ?? ''}'), trailing: Text('₹${x['total_amount'] ?? x['amount'] ?? 0}', style: const TextStyle(fontWeight: FontWeight.w800)), onTap: () => _openInvoice(x['invoice_url']?.toString())),).toList())),
    ]);
  }

  Widget _account() => ListView(padding: const EdgeInsets.fromLTRB(14, 12, 14, 28), children: [
    _sectionTitle('Security & Account', 'Merchant controls'),
    _grid([
      _tool('Change Password', 'Update your merchant password', Icons.lock_reset_rounded, _changePassword),
      _tool('Subscription', 'Plan, renewal and usage', Icons.workspace_premium_rounded, () => setState(() => _tab = 2)),
      _tool('WhatsApp Connection', 'Numbers and connection status', Icons.phonelink_ring_rounded, _showNumbers),
      _tool('Support', 'Open support center', Icons.support_agent_rounded, () => _openWeb('/admin/support.php')),
    ]),
    const SizedBox(height: 18),
    _card(title: 'Service-wide capability model', icon: Icons.layers_rounded, child: const Text('Contacts, CRM, templates, broadcasts, automation, payments, invoices and notifications are common capabilities. Each assigned service keeps its own business modules and actions.')),
  ]);

  Widget _sectionTitle(String title, String subtitle) => Padding(padding: const EdgeInsets.only(bottom: 9), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondaryLight))]));
  Widget _grid(List<Widget> children) => LayoutBuilder(builder: (context, c) { final cols = c.maxWidth >= 700 ? 3 : 2; return GridView.count(crossAxisCount: cols, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisSpacing: 9, mainAxisSpacing: 9, childAspectRatio: 1.28, children: children); });
  Widget _tool(String title, String sub, IconData icon, VoidCallback onTap) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(16), child: Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.borderLight)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Container(width: 40, height: 40, decoration: BoxDecoration(color: const Color(0xFFE6F4F1), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: AppColors.primaryTeal, size: 21)), const Spacer(), Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)), const SizedBox(height: 3), Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.2, color: AppColors.textSecondaryLight))])));
  Widget _metric(String title, String value, Color color) => Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15), border: Border.all(color: AppColors.borderLight)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 10.5, color: AppColors.textSecondaryLight)), const SizedBox(height: 5), Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: color))]));
  Widget _card({required String title, required IconData icon, required Widget child}) => Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17), border: Border.all(color: AppColors.borderLight)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(icon, color: AppColors.primaryTeal, size: 20), const SizedBox(width: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.w800))]), const SizedBox(height: 12), child]));
  Widget _cardList(List<Map<String, dynamic>> items, {required String title, required IconData icon, required String titleKey, required String subtitleKey}) => _card(title: title, icon: icon, child: items.isEmpty ? const Text('No records yet.', style: TextStyle(color: AppColors.textSecondaryLight)) : Column(children: items.take(8).map((x) => ListTile(contentPadding: EdgeInsets.zero, leading: CircleAvatar(backgroundColor: const Color(0xFFE6F4F1), child: Icon(icon, color: AppColors.primaryTeal, size: 18)), title: Text((x[titleKey] ?? x['name'] ?? 'Record').toString(), style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text((x[subtitleKey] ?? '').toString()), dense: true)).toList()));
  Widget _errorView() => Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.cloud_off_rounded, size: 52, color: Colors.grey), const SizedBox(height: 12), Text(_error!, textAlign: TextAlign.center), const SizedBox(height: 16), FilledButton.icon(onPressed: _load, icon: const Icon(Icons.refresh), label: const Text('Retry'))])));

  Future<void> _addContact() async {
    final name=TextEditingController(),phone=TextEditingController(),email=TextEditingController();
    await _dialog('Add Contact', [_field(name,'Name'),_field(phone,'Phone',keyboard:TextInputType.phone),_field(email,'Email',keyboard:TextInputType.emailAddress)], () async { await _post('contacts', {'name':name.text,'phone':phone.text,'email':email.text}); await _load(); });
  }
  Future<void> _syncGoogleContacts() async {
    try {
      final r=await _api.get<Map<String,dynamic>>('/mobile/google-contacts.php',queryParameters:{'action':'start'},parser:(d)=>Map<String,dynamic>.from(d as Map));
      r.when(success:(data)async{final url=data['authorization_url']?.toString()??'';if(url.isNotEmpty){await launchUrl(Uri.parse(url),mode:LaunchMode.externalApplication);_toast('Complete Google authorization. Contacts will sync automatically.');}},failure:(e)=>_toast(e.message));
    } catch(e){_toast('Google Contacts sync failed: $e');}
  }

  Future<void> _syncPhoneContacts() async {
    try {
      final status=await FlutterContacts.permissions.request(PermissionType.read); if(status!=PermissionStatus.granted){_toast('Contacts permission was not granted.');return;}
      final contacts=await FlutterContacts.getAll(properties:{ContactProperty.name,ContactProperty.phone,ContactProperty.email}); int saved=0;
      for(final c in contacts){ if(c.phones.isEmpty) continue; final phone=c.phones.first.number.trim(); if(phone.isEmpty) continue; final displayName=c.displayName ?? ''; final email=c.emails.isNotEmpty ? c.emails.first.address : ''; await _post('contacts', {'name':displayName.isEmpty?'Contact':displayName,'phone':phone,'email':email}); saved++; }
      await _load(); _toast('$saved phone contacts synchronized.');
    } catch(e){_toast('Phone contact sync failed: $e');}
  }
  Future<void> _importCsv() async {
    final r=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['csv','txt'],withData:true); if(r==null||r.files.single.bytes==null)return;
    final text=utf8.decode(r.files.single.bytes!); final lines=text.split(RegExp(r'\r?\n')).where((x)=>x.trim().isNotEmpty).toList(); int count=0;
    for(int i=1;i<lines.length;i++){final cols=lines[i].split(',');if(cols.length<2)continue;await _post('contacts',{'name':cols[0].trim(),'phone':cols[1].trim(),'email':cols.length>2?cols[2].trim():''});count++;}
    await _load();_toast('$count contacts imported.');
  }
  Future<void> _exportContacts() async {
    final rows=['Name,Phone,Email']; for(final x in _contacts){rows.add('${_csv(x['name'])},${_csv(x['phone'])},${_csv(x['email'])}');}
    final dir=Directory.systemTemp;final file=File('${dir.path}/necner_contacts_${DateTime.now().millisecondsSinceEpoch}.csv');await file.writeAsString(rows.join('\n'));await Share.shareXFiles([XFile(file.path)],text:'Necner Merchant contacts export');
  }
  String _csv(dynamic v)=>'"${(v??'').toString().replaceAll('"','""')}"';
  Future<void> _showTeam() async { await showModalBottomSheet(context:context,isScrollControlled:true,showDragHandle:true,builder:(_)=>SizedBox(height:MediaQuery.of(context).size.height*.72,child:ListView(padding:const EdgeInsets.all(18),children:[const Text('Team Members',style:TextStyle(fontSize:20,fontWeight:FontWeight.w800)),const SizedBox(height:12),..._team.map((x)=>ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text((x['user_name']??x['team_name']??'Team').toString()),subtitle:Text((x['email']??x['description']??'').toString())))])));}
  Future<void> _addTeam() async { final name=TextEditingController(),desc=TextEditingController(),email=TextEditingController(); await _dialog('Create Team',[_field(name,'Team name'),_field(desc,'Description'),_field(email,'Existing member email (optional)',keyboard:TextInputType.emailAddress)],()async{await _post('team',{'name':name.text,'description':desc.text,'email':email.text});await _load();}); }
  Future<void> _changePassword() async { final old=TextEditingController(),n=TextEditingController(),c=TextEditingController(); await _dialog('Change Password',[_field(old,'Current password',obscure:true),_field(n,'New password',obscure:true),_field(c,'Confirm password',obscure:true)],()async{if(n.text!=c.text)throw Exception('New passwords do not match.');await _post('password',{'current_password':old.text,'new_password':n.text});_toast('Password changed successfully.');}); }
  Future<void> _showCampaignDialog() async { final name=TextEditingController(); await _dialog('Create Broadcast',[_field(name,'Campaign name')],()async{final cfg=await _post('campaign-proxy',{'name':name.text});_toast(cfg['message']?.toString()??'Broadcast created.');}); }
  Future<void> _showNumbers() async { await showModalBottomSheet(context:context,showDragHandle:true,builder:(_)=>ListView(padding:const EdgeInsets.all(18),children:[const Text('WhatsApp Business Numbers',style:TextStyle(fontSize:20,fontWeight:FontWeight.w800)),const SizedBox(height:12),..._numbers.map((x)=>ListTile(leading:const CircleAvatar(backgroundColor:Color(0xFFE6F4F1),child:Icon(Icons.phone,color:AppColors.primaryTeal)),title:Text((x['display_name']??x['phone_number']??'WhatsApp').toString()),subtitle:Text('${x['status']??''} • ${x['quality_rating']??''}'))),if(_numbers.isEmpty)const Text('No WhatsApp Business number is connected yet. Connect it from the WhatsApp Business settings in the web control center.') ])); }
  Future<void> _openWeb(String path) async { final cfg=context.read<AppConfig>(); final url='${cfg.apiBaseUrl}$path'; await launchUrl(Uri.parse(url),mode:LaunchMode.externalApplication); }
  Future<void> _openInvoice(String? url) async { if(url==null||url.isEmpty)return;await launchUrl(Uri.parse(url),mode:LaunchMode.externalApplication); }
  Widget _field(TextEditingController c,String label,{TextInputType? keyboard,bool obscure=false})=>TextField(controller:c,keyboardType:keyboard,obscureText:obscure,decoration:InputDecoration(labelText:label));
  Future<void> _dialog(String title,List<Widget> fields,Future<void> Function() save) async {await showDialog(context:context,builder:(ctx)=>AlertDialog(title:Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),content:SizedBox(width:420,child:Column(mainAxisSize:MainAxisSize.min,children:fields.map((x)=>Padding(padding:const EdgeInsets.only(bottom:10),child:x)).toList())),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:()async{try{await save();if(ctx.mounted)Navigator.pop(ctx);}catch(e){if(ctx.mounted)ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content:Text(e.toString())));}},child:const Text('Save'))]));}
  void _toast(String s){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}
}
