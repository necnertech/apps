import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../../core/errors/app_exception.dart';
import '../../../core/push/push_notification_service.dart';
import '../../../data/models/notification_models.dart';
import '../../../data/repositories/notification_repository.dart';

class NotificationsController extends ChangeNotifier {
  final NotificationRepository _repository;
  final PushNotificationService _pushService;

  List<PushNotificationItem> _notifications = [];
  bool _isLoading = false;
  AppException? _error;
  String _activeFilter = 'all';

  StreamSubscription<PushNotificationItem>? _pushSubscription;
  Timer? _pollTimer;
  int _latestNotificationId = 0;

  NotificationsController({
    required NotificationRepository repository,
    required PushNotificationService pushService,
  })  : _repository = repository,
        _pushService = pushService {
    _listenToForegroundPushes();
  }

  bool get isLoading => _isLoading;
  AppException? get error => _error;
  String get activeFilter => _activeFilter;

  int get unreadCount => _notifications.where((n) => !n.isRead).length;

  List<PushNotificationItem> get filteredNotifications {
    if (_activeFilter == 'all') return _notifications;
    return _notifications.where((n) => n.type == _activeFilter).toList();
  }

  void setFilter(String filter) {
    _activeFilter = filter;
    notifyListeners();
  }

  Future<void> loadNotifications() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    final result = await _repository.getNotifications();
    result.when(
      success: (items) {
        _notifications = items;
        _latestNotificationId = items
            .map((n) => int.tryParse(n.id) ?? 0)
            .fold<int>(0, (a, b) => a > b ? a : b);
        _isLoading = false;
        notifyListeners();
      },
      failure: (err) {
        _error = err;
        _isLoading = false;
        notifyListeners();
      },
    );
  }

  void startFastPolling() {
    _pollTimer?.cancel();
    // Load the current bell state immediately, then keep the foreground
    // badge synchronized with the server at a short interval.
    loadNotifications();
    _pollTimer = Timer.periodic(
      const Duration(seconds: 2),
      (_) => _pollForNewNotifications(),
    );
  }

  void stopFastPolling() {
    _pollTimer?.cancel();
    _pollTimer = null;
  }

  Future<void> _pollForNewNotifications() async {
    final result = await _repository.pollNewNotifications(
      afterId: _latestNotificationId,
    );

    result.when(
      success: (payload) {
        final raw = payload['items'];
        final items = raw is List ? raw : const <dynamic>[];
        var changed = false;

        for (final entry in items.whereType<Map>()) {
          final notification = PushNotificationItem.fromJson(
            Map<String, dynamic>.from(entry),
          );
          if (_notifications.every((item) => item.id != notification.id)) {
            _notifications.insert(0, notification);
            changed = true;
          }

          final id = int.tryParse(notification.id) ?? 0;
          if (id > _latestNotificationId) {
            _latestNotificationId = id;
          }
        }

        if (changed) notifyListeners();
      },
      failure: (_) {},
    );
  }

  Future<void> markAsRead(String notificationId) async {
    final idx = _notifications.indexWhere((n) => n.id == notificationId);
    if (idx == -1 || _notifications[idx].isRead) return;

    _notifications[idx] = _notifications[idx].copyWith(isRead: true);
    notifyListeners();
    await _repository.markAsRead(notificationId);
  }

  Future<void> markAllAsRead() async {
    _notifications =
        _notifications.map((n) => n.copyWith(isRead: true)).toList();
    notifyListeners();

    for (final notification in _notifications) {
      await _repository.markAsRead(notification.id);
    }
  }

  void _listenToForegroundPushes() {
    _pushSubscription =
        _pushService.onForegroundNotification.listen((notification) {
      _notifications.insert(0, notification);
      notifyListeners();
    });
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _pushSubscription?.cancel();
    super.dispose();
  }
}
