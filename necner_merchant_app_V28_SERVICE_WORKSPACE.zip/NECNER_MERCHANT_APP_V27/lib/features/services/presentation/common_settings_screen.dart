import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../app/theme/app_colors.dart';
import '../../../data/models/service_models.dart';
import '../state/services_controller.dart';
import 'merchant_webview_screen.dart';

class CommonSettingsScreen extends StatefulWidget {
  final bool profileOnly;

  const CommonSettingsScreen({super.key, this.profileOnly = false});

  @override
  State<CommonSettingsScreen> createState() => _CommonSettingsScreenState();
}

class _CommonSettingsScreenState extends State<CommonSettingsScreen> {
  bool _loading = true;
  String? _error;
  List<ServiceModule> _modules = const [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final controller = context.read<ServicesController>();
    if (controller.services.isEmpty) await controller.loadAssignedServices();
    if (controller.services.isEmpty) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'No assigned service is available for loading merchant settings.';
      });
      return;
    }

    final merged = <String, ServiceModule>{};
    for (final service in controller.services) {
      final manifest = await controller.loadManifest(service.serviceKey);
      if (manifest == null) continue;
      for (final module in manifest.commonModules) {
        merged[module.moduleKey] = module;
      }
    }

    var modules = merged.values.toList()
      ..sort((a, b) {
        final group = a.group.compareTo(b.group);
        return group != 0 ? group : a.sortOrder.compareTo(b.sortOrder);
      });

    if (widget.profileOnly) {
      modules = modules.where((m) {
        final g = m.group.toLowerCase();
        final id = m.id.toLowerCase();
        return g.contains('account') || g.contains('profile') || id.contains('profile') || id.contains('team') || id.contains('staff') || id.contains('account') || id.contains('password');
      }).toList(growable: false);
    }

    if (!mounted) return;
    setState(() {
      _modules = modules;
      _loading = false;
      if (modules.isEmpty) {
        _error = widget.profileOnly
            ? 'No profile/account functions are configured for this merchant.'
            : 'No common merchant settings are configured.';
      }
    });
  }

  Future<void> _openFunction(ServiceModule module) async {
    var route = module.route.trim();
    if (route.isNotEmpty) {
      final absolute = Uri.tryParse(route);
      if (absolute != null && absolute.hasScheme && absolute.host.isNotEmpty) {
        route = absolute.path + (absolute.hasQuery ? '?${absolute.query}' : '');
      }
    }
    if (route.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${module.title} has no web route configured.')));
      return;
    }
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => MerchantWebViewScreen(title: module.title, path: route),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.profileOnly ? 'Profile Settings' : 'Settings';
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded))],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppColors.primaryEmerald));
    if (_error != null && _modules.isEmpty) {
      return Center(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.settings_outlined, size: 48, color: AppColors.textSecondaryLight),
          const SizedBox(height: 12),
          Text(_error!, textAlign: TextAlign.center),
          const SizedBox(height: 18),
          FilledButton.icon(onPressed: _load, icon: const Icon(Icons.refresh), label: const Text('Retry')),
        ]),
      ));
    }

    final groups = <String, List<ServiceModule>>{};
    for (final module in _modules) {
      groups.putIfAbsent(module.group.isEmpty ? 'Common' : module.group, () => []).add(module);
    }

    return RefreshIndicator(
      onRefresh: _load,
      color: AppColors.primaryEmerald,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 30),
        children: [
          Text(widget.profileOnly ? 'Profile & Account' : 'Common Settings', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 5),
          Text(widget.profileOnly ? 'Business profile, account and team controls' : 'Common functions shared across your assigned services', style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight)),
          const SizedBox(height: 18),
          if (groups.isEmpty) _emptyCard(),
          ...groups.entries.map((entry) => Padding(
            padding: const EdgeInsets.only(bottom: 22),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Padding(padding: const EdgeInsets.only(left: 4, bottom: 10), child: Text(entry.key, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800))),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: entry.value.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 18, childAspectRatio: .82),
                itemBuilder: (_, i) => _tile(entry.value[i]),
              ),
            ]),
          )),
        ],
      ),
    );
  }

  Widget _emptyCard() => Container(
    padding: const EdgeInsets.all(24),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.borderLight)),
    child: const Text('No common merchant settings are configured for this account.', textAlign: TextAlign.center),
  );

  Widget _tile(ServiceModule module) => InkWell(
    borderRadius: BorderRadius.circular(18),
    onTap: () => _openFunction(module),
    child: Column(children: [
      Container(width: 64, height: 64, decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFFE4F5F0), border: Border.all(color: AppColors.primaryTeal.withValues(alpha: .15))), alignment: Alignment.center,
        child: Icon(_icon(module.icon), color: AppColors.primaryTeal, size: 28)),
      const SizedBox(height: 8),
      Text(module.title, maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5, height: 1.15, fontWeight: FontWeight.w700)),
    ]),
  );

  IconData _icon(String raw) {
    final s = raw.toLowerCase();
    if (s.contains('whatsapp') || s.contains('message') || s.contains('chat')) return Icons.chat_rounded;
    if (s.contains('crm') || s.contains('contact') || s.contains('customer')) return Icons.people_alt_rounded;
    if (s.contains('automation') || s.contains('ai')) return Icons.smart_toy_rounded;
    if (s.contains('report') || s.contains('analytic')) return Icons.analytics_rounded;
    if (s.contains('billing') || s.contains('subscription') || s.contains('payment')) return Icons.receipt_long_rounded;
    if (s.contains('profile') || s.contains('account')) return Icons.manage_accounts_rounded;
    if (s.contains('team') || s.contains('staff') || s.contains('user')) return Icons.groups_rounded;
    if (s.contains('support') || s.contains('help')) return Icons.support_agent_rounded;
    return Icons.settings_rounded;
  }
}
