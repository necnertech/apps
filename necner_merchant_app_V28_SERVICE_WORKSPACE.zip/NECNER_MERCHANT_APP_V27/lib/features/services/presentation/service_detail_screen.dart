import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../app/theme/app_colors.dart';
import '../../../data/models/service_models.dart';
import '../state/services_controller.dart';
import 'merchant_webview_screen.dart';

class ServiceDetailScreen extends StatefulWidget {
  final String serviceKey;

  const ServiceDetailScreen({super.key, required this.serviceKey});

  @override
  State<ServiceDetailScreen> createState() => _ServiceDetailScreenState();
}

class _ServiceDetailScreenState extends State<ServiceDetailScreen> {
  bool _loading = true;
  String? _error;
  ServiceDiscoveryItem? _service;
  ServiceManifest? _manifest;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    final controller = context.read<ServicesController>();
    if (controller.services.isEmpty) await controller.loadAssignedServices();
    final matches = controller.services.where((s) => s.serviceKey == widget.serviceKey).toList();
    if (matches.isEmpty) {
      if (!mounted) return;
      setState(() { _loading = false; _error = 'This service is not assigned to the current merchant.'; });
      return;
    }
    final manifest = await controller.loadManifest(widget.serviceKey);
    if (!mounted) return;
    if (manifest == null) {
      setState(() { _loading = false; _error = controller.error?.message ?? 'Unable to load this service functions.'; });
      return;
    }
    setState(() { _service = matches.first; _manifest = manifest; _loading = false; });
  }

  String _routeFor(ServiceModule module) {
    var route = module.route.trim();
    if (route.isEmpty) return '';
    final absolute = Uri.tryParse(route);
    if (absolute != null && absolute.hasScheme && absolute.host.isNotEmpty) {
      route = absolute.path + (absolute.hasQuery ? '?${absolute.query}' : '');
    }
    if (route.startsWith('/')) return route;
    final prefix = _service?.urlPrefix.trim().replaceAll(RegExp(r'^/+|/+$'), '') ?? '';
    if (prefix.isEmpty) return '/$route';
    return '/$prefix/$route';
  }

  void _openModule(ServiceModule module) {
    final route = _routeFor(module);
    if (route.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${module.title} has no web page route configured in the service manifest.')));
      return;
    }
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => MerchantWebViewScreen(
        title: module.title,
        path: route,
        serviceKey: widget.serviceKey,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.primaryEmerald)));
    if (_error != null || _manifest == null || _service == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Service')),
        body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.error_outline_rounded, size: 48, color: Colors.redAccent),
          const SizedBox(height: 12),
          Text(_error ?? 'Service unavailable', textAlign: TextAlign.center),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: _load, icon: const Icon(Icons.refresh), label: const Text('Retry')),
        ]))),
      );
    }

    final modules = _manifest!.modules.where((m) => !m.common).toList()
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: AppColors.primaryTeal,
        foregroundColor: Colors.white,
        title: Text(_service!.serviceName, style: const TextStyle(fontWeight: FontWeight.w800)),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded))],
      ),
      body: RefreshIndicator(
        color: AppColors.primaryEmerald,
        onRefresh: _load,
        child: modules.isEmpty
            ? ListView(children: const [SizedBox(height: 180), Center(child: Text('No service functions were published for this service.'))])
            : GridView.builder(
                padding: const EdgeInsets.fromLTRB(14, 16, 14, 30),
                itemCount: modules.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 18,
                  childAspectRatio: .82,
                ),
                itemBuilder: (_, index) => _moduleItem(modules[index]),
              ),
      ),
    );
  }

  Widget _moduleItem(ServiceModule module) {
    final enabled = module.capability == CapabilityState.available || module.capability == CapabilityState.readOnly;
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: enabled ? () => _openModule(module) : null,
      child: Column(children: [
        Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: enabled ? const Color(0xFFE4F5F0) : Colors.grey.shade200,
            border: Border.all(color: enabled ? AppColors.primaryTeal.withValues(alpha: .16) : Colors.grey.shade300),
          ),
          alignment: Alignment.center,
          child: Icon(_icon(module.icon, module.title), color: enabled ? AppColors.primaryTeal : Colors.grey, size: 29),
        ),
        const SizedBox(height: 8),
        Text(module.title, maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis,
          style: TextStyle(fontSize: 12.5, height: 1.15, fontWeight: FontWeight.w700, color: enabled ? AppColors.textPrimaryLight : Colors.grey)),
        if (module.actions.isNotEmpty) ...[
          const SizedBox(height: 3),
          Text('${module.actions.length} actions', style: const TextStyle(fontSize: 9.5, color: AppColors.textSecondaryLight)),
        ],
      ]),
    );
  }

  IconData _icon(String raw, String title) {
    final s = '${raw.toLowerCase()} ${title.toLowerCase()}';
    if (s.contains('appointment') || s.contains('booking') || s.contains('calendar')) return Icons.calendar_month_rounded;
    if (s.contains('patient') || s.contains('doctor') || s.contains('clinic') || s.contains('medical')) return Icons.medical_services_rounded;
    if (s.contains('prescription') || s.contains('medicine') || s.contains('pharmacy')) return Icons.medication_rounded;
    if (s.contains('order')) return Icons.shopping_bag_rounded;
    if (s.contains('product') || s.contains('catalog')) return Icons.inventory_2_rounded;
    if (s.contains('customer') || s.contains('contact')) return Icons.people_alt_rounded;
    if (s.contains('payment') || s.contains('billing')) return Icons.receipt_long_rounded;
    if (s.contains('report') || s.contains('analytic')) return Icons.analytics_rounded;
    if (s.contains('message') || s.contains('chat') || s.contains('whatsapp')) return Icons.chat_rounded;
    if (s.contains('setting')) return Icons.settings_rounded;
    if (s.contains('staff') || s.contains('team') || s.contains('user')) return Icons.groups_rounded;
    return Icons.apps_rounded;
  }
}
