<?php
declare(strict_types=1);

/**
 * NECNER Merchant Mobile Workspace Bridge
 *
 * NEW FILE ONLY.
 * Converts an authenticated mobile Bearer session into the existing merchant
 * web session, then redirects the WebView to the real desktop merchant page.
 * Existing service business pages remain untouched.
 */

session_start();

$root = dirname(__DIR__);
require_once $root . '/includes/init.php';

function bridge_error(string $message, int $status = 401): never {
    http_response_code($status);
    header('Content-Type: text/plain; charset=utf-8');
    echo $message;
    exit;
}

try {
    if (!class_exists('SellerAuth') || !method_exists('SellerAuth', 'authenticateBearer')) {
        bridge_error('Merchant authentication is unavailable.', 503);
    }

    $ctx = \SellerAuth::authenticateBearer();
    $tenantId = (int)$ctx->getTenantId();
    $sellerId = method_exists($ctx, 'getSellerId') ? (int)$ctx->getSellerId() : 0;

    if ($tenantId <= 0 || $sellerId <= 0) {
        bridge_error('Active merchant session is required.', 401);
    }

    $db = \WaSaaS\Database::getInstance();
    $user = $db->fetchOne(
        'SELECT * FROM users WHERE id = :user_id AND tenant_id = :tenant_id LIMIT 1',
        [':user_id' => $sellerId, ':tenant_id' => $tenantId]
    );

    if (!$user) {
        bridge_error('Merchant account was not found.', 403);
    }

    $tenant = $db->fetchOne('SELECT * FROM tenants WHERE id = :tenant_id LIMIT 1', [':tenant_id' => $tenantId]);
    if (!$tenant || strtolower((string)($tenant['status'] ?? 'active')) !== 'active') {
        bridge_error('Merchant account is inactive.', 403);
    }

    $path = trim((string)($_GET['path'] ?? '/customer/dashboard.php'));
    if ($path === '') $path = '/customer/dashboard.php';
    if ($path[0] !== '/') $path = '/' . $path;
    if (str_contains($path, '..') || preg_match('~^//|^[a-z][a-z0-9+.-]*://~i', $path)) {
        bridge_error('Invalid workspace path.', 400);
    }

    $serviceKey = strtolower(trim((string)($_GET['service'] ?? '')));

    // If a service is requested, confirm that the current tenant is assigned to it.
    if ($serviceKey !== '') {
        $assigned = false;
        $tenantService = strtolower(trim((string)($tenant['service_type'] ?? $tenant['panel_key'] ?? '')));
        if ($tenantService !== '' && in_array($tenantService, [$serviceKey, str_replace('store', 'ecommerce', $serviceKey)], true)) {
            $assigned = true;
        }

        // Multi-service installations may use tenant_service_assignments.
        foreach (['tenant_service_assignments', 'service_tenant_links'] as $table) {
            try {
                $exists = (int)$db->fetchOne(
                    "SELECT COUNT(*) AS c FROM information_schema.tables WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table",
                    [':table' => $table]
                )['c'];
                if ($exists < 1) continue;

                $row = $db->fetchOne(
                    "SELECT * FROM `$table` WHERE tenant_id = :tenant_id AND service_key = :service_key LIMIT 1",
                    [':tenant_id' => $tenantId, ':service_key' => $serviceKey]
                );
                if ($row && (($row['active'] ?? 1) === 1 || (string)($row['status'] ?? 'active') === 'active')) {
                    $assigned = true;
                }
            } catch (Throwable $ignored) {
                // The fallback tenant service assignment above remains authoritative
                // for single-service tenants.
            }
        }

        if (!$assigned) {
            bridge_error('This service is not assigned to the current merchant.', 403);
        }
    }

    // Recreate the normal web merchant session expected by the existing panel.
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['tenant_id'] = $tenantId;
    $_SESSION['role'] = (string)($user['role'] ?? 'merchant');
    $_SESSION['user'] = $user;
    $_SESSION['authenticated'] = true;

    if (class_exists('Auth') && method_exists('Auth', 'initSession')) {
        try { \Auth::initSession(); } catch (Throwable $ignored) {}
    }

    // Force iframe mode for existing responsive merchant workspace pages.
    $query = [];
    $parts = parse_url($path);
    $cleanPath = (string)($parts['path'] ?? $path);
    if (!empty($parts['query'])) parse_str((string)$parts['query'], $query);
    $query['iframe'] = '1';

    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = (string)($_SERVER['HTTP_HOST'] ?? 'udidesign.in');
    $target = $scheme . '://' . $host . $cleanPath . '?' . http_build_query($query);

    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Location: ' . $target, true, 302);
    exit;
} catch (Throwable $e) {
    error_log('[MOBILE WORKSPACE BRIDGE] ' . $e->getMessage());
    bridge_error('Unable to open the merchant workspace.', 503);
}
